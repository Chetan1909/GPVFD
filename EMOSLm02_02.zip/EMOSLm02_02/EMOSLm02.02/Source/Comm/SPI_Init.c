/*
 * SPI_Init.c
 *
 *  Created on: 05-Oct-2023
 *      Author: arjun
 */

#include <Headers/Project_Header/Init.h>

//uint16_t SPI_REC_BUFF[40];
//unsigned char i=0;

uint16_t  TX_Buff_Status = 0;

unsigned char Data_send_Done = 0, SPI_Frame_Number = 0, rec_buff_index = 0, SPI_SENDING = 0;

uint16_t SPI_REC_BUFF[40];

unsigned char SPI_RECB[SPI_Buffer_Size],SPI_REC_MB[40],SPI_SEND_MB[40],index=0,first_index=0, second_index;  // sagar     index = Last byte index of modbus buffer
                                                                                               // first_index = store the first index for valid modbus command
unsigned char write_byte_index, multi_write_flag,CRC_BUFF_LENGHT;
unsigned char read_write_flag=0;    // indicates that next byes will be of read or write cmd

unsigned int buffer_size;   //sagar
size_t var1, var2,var3,var4;  //sagar
unsigned char MB_funC=0, MB_StartA_H, MB_StartA_L, MB_Nof_Reg_H, MB_Nof_Reg_L, MB_Response_flag, MB_SEND_COUNT=0, MB_byte_to_write;  //sagar
//    unsigned char MB_Nof_Reg_H,MB_Nof_Reg_L;    // sagar
uint16_t MB_Nof_Reg;      // sagar
unsigned int MB_SEND_CRC=0;


uint16_t read_buff=0,writr_buff=0;
uint16_t Motor_Parameters[50];
uint16_t modbus_memory[17][30];

unsigned long temp_float;
float temp_store;

void ConfigureSPI(void){
    EALLOW;

    SpiaRegs.SPICCR.bit.SPISWRESET      = 0;        // Set reset low before configuration changes

    SpiaRegs.SPICCR.bit.CLKPOLARITY     = 1;        // Clock polarity (0 == rising, 1 == falling)
    SpiaRegs.SPICCR.bit.HS_MODE         = 0;        // Disable High Speed Mode
    SpiaRegs.SPICCR.bit.SPILBK          = 0;        // DISABLE LOOP BACK MODE
    SpiaRegs.SPICCR.bit.SPICHAR         = (16-1);    // 8 Bit Data Format

    SpiaRegs.SPICTL.bit.OVERRUNINTENA   = 0;        // Disable overrun interrupt
    SpiaRegs.SPICTL.bit.CLK_PHASE       = 0;        // Normal Clk
    SpiaRegs.SPICTL.bit.MASTER_SLAVE    = 0;        // Enable as Salve (0 == slave, 1 == master)
    SpiaRegs.SPICTL.bit.TALK            = 0;        // Enable transmission (Talk)
    SpiaRegs.SPICTL.bit.SPIINTENA       = 1;        // SPI interrupts are enabled

    SpiaRegs.SPIBRR.bit.SPI_BIT_RATE    = 4;        // LSPCLK/(SPIBRR+1)

    SpiaRegs.SPIFFTX.bit.TXFFINTCLR     = 1;        // Clear TX FIFO interrupt Flag
    SpiaRegs.SPIFFTX.bit.SPIFFENA       = 1;        // Enable FIFIO
    SpiaRegs.SPIFFTX.bit.TXFIFO         = 0;        // Reset TX FIFO pointer
    SpiaRegs.SPIFFTX.bit.TXFFIENA       = 0;        // TX FIFO interrupt Disable
    SpiaRegs.SPIFFTX.bit.TXFFIL         = 0;        // Generate interrupt when no word remains in TX buffer.
    SpiaRegs.SPIFFTX.bit.TXFIFO         = 1;        // Release TX FIFO from reset

    SpiaRegs.SPIFFRX.bit.RXFFINTCLR     = 1;        // Clear RX FIFO interrupt Flag
    SpiaRegs.SPIFFRX.bit.RXFIFORESET    = 0;        // Reset RX FIFO pointer
    SpiaRegs.SPIFFRX.bit.RXFFIENA       = 1;        // RX FIFO interrupt Enable
    SpiaRegs.SPIFFRX.bit.RXFFIL         = 1;        // Generate interrupt when one or more word remains in RX buffer.
    SpiaRegs.SPIFFRX.bit.RXFIFORESET    = 1;        // Release RX FIFO from reset

    SpiaRegs.SPIPRI.bit.FREE            = 0;
    SpiaRegs.SPIPRI.bit.TRIWIRE         = 0;

    SpiaRegs.SPICCR.bit.SPISWRESET      = 1;        // Release SPI reset to initialize SPI

    dummy_read = SpiaRegs.SPIRXBUF;
    SpiaRegs.SPIFFRX.bit.RXFFINTCLR     = 1;        // Clear RX FIFO interrupt Flag
    PieCtrlRegs.PIEACK.all              = PIEACK_GROUP6;              // Issue PIE ACK

    EDIS;
}

/***************************************SPIA_TX_ISR*******************************************/
/*
 * This interrupt is serving all the transmissions through SPI
 */
/********************************************************************************************/

__interrupt void spiaTxFifoIsr(void){
    EINT;                                                   // Enable Global interrupt INTM
    SPI_SENDING = 0;
    SpiaRegs.SPIFFTX.bit.TXFFINTCLR     = 1;        // Clear TX FIFO interrupt Flag
    PieCtrlRegs.PIEACK.all              = PIEACK_GROUP6;              // Issue PIE ACK
}

/***************************************SPIA_TX_ISR*******************************************/
/*
 * This interrupt is serving all the transmissions through SPI
 */
/********************************************************************************************/

__interrupt void spiaRxFifoIsr(void){
    EINT;                                                   // Enable Global interrupt INTM
//    SPI_Recv_Process();   // sagar comment
    SPI_modbus();

    SpiaRegs.SPIFFRX.bit.RXFFINTCLR     = 1;        // Clear RX FIFO interrupt Flag
    PieCtrlRegs.PIEACK.all              = PIEACK_GROUP6;              // Issue PIE ACK
}


//void SPI_Recv_Process(void)
//{
//    if(SPI_SENDING == false){
//        SPI_REC_BUFF[rec_buff_index] = SpiaRegs.SPIRXBUF;
//
//        if((rec_buff_index > 2) && SPI_REC_BUFF[rec_buff_index] == 0x22 && SPI_REC_BUFF[rec_buff_index-2] == 0x03 && SPI_REC_BUFF[rec_buff_index-3] == 0x11){
//            SPI_REC_BUFF[rec_buff_index] = 0;
//            SPI_SENDING = true;
//            SPI_Frame_Number = SPI_REC_BUFF[rec_buff_index-1];
//
//            for(i=0;i<14;i++){
//                SpiaRegs.SPITXBUF = (SPI_send_buff[SPI_Frame_Number][i]);
//            }
//            EALLOW;
//            SpiaRegs.SPICTL.bit.TALK            = 1;
//            EDIS;
//
//        }
//        if((rec_buff_index > 4) && SPI_REC_BUFF[rec_buff_index] == 0x22 && SPI_REC_BUFF[rec_buff_index-4] == 0x06 && SPI_REC_BUFF[rec_buff_index-5] == 0x11){
//            SPI_REC_BUFF[rec_buff_index] = 0;
//            if(SPI_REC_BUFF[rec_buff_index-3] == 0x01)
//            { ON_OFF_FLAG = 1;  }
//
//            if(SPI_REC_BUFF[rec_buff_index-3] == 0x02)
//            { SOFT_STOP_FLAG = 1;  }
//
//            if(SPI_REC_BUFF[rec_buff_index-3] == 0x03 && ON_OFF_FLAG == false){                             // Speed mode Selection
//                SPEED_MODE_SELECT = SPI_REC_BUFF[rec_buff_index-1];                                         // Need to write in EEPROM also
//            }
//
//            if(SPI_REC_BUFF[rec_buff_index-3] == 0x04){                                                     // Speed ref Selection
//                SPEED_RPM_REF_UI = SPI_REC_BUFF[rec_buff_index-1];                                          // Need to write in EEPROM also
//            }
//            if((SPI_REC_BUFF[rec_buff_index-3] == 0xFF) && (SPI_REC_BUFF[rec_buff_index-1] == 0x02) ){      // for display REset on start up
//                Display_Reset_Flag = 2;                                                                     // Need to write in EEPROM also
//            }
//        }
//        rec_buff_index++;
//        if(rec_buff_index > 39)
//        {rec_buff_index = 0;}
//    }
//    else{
//        dummy_read = SpiaRegs.SPIRXBUF;
//
//        if(Data_send_Done == true){
//            SPI_SENDING = false;
//            EALLOW;
//            SpiaRegs.SPICTL.bit.TALK            = 0;
//            EDIS;
//        }
//        TX_Buff_Status = (SpiaRegs.SPIFFTX.all);
//        TX_Buff_Status = TX_Buff_Status & 0x1F00;
//        TX_Buff_Status = TX_Buff_Status >> 8;
//
//        if(TX_Buff_Status == 0 && Data_send_Done == false){
//            Data_send_Done = true;
//        }
//        else{
//            Data_send_Done = false;
//        }
//    }
//}

void SPI(void)
{
        if(SPI_SENDING == false){
            SPI_REC_BUFF[rec_buff_index] = SpiaRegs.SPIRXBUF;

            if((rec_buff_index > 2) && SPI_REC_BUFF[rec_buff_index-2] == 0xFF00 && SPI_REC_BUFF[rec_buff_index-3] == 0x0106){
                SPI_REC_BUFF[rec_buff_index-3] = 0;
                SPI_REC_BUFF[rec_buff_index-2] = 0;
                SPI_SENDING = true;
//                SPI_Frame_Number = SPI_REC_BUFF[rec_buff_index-1];

                for(var3=0;var3<4;var3++){
                    SpiaRegs.SPITXBUF = 0x0102;
                }
                EALLOW;
                SpiaRegs.SPICTL.bit.TALK            = 1;
                EDIS;

            }

            rec_buff_index++;
            if(rec_buff_index > 39)
            {rec_buff_index = 0;}
        }
        else{
            dummy_read = SpiaRegs.SPIRXBUF;

            if(Data_send_Done == true){
                SPI_SENDING = false;
                EALLOW;
                SpiaRegs.SPICTL.bit.TALK            = 0;
                EDIS;
            }
            TX_Buff_Status = (SpiaRegs.SPIFFTX.all);
            TX_Buff_Status = TX_Buff_Status & 0x1F00;
            TX_Buff_Status = TX_Buff_Status >> 8;

            if(TX_Buff_Status == 0 && Data_send_Done == false){
                Data_send_Done = true;
            }
            else{
                Data_send_Done = false;
            }
        }
}


void SPI_modbus(void)
{
    if(SPI_SENDING == false)
    {
        read_buff = SpiaRegs.SPIRXBUF;

        SPI_RECB[rec_buff_index % SPI_Buffer_Size]        = (read_buff>>8);
        SPI_RECB[(rec_buff_index + 1)%SPI_Buffer_Size]    = (read_buff & 0xFF);
        index = (rec_buff_index + 1)%SPI_Buffer_Size;

        if( SPI_RECB[( SPI_Buffer_Size + (index-1) ) % SPI_Buffer_Size]==0x01 &&
                  (SPI_RECB[(SPI_Buffer_Size+index) % SPI_Buffer_Size] == 0x03 ||
                     SPI_RECB[(SPI_Buffer_Size+index)%SPI_Buffer_Size] == 0x06 ) && read_write_flag==0 )
        {
            first_index = ( SPI_Buffer_Size + (index-1) ) % SPI_Buffer_Size;                        //if the command is single write or multiple read
            multi_write_flag =0;                                                                    // if flag is zero means command is single write or multiple read
            read_write_flag = 1;                                                                    // it shows that some command is in process so we do not have to check for same condition
        }
        else if( SPI_RECB[( SPI_Buffer_Size + (index-1) ) % SPI_Buffer_Size]==0x01 &&
                       SPI_RECB[(SPI_Buffer_Size+index) % SPI_Buffer_Size] == 0x10 )
        {
          first_index  = ( SPI_Buffer_Size + (index-1) ) % SPI_Buffer_Size;
          write_byte_index = ( SPI_Buffer_Size + (first_index+6) ) % SPI_Buffer_Size;
          multi_write_flag =1;
        }
        if(index == ((first_index+7) % SPI_Buffer_Size) && multi_write_flag==0)
        {
            read_write_flag=0;                                                                     // after receiving some bytes it will again set the flag to zero so we can receive wait for other command(single write or multiple read)
            buffer_size = sizeof(SPI_RECB);
            memset(SPI_REC_MB, 0, sizeof(SPI_REC_MB));
            copy_buffer_part_wraparound(SPI_RECB, first_index, 8, SPI_REC_MB, buffer_size);
            SPI_RECB[first_index] =0;
            memset(SPI_RECB+( (SPI_Buffer_Size+first_index-8) % SPI_Buffer_Size), 0, 8);

            if(CRC16_MODBUS(SPI_REC_MB,8) == 0)
            {
                MB_function(SPI_REC_MB);
            }
//            EALLOW;
//            SpiaRegs.SPICTL.bit.TALK            = 1;
//            EDIS;
        }
        second_index = (first_index + SPI_RECB[write_byte_index] + 8) % SPI_Buffer_Size;                                  // hold the last index of multiple write command
        index = ( SPI_Buffer_Size + (index-1) ) % SPI_Buffer_Size;
        if (index == second_index )
        {
            buffer_size = sizeof(SPI_RECB);
            memset(SPI_REC_MB, 0, sizeof(SPI_REC_MB));
            CRC_BUFF_LENGHT = ( SPI_RECB[write_byte_index] + 9 );
            copy_buffer_part_wraparound(SPI_RECB, first_index, CRC_BUFF_LENGHT, SPI_REC_MB, buffer_size);
            SPI_RECB[first_index] =0;
            if(CRC16_MODBUS(SPI_REC_MB,CRC_BUFF_LENGHT) == 0)
            {
                MB_function(SPI_REC_MB);
            }

        }




    rec_buff_index =rec_buff_index +2;
    rec_buff_index = rec_buff_index % SPI_Buffer_Size;
    }
    else
    {
        dummy_read = SpiaRegs.SPIRXBUF;

        if(Data_send_Done == true){
            SPI_SENDING = false;
            EALLOW;
            SpiaRegs.SPICTL.bit.TALK            = 0;
            EDIS;
        }
        TX_Buff_Status = (SpiaRegs.SPIFFTX.all);
        TX_Buff_Status = TX_Buff_Status & 0x1F00;
        TX_Buff_Status = TX_Buff_Status >> 8;

        if(TX_Buff_Status == 0 && Data_send_Done == false){
            Data_send_Done = true;
        }
        else{
            Data_send_Done = false;
        }

    }
}

void MB_function(unsigned char *CMD_REC_MB)
{
    MB_funC      = CMD_REC_MB[1];
    MB_StartA_H  = CMD_REC_MB[2];
    MB_StartA_L  = CMD_REC_MB[3];
//    MB_Nof_Reg_H = CMD_REC_MB[4];
//    MB_Nof_Reg_L = CMD_REC_MB[5];
//    MB_Nof_Reg   = (CMD_REC_MB[4]<<8) | CMD_REC_MB[5];

    switch(MB_funC)
    {
    case 0x03:
        MB_Response_flag=1;
        break;

    case 0x06:

        MB_Response_flag=2;
        break;

    case 0x10:

        MB_Response_flag=3;
        break;
    }

    switch(MB_Response_flag)
    {
    case 1:
        if(MB_StartA_H==0xFF)
        {
            MB_Nof_Reg   = (CMD_REC_MB[4]<<8) | CMD_REC_MB[5];
            memset(SPI_SEND_MB, 0, sizeof(SPI_SEND_MB));
            MB_SEND_COUNT =0;
            SPI_SEND_MB[MB_SEND_COUNT] = 0x01; MB_SEND_COUNT++;   SPI_SEND_MB[MB_SEND_COUNT] = 0x03; MB_SEND_COUNT++;   SPI_SEND_MB[MB_SEND_COUNT] = MB_Nof_Reg*2; MB_SEND_COUNT++;
            for(var1=0, var2=MB_StartA_L; var1<MB_Nof_Reg; var1++, var2++)
            {
                SPI_SEND_MB[MB_SEND_COUNT]   =  Motor_Parameters[var2]>>8; MB_SEND_COUNT++;
                SPI_SEND_MB[MB_SEND_COUNT] =  Motor_Parameters[var2] & 0xFF; MB_SEND_COUNT++;
            }
            MB_SEND_CRC = CRC16_MODBUS(SPI_SEND_MB,MB_SEND_COUNT);
            SPI_SEND_MB[MB_SEND_COUNT]    =  MB_SEND_CRC & 0xFF;
            SPI_SEND_MB[MB_SEND_COUNT+1]  =  MB_SEND_CRC>>8 ;


            SPI_SENDING = true;
            for(var4=0, var3=0; var4<(MB_Nof_Reg+3); var3+=2, var4++){
                writr_buff        = (SPI_SEND_MB[var3]<<8) | SPI_SEND_MB[var3+1];
                SpiaRegs.SPITXBUF = writr_buff;
            }
            EALLOW;
            SpiaRegs.SPICTL.bit.TALK            = 1;
            EDIS;
        }
        else
        {

            MB_Nof_Reg   = (CMD_REC_MB[4]<<8) | CMD_REC_MB[5];
            memset(SPI_SEND_MB, 0, sizeof(SPI_SEND_MB));
            MB_SEND_COUNT =0;
            SPI_SEND_MB[MB_SEND_COUNT] = 0x01; MB_SEND_COUNT++;   SPI_SEND_MB[MB_SEND_COUNT] = 0x03; MB_SEND_COUNT++;   SPI_SEND_MB[MB_SEND_COUNT] = MB_Nof_Reg*2; MB_SEND_COUNT++;
            for(var1=0, var2=MB_StartA_L; var1<MB_Nof_Reg; var1++, var2++)
            {
                SPI_SEND_MB[MB_SEND_COUNT] =  modbus_memory[MB_StartA_H][var2]>>8; MB_SEND_COUNT++;
                SPI_SEND_MB[MB_SEND_COUNT] =  modbus_memory[MB_StartA_H][var2] & 0xFF; MB_SEND_COUNT++;
            }
            MB_SEND_CRC = CRC16_MODBUS(SPI_SEND_MB,MB_SEND_COUNT);
            SPI_SEND_MB[MB_SEND_COUNT]    =  MB_SEND_CRC & 0xFF;
            SPI_SEND_MB[MB_SEND_COUNT+1]  =  MB_SEND_CRC>>8 ;


            SPI_SENDING = true;
            for(var4=0, var3=0; var4<(MB_Nof_Reg+3); var3+=2, var4++){
                writr_buff        = (SPI_SEND_MB[var3]<<8) | SPI_SEND_MB[var3+1];
                SpiaRegs.SPITXBUF = writr_buff;
            }
            EALLOW;
            SpiaRegs.SPICTL.bit.TALK            = 1;
            EDIS;

        }

        break;

    case 2:
        memset(SPI_SEND_MB, 0, 40);
        MB_SEND_COUNT =8;
        memcpy(SPI_SEND_MB, CMD_REC_MB, MB_SEND_COUNT);

        if(MB_StartA_H==0xFF)
        {
            Motor_Parameters[MB_StartA_L] = (CMD_REC_MB[4]<<8) | CMD_REC_MB[5];
            Update_Motor_Para();
        }
        else{
            modbus_memory[MB_StartA_H][MB_StartA_L] = (CMD_REC_MB[4]<<8) | CMD_REC_MB[5];
            Update_Modbus_Memory();
        }

        SPI_SENDING = true;

        for(var4=0, var3=0; var4<(4); var3+=2, var4++){
            writr_buff        = (SPI_SEND_MB[var3]<<8) | SPI_SEND_MB[var3+1];
            SpiaRegs.SPITXBUF = writr_buff;
        }
        EALLOW;
        SpiaRegs.SPICTL.bit.TALK            = 1;
        EDIS;

        break;

    case 3:
        memset(SPI_SEND_MB, 0, 40);
//        MB_Nof_Reg_H = CMD_REC_MB[4];
//        MB_Nof_Reg_L = CMD_REC_MB[5];
        MB_Nof_Reg        = (CMD_REC_MB[4]<<8) | CMD_REC_MB[5];
        MB_byte_to_write  = CMD_REC_MB[6];

        for(var4=0, var3=7; var4<(MB_Nof_Reg); var3+=2, var4++)
        {
            modbus_memory[MB_StartA_H][MB_StartA_L+var4] = (CMD_REC_MB[var3]<<8) | CMD_REC_MB[var3+1];
        }
        Update_Modbus_Memory();
        MB_SEND_COUNT=0;
        SPI_SEND_MB[MB_SEND_COUNT] = 0x01; MB_SEND_COUNT++;   SPI_SEND_MB[MB_SEND_COUNT] = 0x10; MB_SEND_COUNT++;
        SPI_SEND_MB[MB_SEND_COUNT] = MB_StartA_H; MB_SEND_COUNT++;  SPI_SEND_MB[MB_SEND_COUNT] = MB_StartA_L; MB_SEND_COUNT++;
        SPI_SEND_MB[MB_SEND_COUNT] = CMD_REC_MB[4]; MB_SEND_COUNT++; SPI_SEND_MB[MB_SEND_COUNT] = CMD_REC_MB[5]; MB_SEND_COUNT++;
        MB_SEND_CRC = CRC16_MODBUS(SPI_SEND_MB,MB_SEND_COUNT);
        SPI_SEND_MB[MB_SEND_COUNT]    =  MB_SEND_CRC & 0xFF;
        SPI_SEND_MB[MB_SEND_COUNT+1]  =  MB_SEND_CRC>>8 ;

        SPI_SENDING = true;
        for(var4=0, var3=0; var4<(4 ); var3+=2, var4++){
            writr_buff        = (SPI_SEND_MB[var3]<<8) | SPI_SEND_MB[var3+1];
            SpiaRegs.SPITXBUF = writr_buff;
        }
        EALLOW;
        SpiaRegs.SPICTL.bit.TALK            = 1;
        EDIS;

        break;
    }

}

unsigned int checksum(unsigned char *buf,int start, int len){
    unsigned int crc = 0xFFFF;
    int pos=start,i=0;
    for (pos = start; pos < len; pos++){
        crc ^= (unsigned int)buf[pos];                                                      // XOR byte into least sig. byte of crc
        for ( i = 8; i != 0; i--)                                                           // Loop over each bit
        {
            if ((crc & 0x0001) != 0)                                                        // If the LSB is set
            {
                crc >>= 1;                                                                  // Shift right and XOR 0xA001
                crc ^= 0xA001;
            }
            else
                crc >>= 1;                                                                  // Just shift right
        }
    }
    return crc;
}



void copy_buffer_part(char *source, int start_index, int length, char *destination) {
    memcpy(destination, source + start_index, length);
}

void copy_buffer_part_wraparound(unsigned char *source, unsigned int start_index, unsigned int length, unsigned char *destination, unsigned int buffer_size) {
    int copy_length = length;
    if (start_index + length > buffer_size) {
        // Adjust the copy length to wrap around to the beginning of the buffer
        copy_length = buffer_size - start_index;
    }

    memcpy(destination, source + start_index, copy_length);

    // If we wrapped around, copy the remaining part from the beginning of the source buffer
    if (copy_length < length) {
        memcpy(destination + copy_length, source, length - copy_length);
    }
}

void Display_SPI_Buffer_Fill(void)
{
// Input Parameters (Frame number 0)
    SPI_send_buff[0][0]        =   0xF0F0;

    temp_float = *(unsigned long *)&VGRD_RY_STRUCT.RMS;
    SPI_send_buff[0][1]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[0][2]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&VGRD_YB_STRUCT.RMS;
    SPI_send_buff[0][3]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[0][4]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&IGRD_R_STRUCT.RMS;
    SPI_send_buff[0][5]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[0][6]        =   (uint16_t)(temp_float & 0X0000FFFF);

    SPI_send_buff[0][7]        =   Display_Reset_Flag;      // for display reset at startup
    SPI_send_buff[0][8]        =   ON_OFF_FLAG;

    temp_store = 49.9;
    temp_float = *(unsigned long *)&temp_store;//*(unsigned long *)&Input_Freq;
    SPI_send_buff[0][9]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[0][10]       =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&VDC_BUS;
    SPI_send_buff[0][11]       =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[0][12]       =   (uint16_t)(temp_float & 0X0000FFFF);

    SPI_send_buff[0][13]       =   0x0F0F;

// Output Parameters (Frame number 1)

    SPI_send_buff[1][0]        =   0xF0F1;

    temp_float = *(unsigned long *)&VVFD_UV_STRUCT.RMS;
    SPI_send_buff[1][1]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[1][2]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&VVFD_VW_STRUCT.RMS;
    SPI_send_buff[1][3]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[1][4]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&IVFD_U_STRUCT.RMS;
    SPI_send_buff[1][5]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[1][6]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&IVFD_V_STRUCT.RMS;
    SPI_send_buff[1][7]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[1][8]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&Freq;
    SPI_send_buff[1][9]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[1][10]       =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_store = 0.98;
    temp_float = *(unsigned long *)&temp_store;//*(unsigned long *)&Output_Power_Factor;
    SPI_send_buff[1][11]       =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[1][12]       =   (uint16_t)(temp_float & 0X0000FFFF);

    SPI_send_buff[1][13]       =   0x1F0F;

// Load Parameters (Frame number 2)

    SPI_send_buff[2][0]        =   0xF0F2;

    SPI_send_buff[2][1]        =   RPM_Display;
    SPI_send_buff[2][2]        =   1;

    temp_float = 0;//*(unsigned long *)&Output_Power;
    SPI_send_buff[2][3]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[2][4]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = 0;//*(unsigned long *)&Output_Torque;
    SPI_send_buff[2][5]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[2][6]        =   (uint16_t)(temp_float & 0X0000FFFF);

    SPI_send_buff[2][7]        =   (uint16_t)((FAULT_CODE & 0XFFFF0000)>>16);
    SPI_send_buff[2][8]        =   (uint16_t)(FAULT_CODE & 0X0000FFFF);

    temp_float = 0;//*(unsigned long *)&Total_Discharge;
    SPI_send_buff[2][9]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[2][10]       =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = 0;//*(unsigned long *)&Today_Discharge;
    SPI_send_buff[2][11]       =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[2][12]       =   (uint16_t)(temp_float & 0X0000FFFF);

    SPI_send_buff[2][13]       =   0x2F0F;

// Energy-Time Parameters (Frame number 3)

    SPI_send_buff[3][0]        =   0xF0F3;

    temp_float = 0;//*(unsigned long *)&Total_Hours;
    SPI_send_buff[3][1]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[3][2]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = 0;//*(unsigned long *)&Total_Energy;
    SPI_send_buff[3][3]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[3][4]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = 0;//*(unsigned long *)&Today_Hours;
    SPI_send_buff[3][5]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[3][6]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = 0;//*(unsigned long *)&Today_Energy;
    SPI_send_buff[3][7]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[3][8]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = 0;//*(unsigned long *)&Test1_Time;
    SPI_send_buff[3][9]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[3][10]       =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = 0;//*(unsigned long *)&Test1_Energy;
    SPI_send_buff[3][11]       =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[3][12]       =   (uint16_t)(temp_float & 0X0000FFFF);

    SPI_send_buff[3][13]       =   0x3F0F;

// Remaining Parameters (Frame number 6)

    SPI_send_buff[6][0]        =   0xF0F6;

    temp_float = *(unsigned long *)&TEMP_INV;
    SPI_send_buff[6][1]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[6][2]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&TEMP_HS;
    SPI_send_buff[6][3]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    SPI_send_buff[6][4]        =   (uint16_t)(temp_float & 0X0000FFFF);

    SPI_send_buff[6][5]        =   0;
    SPI_send_buff[6][6]        =   0;

    SPI_send_buff[6][7]        =   0;
    SPI_send_buff[6][8]        =   0;

    SPI_send_buff[6][9]        =   0;   // Reserved
    SPI_send_buff[6][10]       =  0;   // Reserved

    SPI_send_buff[6][11]       =  0;
    SPI_send_buff[6][12]       =  0;

    SPI_send_buff[6][13]       =   0x6F0F;



//////////             sagar               //////////

    Motor_Parameters[0]         =  ON_OFF_FLAG;

    modbus_memory[0x0D][0x0E]   = ON_OFF_FLAG;
    modbus_memory[0x0D][0x14]   = SPEED_RPM_REF_UI;
    modbus_memory[0x0D][0x06]   = SPEED_FORWARD;
    //modbus_memory[0x0D][0x13]   = MOTOR_ID;

    Motor_Parameters[1]         =  (uint16_t)((FAULT_CODE & 0XFFFF0000)>>16);
    Motor_Parameters[2]         =  (uint16_t)(FAULT_CODE & 0X0000FFFF);

    temp_float = *(unsigned long *)&VGRD_RY_STRUCT.RMS;
    Motor_Parameters[3]         =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[4]         =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&VGRD_YB_STRUCT.RMS;
    Motor_Parameters[5]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[6]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&VGRD_BR_STRUCT.RMS;
    Motor_Parameters[7]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[8]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&VDC_BUS;                                                 //DC bus voltage
    Motor_Parameters[9]       =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[10]       =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_store = 49.9;
    temp_float = *(unsigned long *)&temp_store;//*(unsigned long *)&Input_Freq;              //i/p freq
    Motor_Parameters[11]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[12]        =   (uint16_t)(temp_float & 0X0000FFFF);



    temp_float = *(unsigned long *)&IGRD_R_STRUCT.RMS;                                       //i/p i1
    Motor_Parameters[13]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[14]       =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&IGRD_R_STRUCT.RMS;                                       //i/p i2
    Motor_Parameters[15]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[16]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&IGRD_R_STRUCT.RMS;                                       //i/p i3
    Motor_Parameters[17]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[18]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&VVFD_UV_STRUCT.RMS;                                      //o/p v1
    Motor_Parameters[19]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[20]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&VVFD_VW_STRUCT.RMS;                                      //o/p v2
    Motor_Parameters[21]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[22]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&VVFD_WU_STRUCT.RMS;                                      //o/p v3
    Motor_Parameters[23]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[24]        =   (uint16_t)(temp_float & 0X0000FFFF);

    Motor_Parameters[25]        =   Display_Reset_Flag;                                      // for display reset at startup

    temp_float = *(unsigned long *)&IVFD_U_STRUCT.RMS;                                       //o/p i1
    Motor_Parameters[26]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[27]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&IVFD_V_STRUCT.RMS;                                       //o/p i2
    Motor_Parameters[28]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[29]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&IVFD_W_STRUCT.RMS;                                       //o/p i3
    Motor_Parameters[30]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[31]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&Freq;                                                    //o/p freq
    Motor_Parameters[32]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[33]       =   (uint16_t)(temp_float & 0X0000FFFF);

    Motor_Parameters[34]        =   RPM_Display;                                            //live rpm (speed)
    Motor_Parameters[35]        =   1;

    temp_float = 0;//*(unsigned long *)&Output_Power;                                       // Output_Power
    Motor_Parameters[36]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[37]        =   (uint16_t)(temp_float & 0X0000FFFF);

    Motor_Parameters[38]       =   0xFFFF;                                                   //eprom count



    temp_float = 0;//*(unsigned long *)&Output_Torque;                                       //Output_Torque
    Motor_Parameters[39]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[40]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&TEMP_INV;
    Motor_Parameters[41]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[42]        =   (uint16_t)(temp_float & 0X0000FFFF);

    temp_float = *(unsigned long *)&TEMP_HS;
    Motor_Parameters[43]        =   (uint16_t)((temp_float & 0XFFFF0000)>>16);
    Motor_Parameters[44]        =   (uint16_t)(temp_float & 0X0000FFFF);




}

void Update_Motor_Para(void){
       if(Motor_Parameters[0]==1){ON_OFF_FLAG=1;}
       if(Motor_Parameters[0]==0){SOFT_STOP_FLAG=1;}
}

void Update_Modbus_Memory(){
         if(ON_OFF_FLAG == 0){
             SPEED_FORWARD      = modbus_memory[0x0D][0x06];
             //Need to write in EEPROM
         }
         if(SOFT_STOP_FLAG ==0){
         SPEED_RPM_REF_UI   = modbus_memory[0x0D][0x14];          // to change rpm
       /*  if(MOTOR_ID != modbus_memory[0x0D][0x13]){
             MOTOR_ID   =   modbus_memory[0x0D][0x13];
             Variable_Init();
             }*/
         }
         if(modbus_memory[0x0D][0x0E]==1){ON_OFF_FLAG=1;}
         if(modbus_memory[0x0D][0x0E] ==0){SOFT_STOP_FLAG=1;}
//         CONTROL_MODE  = modbus_memory[0x01][0x02];          //to update control mode

}
