/*
 * I2C_Init.c
 *
 *  Created on: 28-Aug-2023
 *      Author: Arjun
 */

#include <Headers/Project_Header/Init.h>

unsigned int i2c_fail_count = 0;

void EEPROM_Default_Data_Write(void){

//    // Planned Memory Map of 24LC64
//    //  64 pages of 128 bytes each
//
//    //                  Total           Pages Total Size in bytes       Used for        Total para
//    //Page 0 - 1        2                   256                         Device info
//    //Page 2 - 101      100                 12800                       Parameters          800
//    //Page 102 - 151    10                  1280                        Fault Logs          80
//    //Page 152 - 171    20                  2560                        Parameters          1280
//    //Page 172 - 191    20                  2560                        Reserved            1280
//
//
//    //    EEPROM_WriteByte(unsigned char eeprom_page_number, unsigned char eeprom_address, unsigned char eeprom_data)
//
////    /*01*/EEPROM_WriteByte(2,0,0);      // MASTER_ON_OFF                                    //0-1
////    /*02*/EEPROM_WriteByte(2,1,2);      // SPEED_MODE_SELECT                                //1-5   ->  1 : AUTO 2 : MANNUAL 3: SPEED_CONTROL 4: JOG 5: TIMER
////    /*03*/EEPROM_WriteByte(2,2,1);      // SPEED_DIRECTION_SELECT                           //1-2   ->  1 : FORWARD 2 : REVERSE
////    /*04*/EEPROM_WriteByte(2,3,0);      // FACTORY_MODE                                     //0-1   ->  0 : DO NOT ENTER FACTORY MODE 1 : ENTER FACTORY MODE
////    /*05*/EEPROM_WriteByte(2,4,0);      // LANGUAGE_SELECTED                                //0-0   ->  0 : ENGLISH
////    /*06*/EEPROM_WriteByte(2,5,0);      // APP_MODE                                         //0-1   ->  0 : GRID 1 : SOLAR
////    /*07*/EEPROM_WriteByte(2,6,0);      // MOTOR_TYPE                                       //0-2   ->  0 : Induction  1 : PMSM
//    /*08*/EEPROM_WriteByte(2,5,1);      // EEPROM_DATA_VALID_FLAG                           //0-1   ->  0 : DATA NOT VALID ON EEPROM 1 : DATA VALID
//
//    //    EEPROM_WriteInt(unsigned char eeprom_page_number, unsigned char eeprom_address, unsigned int eeprom_data)
//
////    /*01*/EEPROM_WriteInt(3,0,0);           // MOTOR_TYPE                  //1/1                       //0-2
////    /*01*/EEPROM_WriteInt(3,2,0);           // CONTROL MODE                  //1/1                       //0-2
////    /*03*/EEPROM_WriteInt(3,4,3400);       // RATED_VOLT_IM       04/02/2025
////    /*07*/EEPROM_WriteInt(3,6,140);      // RATED_CURR_IM                                 //1/10000                    //5-999 //30-460
////    /*04*/EEPROM_WriteInt(3,8,60);        // RATED_FREQ_IM       04/02/2025
////    /*04*///EEPROM_WriteInt(3,10,60);        // Omega       04/02/2025
////    /*04*///EEPROM_WriteInt(3,12,60);        // Power       04/02/2025
////    /*06*/EEPROM_WriteInt(3,14,85);     // RATED_COS_PHI_IM
////    /*06*///EEPROM_WriteInt(3,16,85);     // Slip
////    /*11*/EEPROM_WriteInt(3,17,419);     // Rs
////    /*10*/EEPROM_WriteInt(3,20,430);      // Rr                                  //1/100                      //20-9999
////    /*08*///EEPROM_WriteInt(3,22,400);     // Llr                                  //1/10000                    //20-9999
////    /*08*/EEPROM_WriteInt(3,24,200);     // Lls                                  //1/10000                    //20-9999
////    /*09*/EEPROM_WriteInt(3,26,4250);      // Lm                                  //1/100                      //20-9999
////    /*05*/EEPROM_WriteInt(3,28,2);       // RATED_POLE_IM                    //1/10                       //0-30
////    /*05*///EEPROM_WriteInt(3,30,35);       // Torque percentage                    //1/10                       //0-30
////    /*02*/EEPROM_WriteInt(3,32,0);          // MOTOR_ID     //0-,1-,2-,3-,4-
//
//    //Admin Parameter 05-04-2025
    EEPROM_WriteInt(2,0,1);
    EEPROM_WriteInt(2,2,0);
    EEPROM_WriteInt(2,4,1);
    EEPROM_WriteInt(2,6,1234);
    EEPROM_WriteInt(2,8,1);
    EEPROM_WriteInt(2,10,10);   //  Retry_time_Minutes_EEPROM
    EEPROM_WriteInt(2,12,0);   //  MASTER_ON_OFF

//
//    //Application Parameter 17-02-2025
    EEPROM_WriteInt(3,0,0);           // MOTOR_TYPE
    EEPROM_WriteInt(3,2,0);      // APP_MODE 0 : GRID 1 : SOLAR
    EEPROM_WriteInt(3,4,1);           // CONTROL MODE
//    EEPROM_WriteInt(2,10,10);   //  Retry_time_Minutes_EEPROM
//
//  //  EEPROM_WriteInt(3,32,0);          // MOTOR_ID//////\\\\\\\\\\\\\\\\\\\
//
//
//    //    EEPROM_WriteInt(unsigned char eeprom_page_number, unsigned char eeprom_address, unsigned int eeprom_data)
//    //IM 17-02-2025 -3HP,
    EEPROM_WriteInt(4,0,3800);       // RATED_VOLT_IM
    EEPROM_WriteInt(4,2,150);      // RATED_CURR_IM
    EEPROM_WriteInt(4,4,50);        // RATED_FREQ_IM
    EEPROM_WriteInt(4,6,3000);        // Omega
    EEPROM_WriteInt(4,8,2200);        // Power
    EEPROM_WriteInt(4,10,85);     // RATED_COS_PHI_IM
    EEPROM_WriteInt(4,12,0);     // Slip
    EEPROM_WriteInt(4,14,45);     // Rs
    EEPROM_WriteInt(4,16,85);      // Rr
    EEPROM_WriteInt(4,18,400);     // Llr
    EEPROM_WriteInt(4,20,500);     // Lls
    EEPROM_WriteInt(4,22,300);      // Lm
    EEPROM_WriteInt(4,24,2);       // RATED_POLE_IM
    EEPROM_WriteInt(4,26,1000);       // Torque percentage

//
//
//    //PM 18-02-2025
    EEPROM_WriteInt(5,0,2800);  //RATED_VOLT_PM
    EEPROM_WriteInt(5,2,150);   //RATED_CURR_PM
    EEPROM_WriteInt(5,4,1000);   //RATED_FREQ_PM
    EEPROM_WriteInt(5,6,3000);  // RATED_OMEGA_PM
    EEPROM_WriteInt(5,8,2200);   // MOTOR_POWER_PM
    EEPROM_WriteInt(5,10,95);   // RATED_COS_PHI_PM
    EEPROM_WriteInt(5,12,40);     // Rs_PM
    EEPROM_WriteInt(5,14,600);     // Ld_PM
    EEPROM_WriteInt(5,16,800);     // Lq_PM
    EEPROM_WriteInt(5,18,4);    //RATED_POLE_PM
    EEPROM_WriteInt(5,20,0);    // torque percent
    EEPROM_WriteInt(5,22,25);// IMP_FACTOR
//
//    //SynRM motor para //05-04-2025
//    EEPROM_WriteInt(6,0,4150);
//    EEPROM_WriteInt(6,2,150);
//    EEPROM_WriteInt(6,4,50);
//    EEPROM_WriteInt(6,6,3000);
//    EEPROM_WriteInt(6,8,1500);
//    EEPROM_WriteInt(6,10,85);
////    EEPROM_WriteInt(6,12,);//////////////////////////
//    EEPROM_WriteInt(6,14,45);
//    EEPROM_WriteInt(6,16,85);
//    EEPROM_WriteInt(6,18,400);
//    EEPROM_WriteInt(6,20,500);
//    EEPROM_WriteInt(6,22,300);
//    EEPROM_WriteInt(6,24,300);
//    EEPROM_WriteInt(6,26,0);
//
//    //speed selection  motor para //05-04-2025
    EEPROM_WriteInt(7,0,3);
    EEPROM_WriteInt(7,2,1);
    EEPROM_WriteInt(7,4,100);
    EEPROM_WriteInt(7,6,200);
    EEPROM_WriteInt(7,8,300);
    EEPROM_WriteInt(7,10,500);
    EEPROM_WriteInt(7,12,700);
    EEPROM_WriteInt(7,14,1000);
    EEPROM_WriteInt(7,16,1500);
    EEPROM_WriteInt(7,18,2000);
    EEPROM_WriteInt(7,20,2500);
    EEPROM_WriteInt(7,22,1);
    EEPROM_WriteInt(7,24,500);
//
//
//    //Protection enable  motor para //05-04-2025
    EEPROM_WriteInt(8,0,1);
    EEPROM_WriteInt(8,2,1);
    EEPROM_WriteInt(8,4,1);
    EEPROM_WriteInt(8,6,1);
    EEPROM_WriteInt(8,8,1);
    EEPROM_WriteInt(8,10,1);
    EEPROM_WriteInt(8,12,1);
    EEPROM_WriteInt(8,14,1);
//
//    //Protection limit  motor para //05-04-2025
    EEPROM_WriteInt(9,0,500);
    EEPROM_WriteInt(9,2,7500); // 450-3-5hp,7.5 and above-750
    EEPROM_WriteInt(9,4,1500);  //
    EEPROM_WriteInt(9,6,850);
    EEPROM_WriteInt(9,8,850);
    EEPROM_WriteInt(9,10,850);
    EEPROM_WriteInt(9,12,2000);
    EEPROM_WriteInt(9,14,2500);
    EEPROM_WriteInt(9,16,300);
    EEPROM_WriteInt(9,18,3000);
    EEPROM_WriteInt(9,20,4500);
    EEPROM_WriteInt(9,22,10);
    EEPROM_WriteInt(9,24,100);
    EEPROM_WriteInt(9,26,1);
    EEPROM_WriteInt(9,28,3000);
    EEPROM_WriteInt(9,30,10);
    EEPROM_WriteInt(9,32,600);
    EEPROM_WriteInt(9,34,9600);//Max_PV_PPWER
    EEPROM_WriteInt(9,36,160);//MAX_PV_CURRENT
    EEPROM_WriteInt(9,38,160);//MAX_OUTPUT_CURRENT


//
//    //PID control parameters IM motor para //05-04-2025
//    EEPROM_WriteInt(10,0,1);
//    EEPROM_WriteInt(10,2,1);
//    EEPROM_WriteInt(10,4,1);
//    EEPROM_WriteInt(10,6,1);
//
//
//    //PID control parameters P motor para //05-04-2025
    EEPROM_WriteInt(11,0,180);//MAX_FREQ_SET_PM
    EEPROM_WriteInt(11,2,0);//FLAG_PARK_EEPROM
    EEPROM_WriteInt(11,4,2);//SPEED_KP_PM
    EEPROM_WriteInt(11,6,5);//SPEED_KI_PM
    EEPROM_WriteInt(11,8,0);//PMSM_THETA_FACTOR
    EEPROM_WriteInt(11,10,500);//PMSM_MIN_RPM
    EEPROM_WriteInt(11,12,30);//INIT_RAMP_TIME_PMSM
    EEPROM_WriteInt(11,14,30);//INIT_VOLTPERCENT_FACTOR
    EEPROM_WriteInt(11,16,250);//TORQUE_LIMIT_PM
    EEPROM_WriteInt(11,18,0);//ID_REF_PM
    EEPROM_WriteInt(11,20,50);//CURRENT_KP
    EEPROM_WriteInt(11,22,3000);//CURRENT_KI
    EEPROM_WriteInt(11,24,50);//CURR_ERROR_LIMIT_PM
    EEPROM_WriteInt(11,26,430);//VOLT_OUTPUT_LIMIT_PM
    EEPROM_WriteInt(11,28,250);//START_CURRRENT_LIMIT
    EEPROM_WriteInt(11,30,226);//ISTART_PM_FACTOR
    EEPROM_WriteInt(11,32,50);//VFD_VDC_STEP 1/10
    EEPROM_WriteInt(11,34,10);//VFD_VDC_KP//  1/100
    EEPROM_WriteInt(11,36,1);//VFD_VDC_KI//  1/100
//
//
//    //PID control parameters SynRM motor para //05-04-2025
//    EEPROM_WriteInt(12,0,1);
//    EEPROM_WriteInt(12,2,1);
//    EEPROM_WriteInt(12,4,1);
//    EEPROM_WriteInt(12,6,1);
//
//    // Device control para //05-04-2025
//    EEPROM_WriteInt(13,0,1);
//    EEPROM_WriteInt(13,2,1);
//    EEPROM_WriteInt(13,4,0);
    EEPROM_WriteInt(13,6,0);
//    EEPROM_WriteInt(13,8,0);
//    EEPROM_WriteInt(13,10,0);
    EEPROM_WriteInt(13,12,1);
    EEPROM_WriteInt(13,14,3200);
//    EEPROM_WriteInt(13,16,1);
//    EEPROM_WriteInt(13,18,50);
//    EEPROM_WriteInt(13,20,1);
//    EEPROM_WriteInt(13,22,0);
//    EEPROM_WriteInt(13,24,0);
//    EEPROM_WriteInt(13,26,0);
//    EEPROM_WriteInt(13,28,0);
//    EEPROM_WriteInt(13,30,0);
//    EEPROM_WriteInt(13,32,0);
//    EEPROM_WriteInt(13,34,0);
//
//    // Solar Parameters 05-04-2025
    EEPROM_WriteInt(14,0,600);
    EEPROM_WriteInt(14,2,4500);//5hp- 450, 10hp/15hp -750
    EEPROM_WriteInt(14,4,4500);
    EEPROM_WriteInt(14,6,120);//3hp-12,10/15hp - 15A
    EEPROM_WriteInt(14,8,4800);//3hp-3000,5hp-4800,7.5-6750,,10 - 9000,12.5hp-11500, 15hp-13500
    EEPROM_WriteInt(14,10,300);
    EEPROM_WriteInt(14,12,2000);

    /*
//    EEPROM_WriteInt(14,14,5000);
//    EEPROM_WriteInt(14,16,5000);
//    EEPROM_WriteInt(14,18,2000);*/
//
//    // Pump Parameters 05-04-2025-these parameters are for 3HP, need to confirm and change later for higher power rating
    EEPROM_WriteInt(15,0,500);
    EEPROM_WriteInt(15,2,500);
    EEPROM_WriteInt(15,4,1200);
    EEPROM_WriteInt(15,6,800);
    EEPROM_WriteInt(15,8,1800);
    EEPROM_WriteInt(15,10,1200);
    EEPROM_WriteInt(15,12,2500);
    EEPROM_WriteInt(15,14,2200);
    EEPROM_WriteInt(15,16,3000);
    EEPROM_WriteInt(15,18,2500);
    EEPROM_WriteInt(15,20,1000);
  //
//    // Cumulative Parameters 05-04-2025
    EEPROM_WriteFloat(16,0,0);
    EEPROM_WriteFloat(16,2,0);
    EEPROM_WriteFloat(16,4,0);
//
//
////    EEPROM_WriteInt(7,24,500);    // SPEED_RPM_REF_UI
////    EEPROM_WriteInt(7,0,3);    // speed_mode_select

}
void EEPROM_All_Data_Read(void){

    //EEPROM_ReadByte(unsigned int Page_Number, unsigned char eeprom_Address)

    /*4*///FACTORY_MODE                           = EEPROM_ReadByte(2,0);
    /*5*///LANGUAGE_SELECTED                      = EEPROM_ReadByte(2,2);
    /*5*///ACCESS_ENABLE                          = EEPROM_ReadByte(2,4);
    /*5*///PASSWORD                               = EEPROM_ReadByte(2,6);
    /*8*/EEPROM_DATA_VALID_FLAG                 = EEPROM_ReadInt(2,8);
    Retry_time_Minutes_EEPROM                   = EEPROM_ReadInt(2,10);
    MASTER_ON_OFF                               = EEPROM_ReadInt(2,12);
 //   Firmware_Version                            = EEPROM_ReadInt(2,12);

    Device_State_Type                           = EEPROM_ReadInt(2,26);
    Device_Type                                 = EEPROM_ReadInt(2,28);
    Device_Sr_No                                = EEPROM_ReadInt(2,30);
    Date_Code                                   = EEPROM_ReadInt(2,32);



    // Application Parameter
    MOTOR_TYPE                             = EEPROM_ReadInt(3,0);
    APPLICATION_MODE                       = EEPROM_ReadInt(3,2);
    CONTROL_MODE                           = EEPROM_ReadInt(3,4);


    /*
     * Motor Parameter IM
     */

    RATED_VOLT_IM                          = EEPROM_ReadInt(4,0) * ONE_BY_TEN;
    RATED_CURR_IM                          = EEPROM_ReadInt(4,2) * ONE_BY_TEN;
    RATED_FREQ_IM                          = EEPROM_ReadInt(4,4);
    RATED_OMEGA_IM                         = EEPROM_ReadInt(4,6);
    MOTOR_POWER                            = EEPROM_ReadInt(4,8);// * ONE_BY_HUNDRED;
    RATED_COS_PHI_IM                       = EEPROM_ReadInt(4,10)* ONE_BY_HUNDRED;
    W_Slip_Est                             = EEPROM_ReadInt(4,12)* ONE_BY_HUNDRED;
    Rs                                     = EEPROM_ReadInt(4,14) * ONE_BY_HUNDRED;
    Rr                                     = EEPROM_ReadInt(4,16) * ONE_BY_HUNDRED;
    Llr                                    = EEPROM_ReadInt(4,18) * ONE_BY_TEN_THOUSAND;
    Lls                                    = EEPROM_ReadInt(4,20) * ONE_BY_TEN_THOUSAND;
    Lm                                     = EEPROM_ReadInt(4,22) * ONE_BY_TEN_THOUSAND;
    RATED_POLE_IM                          = EEPROM_ReadInt(4,24);
    TORQUE_PERCENT_IM                      = EEPROM_ReadInt(4,26)* ONE_BY_HUNDRED;

    /*
     * Motor Parameter PM  13-02-2025
     */
    RATED_VOLT_PM                               = EEPROM_ReadInt(5,0) * ONE_BY_TEN;
    RATED_CURR_PM                               = EEPROM_ReadInt(5,2) * ONE_BY_TEN;
    RATED_FREQ_PM                               = EEPROM_ReadInt(5,4);
    RATED_OMEGA_PM                              = EEPROM_ReadInt(5,6) ;//* ONE_BY_TEN;
    MOTOR_POWER_PM                              = EEPROM_ReadInt(5,8);// * ONE_BY_HUNDRED;
    RATED_COS_PHI_PM                            = EEPROM_ReadInt(5,10) * ONE_BY_HUNDRED;
    Rs_PM                                       = EEPROM_ReadInt(5,12) * ONE_BY_HUNDRED;
    Ld_PM                                       = EEPROM_ReadInt(5,14) * ONE_BY_TEN_THOUSAND;
    Lq_PM                                       = EEPROM_ReadInt(5,16) * ONE_BY_TEN_THOUSAND;
    RATED_POLE_PM                               = EEPROM_ReadInt(5,18);
    TORQUE_PERCENT_PM                           = EEPROM_ReadInt(5,20) * ONE_BY_HUNDRED;
    IMP_FACTOR                                  = EEPROM_ReadInt(5,22) * ONE_BY_HUNDRED;


    /*
     * Motor Parameter SynRM  13-02-2025
     */
    /*   RATED_VOLT_SynRM                         = EEPROM_ReadInt(6,0) * ONE_BY_TEN;
     RATED_CURR_SynRM                         = EEPROM_ReadInt(6,2) * ONE_BY_TEN;
     RATED_FREQ_SynRM                         = EEPROM_ReadInt(6,4);
     RATED_OMEGA_SynRM                        = EEPROM_ReadInt(6,6)* ONE_BY_TEN;
     MOTOR_POWER_SynRM                        = EEPROM_ReadInt(6,8) * ONE_BY_HUNDRED;
     RATED_COS_PHI_SynRM                      = EEPROM_ReadInt(6,10)* ONE_BY_HUNDRED;
     W_Slip_Est_SynRM                         = EEPROM_ReadInt(6,12)* ONE_BY_HUNDRED;
     Rs_SynRM                                 = EEPROM_ReadInt(6,14) * ONE_BY_HUNDRED;
     Rr_SynRM                                 = EEPROM_ReadInt(6,16) * ONE_BY_HUNDRED;
     Llr_SynRM                                = EEPROM_ReadInt(6,18) * ONE_BY_TEN_THOUSAND;
     Lls_SynRM                                = EEPROM_ReadInt(6,20) * ONE_BY_TEN_THOUSAND;
     Lm_SynRM                                 = EEPROM_ReadInt(6,22) * ONE_BY_TEN_THOUSAND;
     RATED_POLE_SynRM                         = EEPROM_ReadInt(6,24);
     TORQUE_PERCENT_SynRM                     = EEPROM_ReadInt(6,26)* ONE_BY_HUNDRED;

     Rs_SynRM                               = EEPROM_ReadInt(6,12)* ONE_BY_HUNDRED;
     Ld_SynRM                               = EEPROM_ReadInt(6,14)* ONE_BY_HUNDRED;
     Lq_SynRM                               = EEPROM_ReadInt(6,16)* ONE_BY_HUNDRED;
     RATED_POLE_SynRM                       = EEPROM_ReadInt(6,18);
     TORQUE_PERCENT_SynRM                   = EEPROM_ReadInt(6,20)* ONE_BY_HUNDRED;

     */

    /*
     * speed selection  12-02-2025
     */


    SPEED_MODE_SELECT                       = EEPROM_ReadInt(7,0);
    CONST_SPEED_REF_SOURCE                  = EEPROM_ReadInt(7,2);
    CONST_SPEED_REF_1                       = EEPROM_ReadInt(7,4);
    CONST_SPEED_REF_2                       = EEPROM_ReadInt(7,6);
    CONST_SPEED_REF_3                       = EEPROM_ReadInt(7,8);
    CONST_SPEED_REF_4                       = EEPROM_ReadInt(7,10);
    CONST_SPEED_REF_5                       = EEPROM_ReadInt(7,12);
    CONST_SPEED_REF_6                       = EEPROM_ReadInt(7,14);
    CONST_SPEED_REF_7                       = EEPROM_ReadInt(7,16);
    CONST_SPEED_REF_8                       = EEPROM_ReadInt(7,18);
    CONST_SPEED_REF_9                       = EEPROM_ReadInt(7,20);
    VARIABLE_SPEED_REF_SOURCE               = EEPROM_ReadInt(7,22);
    SPEED_RPM_REF_UI                        = EEPROM_ReadInt(7,24); //Commented temporary for testing 06032025


    /*
     * Protection enable   13-02-2025
     */
    INPUT_UNBALANCE_LIMIT                   = EEPROM_ReadInt(8,0);
    UV_Enable                               = EEPROM_ReadInt(8,2);
    OV_Enable                               = EEPROM_ReadInt(8,4);
    OVER_TEMP_Enable                        = EEPROM_ReadInt(8,6);
    OC_Enable                               = EEPROM_ReadInt(8,8);
    Over_Load_enable                      = EEPROM_ReadInt(8,10);
    Over_Speed_Enable                       = EEPROM_ReadInt(8,12);
    DRY_Run_Enable                          = EEPROM_ReadInt(8,14);


    /*
     * Protection limits   13-02-2025
     */

    INPUT_VOLT_UNBALANCE_LIMIT              = EEPROM_ReadInt(9,0)* ONE_BY_TEN;
    DC_BUS_OV_LIMIT                         = EEPROM_ReadInt(9,2)* ONE_BY_TEN;
    DCBUS_UNDER_VOLT                        = EEPROM_ReadInt(9,4)* ONE_BY_TEN;
    VFD_OVER_TEMP_LIMIT                     = EEPROM_ReadInt(9,6)* ONE_BY_TEN;
    VFD_OVER_TEMP_LIMIT_1                   = EEPROM_ReadInt(9,8)* ONE_BY_TEN;
    VFD_OVER_TEMP_LIMIT_2                   = EEPROM_ReadInt(9,10)* ONE_BY_TEN;
    OVER_CURR_LIMIT                         = EEPROM_ReadInt(9,12)* ONE_BY_HUNDRED;
    MAX_CURR_LIMIT                          = EEPROM_ReadInt(9,14)* ONE_BY_HUNDRED;
    DRY_RUN_CURR_LIMIT                      = EEPROM_ReadInt(9,16)* ONE_BY_HUNDRED;
    DRY_RUN_POWER_LIMIT                     = EEPROM_ReadInt(9,18);//* ONE_BY_TEN;
    VFD_OVER_VOLT_LIMIT                     = EEPROM_ReadInt(9,20)* ONE_BY_TEN;
    Torue_MIN                               = EEPROM_ReadInt(9,22)* ONE_BY_TEN;
    Torque_Max                              = EEPROM_ReadInt(9,24)* ONE_BY_TEN;
    Speed_Min                               = EEPROM_ReadInt(9,26);//* ONE_BY_HUNDRED;
    Speed_Max                               = EEPROM_ReadInt(9,28);//* ONE_BY_HUNDRED;
    Freq_Min                                = EEPROM_ReadInt(9,30)* ONE_BY_TEN;
    Freq_Max                                = EEPROM_ReadInt(9,32)* ONE_BY_TEN;
    MAX_SOLAR_POWER                         = EEPROM_ReadInt(9,34);
    I_PV_MAX                                = EEPROM_ReadInt(9,36)* ONE_BY_TEN;
    MAX_OUTPUT_CURRENT                      = EEPROM_ReadInt(9,38)* ONE_BY_TEN;


    /*
     * PID control parameter IM   13-02-2025
     */
    //    FluxErrorPI_Kp                          = EEPROM_ReadInt(10,0);
    //    FluxErrorPI_Ki                          = EEPROM_ReadInt(10,2);
    //    Flux_Error_Max_IM                       = EEPROM_ReadInt(10,4);
    //    Flux_Error_PI_Max_IM                    = EEPROM_ReadInt(10,6);


    /*
     * PID control parameter PMSM   25-06-2025
     */
    MAX_FREQ_SET_PM                             = EEPROM_ReadInt(11,0)*1;
    FLAG_PARK_EEPROM                            = EEPROM_ReadInt(11,2)*1;
    SPEED_KP_PM                                 = EEPROM_ReadInt(11,4)*0.01;
    SPEED_KI_PM                                 = EEPROM_ReadInt(11,6)*0.001;
    PMSM_THETA_FACTOR                           = EEPROM_ReadInt(11,8)*0.1;
    PMSM_MIN_RPM                                = EEPROM_ReadInt(11,10)*1;
    INIT_RAMP_TIME_PMSM                         = EEPROM_ReadInt(11,12)*0.1;
    INIT_VOLTPERCENT_FACTOR                     = EEPROM_ReadInt(11,14)*0.01;
    TORQUE_LIMIT_PM                             = EEPROM_ReadInt(11,16)*0.1;
    ID_REF_PM                                   = EEPROM_ReadInt(11,18)*0.1;
    CURRENT_KP_PM                               = EEPROM_ReadInt(11,20)*0.1;
    CURRENT_KI_PM                               = EEPROM_ReadInt(11,22)*0.1;
    CURR_ERROR_LIMIT_PM                         = EEPROM_ReadInt(11,24)*0.1;
    VOLT_OUTPUT_LIMIT_PM                        = EEPROM_ReadInt(11,26)*1;
    ISTART_PM_LIMIT                             = EEPROM_ReadInt(11,28)*0.1;
    ISTART_PM_FACTOR                            = EEPROM_ReadInt(11,30)*0.1;
    VFD_VDC_STEP                                = EEPROM_ReadInt(11,32)*0.1;
    VFD_VDC_KP                                  = EEPROM_ReadInt(11,34)*ONE_BY_HUNDRED;
    VFD_VDC_KI                                  = EEPROM_ReadInt(11,36)*ONE_BY_HUNDRED;


    /*
     * PID control parameter SynRM 13-02-2025
     */
    //    FluxErrorPI_Kp_SynRM                    = EEPROM_ReadInt(11,0);
    //    FluxErrorPI_Ki_SynRM                    = EEPROM_ReadInt(12,2);
    //    Flux_Error_Max_SynRM                    = EEPROM_ReadInt(12,4);
    //    Flux_Error_PI_Max_SynRM                 = EEPROM_ReadInt(12,6);


    /*
     * Solar parameters 07-05-2025 (Arjun)
     */
    MAX_FREQ_SET_IM                         = EEPROM_ReadInt(14,0)* ONE_BY_TEN;
    DC_OC_VOLT                              = EEPROM_ReadInt(14,2)* ONE_BY_TEN;
    MAX_DC_VOLT                             = EEPROM_ReadInt(14,4)* ONE_BY_TEN;
    MAX_DC_CURR                             = EEPROM_ReadInt(14,6)* ONE_BY_TEN;
    MAX_OA_POWER                            = EEPROM_ReadInt(14,8);//* ONE_BY_TEN;
    MIN_PV_POWER                            = EEPROM_ReadInt(14,10);//* ONE_BY_TEN;


    /*
     * Pump parameters 04-04-2025
     */
    POW1                                   = EEPROM_ReadInt(15,0);//* ONE_BY_TEN;
    D1                                     = EEPROM_ReadInt(15,2)* ONE_BY_TEN;
    POW2                                   = EEPROM_ReadInt(15,4);//* ONE_BY_TEN;
    D2                                     = EEPROM_ReadInt(15,6)* ONE_BY_TEN;
    POW3                                   = EEPROM_ReadInt(15,8);//* ONE_BY_TEN;
    D3                                     = EEPROM_ReadInt(15,10)* ONE_BY_TEN;
    POW4                                   = EEPROM_ReadInt(15,12);//* ONE_BY_TEN;
    D4                                     = EEPROM_ReadInt(15,14)* ONE_BY_TEN;
    POW5                                   = EEPROM_ReadInt(15,16);//* ONE_BY_TEN;
    D5                                     = EEPROM_ReadInt(15,18)* ONE_BY_TEN;
    Head                                   = EEPROM_ReadInt(15,20)* ONE_BY_TEN;

    Total_Energy_Ref                       = EEPROM_ReadFloat(16,0);//* ONE_BY_TEN_THOUSAND;
    Total_Water_Discharge_Ref              = EEPROM_ReadFloat(16,2);//* ONE_BY_TEN_THOUSAND;
    Total_Time_Ref                         = EEPROM_ReadFloat(16,4);//*ONE_BY_THOUSAND;

    /*
     * Pump parameters 04-04-2025
     */
//    Cumulative_Energy                                  = EEPROM_ReadInt(16,0)* ONE_BY_TEN;
//    Cummulative_Water_Discharge                        = EEPROM_ReadInt(16,2)* ONE_BY_TEN;
//    Cumulative_Run_Hrs                                  = EEPROM_ReadInt(16,4);//* ONE_BY_TEN;
   // case_state                        = EEPROM_ReadFloat(17,0);
    Test_Var1                         = EEPROM_ReadInt(17,2);
    Test_Var2                         = EEPROM_ReadInt(17,4);

    /*
     * Device Control parameters 13-02-2025
     */
    //    RMT_LOC_CTRL                            = EEPROM_ReadInt(13,0);
    //    FAN_CTRL                                = EEPROM_ReadInt(13,2);
    //    PHASE_ORDER                             = EEPROM_ReadInt(13,4);
          FLT_RST                                 = EEPROM_ReadInt(13,6);//need to change in future
    //    MEM_ER_FLG                              = EEPROM_ReadInt(13,8);
    //    MOTOR_ON_OFF                            = EEPROM_ReadInt(13,10);
          DIR_ROTATION                            = EEPROM_ReadInt(13,12);//need to change in future
          SWITCH_FREQ                             = EEPROM_ReadInt(13,14);
    //    SWITCH_FREQ_MULT                        = EEPROM_ReadInt(13,16);
    //    UF_RATIO                                = EEPROM_ReadInt(13,18);
    //    FREQ_REF_IP_SEL                         = EEPROM_ReadInt(13,20);
    //    RUN_CMD_IP_SEL                          = EEPROM_ReadInt(13,22);
    //    STOP_METHOD_SEL                         = EEPROM_ReadInt(13,24);
    //    JOG_SEL                                 = EEPROM_ReadInt(13,26);
    //    DWELL_REF_START                         = EEPROM_ReadInt(13,28);
    //    DWELL_TIME_START                        = EEPROM_ReadInt(13,30);
    //    DWELL_FREQ_STOP                         = EEPROM_ReadInt(13,32);
    //    DWELL_TIME_STOP                         = EEPROM_ReadInt(13,34);


          INVERTER_PERIOD_EEPROM = 120000000/(SWITCH_FREQ*2);
          EALLOW;
          EPwm5Regs.TBPRD                     = INVERTER_PERIOD_EEPROM;
          EPwm6Regs.TBPRD                     = INVERTER_PERIOD_EEPROM;
          EPwm7Regs.TBPRD                     = INVERTER_PERIOD_EEPROM;
          EDIS;



}





void ConfigureEEprom(void){
    I2C_init();
    eeprom_slave_address = ( (eeprom_24xx64_control_word << 3) | eeprom_24xx64_pin_address );
}

void I2C_init(void){

    EALLOW;
    I2cbRegs.I2CMDR.bit.IRS     = 0x0;          // Put I2C into reset/disable before configuration

    I2cbRegs.I2CPSC.all         = 0x0B;         // Pre-scaler - To get 10 MHz on module CLK (120MHz / (11+1))
    I2cbRegs.I2CCLKL            = 0x2D;         // To get 100kHz SCL
    I2cbRegs.I2CCLKH            = 0x2D;         // To get 100kHz SCL

    I2cbRegs.I2CMDR.bit.MST     = 0x1;          // Configure Master
    I2cbRegs.I2CMDR.bit.TRX     = 0x1;          // Configure as a Transmitter
    I2cbRegs.I2CMDR.bit.BC      = 0x0;          // Set the bit count to 8 bits per data byte
    I2cbRegs.I2CMDR.bit.RM      = 0x0;          // Repeat mode is disabled

    I2cbRegs.I2CCNT             = 0x3;          // Set data count
    I2cbRegs.I2CMDR.bit.FREE    = 0x1;          // Set emulation mode to FREE

    I2cbRegs.I2CSTR.all         = 0xFFFF;       // Clear all status
    I2cbRegs.I2CIER.all         = 0x00;         // Disable all I2C related interrupts

    I2cbRegs.I2CMDR.bit.IRS     = 0x1;          // Take I2C out of reset
    EDIS;
}

void wait_i2c_stpbit_clear(void){
    Uint32 while_break_time = mSeconds;
    while(I2cbRegs.I2CMDR.bit.STP !=0x0){
        if(SysTime_mSec_IntervalElapsed(while_break_time, 10)){
            i2c_fail_count++;
            break;//generate I2C error code
        }
    }
}

void wait_i2c_busbusy_clear(void){
    Uint32 while_break_time = mSeconds;
    while(I2cbRegs.I2CSTR.bit.BB !=0x0){
        if(SysTime_mSec_IntervalElapsed(while_break_time, 10)){
            i2c_fail_count++;
            break;//generate I2C error code
        }
    }
}

void wait_i2c_bytesent_set(void){
    Uint32 while_break_time = mSeconds;
    while(I2cbRegs.I2CSTR.bit.BYTESENT != 0x1){
        if(SysTime_mSec_IntervalElapsed(while_break_time, 10)){
            i2c_fail_count++;
            break;//generate I2C error code
        }
    }
}

void wait_i2c_xrdybit_set(void){
    Uint32 while_break_time = mSeconds;
    while(I2cbRegs.I2CSTR.bit.XRDY != 0x1){
        if(SysTime_mSec_IntervalElapsed(while_break_time, 10)){
            i2c_fail_count++;
            break;//generate I2C error code
        }
    }
}

void wait_i2c_rrdybit_set(void){
    Uint32 while_break_time = mSeconds;
    while(I2cbRegs.I2CSTR.bit.RRDY != 0x1){
        if(SysTime_mSec_IntervalElapsed(while_break_time, 10)){
            i2c_fail_count++;
            break;//generate I2C error code
        }
    }
}

void EEPROM_WriteByte(unsigned char eeprom_page_number, unsigned char eeprom_address, unsigned char eeprom_data){

    unsigned int eeprom_physical_address   =   0x0000;

    if( (eeprom_page_number >= eeprom_24xx64_byte_start_page) && \
            (eeprom_page_number <= eeprom_24xx64_byte_end_page) && \
            (eeprom_address <= eeprom_24xx64_byted_per_page) ){

        eeprom_physical_address    =   (eeprom_page_number<<7) | (eeprom_address);

        wait_i2c_stpbit_clear();
        wait_i2c_busbusy_clear();
        EEPROM_WriteByte_24XX64(eeprom_slave_address, eeprom_physical_address, eeprom_data);
    }
    else{
        //wrong address input
    }

    return;
}

void EEPROM_WriteInt(unsigned char eeprom_page_number, unsigned char eeprom_address, unsigned int eeprom_data){

    unsigned char eeprom_data_l   =   0x00, eeprom_data_h   =   0x00;
    unsigned int eeprom_physical_address   =   0x0000;

    if( (eeprom_page_number >= eeprom_24xx64_int_start_page) && \
            (eeprom_page_number <= eeprom_24xx64_int_end_page) && \
            (eeprom_address <= eeprom_24xx64_byted_per_page-1)){

        eeprom_physical_address =   (eeprom_page_number<<7) | (eeprom_address);
        eeprom_data_l           =   (unsigned char)(eeprom_data & 0X00FF);
        eeprom_data_h           =   (unsigned char)((eeprom_data & 0XFF00)>>8);

        wait_i2c_stpbit_clear();
        wait_i2c_busbusy_clear();
        EEPROM_WriteByte_24XX64(eeprom_slave_address, eeprom_physical_address, eeprom_data_h);

        wait_i2c_busbusy_clear();
        EEPROM_WriteByte_24XX64(eeprom_slave_address, eeprom_physical_address+1, eeprom_data_l);
    }
    else{
        //wrong address input
    }

    return;
}

void EEPROM_WriteFloat(unsigned char eeprom_page_number, unsigned char eeprom_address, float eeprom_data){

    unsigned char eeprom_data_f[4]  =   {0,0,0,0};
    unsigned int eeprom_physical_address   =   0x0000;
    unsigned long d = *(unsigned long *)&eeprom_data;

    if( (eeprom_page_number >= eeprom_24xx64_float_start_page) && \
            (eeprom_page_number <= eeprom_24xx64_float_end_page) && \
            (eeprom_address <= eeprom_24xx64_byted_per_page-3)){

        eeprom_physical_address =   (eeprom_page_number<<7) | (eeprom_address);
        eeprom_data_f[3]        =   (unsigned char)(d & 0X000000FF);            // LS byte
        eeprom_data_f[2]        =   (unsigned char)((d & 0X0000FF00)>>8);
        eeprom_data_f[1]        =   (unsigned char)((d & 0X00FF0000)>>16);
        eeprom_data_f[0]        =   (unsigned char)((d & 0XFF000000)>>24);      // MS byte

        wait_i2c_stpbit_clear();
        wait_i2c_busbusy_clear();
        EEPROM_WriteByte_24XX64(eeprom_slave_address, eeprom_physical_address, eeprom_data_f[0]);

        wait_i2c_busbusy_clear();
        EEPROM_WriteByte_24XX64(eeprom_slave_address, eeprom_physical_address+1, eeprom_data_f[1]);

        wait_i2c_busbusy_clear();
        EEPROM_WriteByte_24XX64(eeprom_slave_address, eeprom_physical_address+2, eeprom_data_f[2]);

        wait_i2c_busbusy_clear();
        EEPROM_WriteByte_24XX64(eeprom_slave_address, eeprom_physical_address+3, eeprom_data_f[3]);
    }
    else{
        //wrong address input
    }

    return;
}

void EEPROM_WriteByte_24XX64(unsigned char slaveAddr,unsigned int address, unsigned char data){

    unsigned char address_wh, address_wl;

    address     = address &0xFFFF;
    address_wh  = ((address>>8) & 0x00FF);
    address_wl  = (address & 0X00FF);

    I2cbRegs.I2CSAR.all         = slaveAddr;            // Slave address
    I2cbRegs.I2CMDR.bit.MST     = 0x1;                  // Configure Master
    I2cbRegs.I2CMDR.bit.TRX     = 0x1;                  // Configure as a Transmitter
    I2cbRegs.I2CCNT             = 0x03;                 // Set data count
    I2cbRegs.I2CMDR.bit.STT     = 0x1;                  // send Start condition

    wait_i2c_xrdybit_set();                             // wait till transmission is ready

    I2cbRegs.I2CDXR.all         = address_wh;           // send eeprom address higher byte
    wait_i2c_bytesent_set();                            // wait till byte is sent
    I2cbRegs.I2CSTR.bit.BYTESENT= 0x1;

    I2cbRegs.I2CDXR.all         = address_wl;           // send eeprom address lower byte
    wait_i2c_bytesent_set();                            // wait till byte is sent
    I2cbRegs.I2CSTR.bit.BYTESENT= 0x1;

    I2cbRegs.I2CDXR.all         = data;                 // send eeprom data 1 byte
    wait_i2c_bytesent_set();                            // wait till byte is sent
    I2cbRegs.I2CSTR.bit.BYTESENT= 0x1;

    I2cbRegs.I2CMDR.bit.STP     = 0x1;                  // send stop condition
    wait_i2c_stpbit_clear();
    I2cbRegs.I2CSTR.bit.BYTESENT= 0x1;
    DELAY_US(5000);
}


unsigned char EEPROM_ReadByte(unsigned char eeprom_page_number, unsigned char eeprom_address){

    unsigned char eeprom_data = 0xFE;
    unsigned int eeprom_physical_address   =   0x0000;

    if( (eeprom_page_number >= eeprom_24xx64_byte_start_page) && \
            (eeprom_page_number <= eeprom_24xx64_byte_end_page) && \
            (eeprom_address <= eeprom_24xx64_byted_per_page) ){

        eeprom_physical_address    =   (eeprom_page_number<<7) | (eeprom_address);

        wait_i2c_stpbit_clear();
        wait_i2c_busbusy_clear();
        eeprom_data = EEPROM_ReadByte_24XX64(eeprom_slave_address, eeprom_physical_address);
    }
    else{
        //wrong address input
    }

    return eeprom_data;
}

unsigned int EEPROM_ReadInt(unsigned char eeprom_page_number, unsigned char eeprom_address){

    unsigned char eeprom_data_l   =   0xFE, eeprom_data_h   =   0xFE;
    unsigned int eeprom_physical_address   =   0x0000;
    unsigned long eeprom_data = 0x0000;

    if( (eeprom_page_number >= eeprom_24xx64_int_start_page) && \
            (eeprom_page_number <= eeprom_24xx64_int_end_page) && \
            (eeprom_address <= eeprom_24xx64_byted_per_page-1) ){

        eeprom_physical_address    =   (eeprom_page_number<<7) | (eeprom_address);

        wait_i2c_stpbit_clear();
        wait_i2c_busbusy_clear();
        eeprom_data_h = EEPROM_ReadByte_24XX64(eeprom_slave_address, eeprom_physical_address);

        wait_i2c_busbusy_clear();
        eeprom_data_l = EEPROM_ReadByte_24XX64(eeprom_slave_address, eeprom_physical_address+1);
    }
    else{
        //wrong address input
    }

    eeprom_data = (eeprom_data_h <<8) | eeprom_data_l;

    return eeprom_data;
}

float EEPROM_ReadFloat(unsigned char eeprom_page_number, unsigned char eeprom_address){

    unsigned char eeprom_data_f[4] = {0xFE, 0xFE, 0xFE, 0XFE};
    unsigned int eeprom_physical_address   =   0x0000;
    unsigned long d = 0;
    float eeprom_data = 0x00000000;

    if( (eeprom_page_number >= eeprom_24xx64_float_start_page) && \
            (eeprom_page_number <= eeprom_24xx64_float_end_page) && \
            (eeprom_address <= eeprom_24xx64_byted_per_page-3) ){

        eeprom_physical_address    =   (eeprom_page_number<<7) | (eeprom_address);

        wait_i2c_stpbit_clear();
        wait_i2c_busbusy_clear();
        eeprom_data_f[0] = EEPROM_ReadByte_24XX64(eeprom_slave_address, eeprom_physical_address);

        wait_i2c_busbusy_clear();
        eeprom_data_f[1] = EEPROM_ReadByte_24XX64(eeprom_slave_address, eeprom_physical_address+1);

        wait_i2c_busbusy_clear();
        eeprom_data_f[2] = EEPROM_ReadByte_24XX64(eeprom_slave_address, eeprom_physical_address+2);

        wait_i2c_busbusy_clear();
        eeprom_data_f[3] = EEPROM_ReadByte_24XX64(eeprom_slave_address, eeprom_physical_address+3);
    }
    else{
        //wrong address input
    }

    d =  ((long)eeprom_data_f[0] << 24);
    d|=  ((long)eeprom_data_f[1] << 16);
    d|=  ((long)eeprom_data_f[2] << 8);
    d|=  ((long)eeprom_data_f[3]);

    eeprom_data = *(float *)&d;
    return eeprom_data;
}

unsigned char EEPROM_ReadByte_24XX64(unsigned char slaveAddr,unsigned int address){

    unsigned char address_wh, address_wl, data = 0xFE;

    address     = address &0xFFFF;
    address_wh  = ((address>>8) & 0x00FF);
    address_wl  = (address & 0X00FF);

    I2cbRegs.I2CSAR.all         = slaveAddr;            // Slave address
    I2cbRegs.I2CMDR.bit.MST     = 0x1;                  // Configure Master
    I2cbRegs.I2CMDR.bit.TRX     = 0x1;                  // Configure as a Transmitter
    I2cbRegs.I2CCNT             = 0x02;                 // Set data count
    I2cbRegs.I2CMDR.bit.STT     = 0x1;                  // send Start condition

    wait_i2c_xrdybit_set();                             // wait till transmission is ready

    I2cbRegs.I2CDXR.all         =   address_wh;         // send EEPROM address higher byte
    wait_i2c_bytesent_set();                            // wait till byte is sent
    I2cbRegs.I2CSTR.bit.BYTESENT= 0x1;

    I2cbRegs.I2CDXR.all         =   address_wl;         // send EEPROM address lower byte
    wait_i2c_bytesent_set();                            // wait till byte is sent
    I2cbRegs.I2CSTR.bit.BYTESENT= 0x1;

    I2cbRegs.I2CSAR.all         = slaveAddr;            // Slave address
    I2cbRegs.I2CMDR.bit.MST     = 0x1;                  // Configure Master
    I2cbRegs.I2CMDR.bit.TRX     = 0x0;                  // Configure as a Receiver
    I2cbRegs.I2CCNT             = 0x01;                 // Set data count
    I2cbRegs.I2CMDR.bit.STT     = 0x1;                  // send Start condition

    wait_i2c_rrdybit_set();                             // wait for byte receiving
    data = I2cbRegs.I2CDRR.all;                         // Read received data

    I2cbRegs.I2CMDR.bit.STP = 0x1;                      // send stop condition
    wait_i2c_stpbit_clear();
    I2cbRegs.I2CSTR.bit.BYTESENT = 0x1;
    DELAY_US(10000);

    return data;
}
