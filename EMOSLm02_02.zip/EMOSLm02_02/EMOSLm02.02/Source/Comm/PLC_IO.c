/*
 * PLC_IO.c
 *
 *  Created on: 16-Jun-2025
 *      Author: commc
 */

#include <Headers/Project_Header/Init.h>

Uint16 PLC_I_max_Count = 1873, PLC_V_max_Count = 3090, PLC_I_min_Count = 340, PLC_V_min_Count = 2250;// Values based on testing Adc values
Uint16 V_RPM, I_RPM, I_Mean1, I_Mean2, I_Mean3;
bool First = 1;
unsigned char c = 0;
unsigned int Loc_PLC_I_Count;

PLC_Para_DI Parameter_DI[8] = {             //{Parameter_Flag, PLC_DI}
                               {0, 0},      //Free
                               {0, 0},      //FWD ; Run Command in 2WM2/3WM2
                               {0, 0},      //REV ; Run Direction in 2WM2/3WM2
                               {0, 0},      //Three-Wire-Control Command
                               {0, 0},      //SPEED_UP
                               {0, 0}       //SPEED_DOWN
};


void Digital_PLC_Handler(void){

    DELAY_US(50);

  /*  if((Parameter_DI[3].Parameter_FLAG == 1) && (loc_plc[Parameter_DI[1].PLC_DI])){
        FWD_MOMENTARY_FLAG = 1;
        REV_MOMENTARY_FLAG = 0;
    }

    if((Parameter_DI[3].Parameter_FLAG == 1) && (loc_plc[Parameter_DI[2].PLC_DI])){
        REV_MOMENTARY_FLAG = 1;
        FWD_MOMENTARY_FLAG = 0;
    }*/
    PLC_DI3 = loc_plc[2];
    PLC_DI4 = loc_plc[3];
    switch(PLC_Function){
    case 1:
        Two_Wire_Mode1();
        break;
    case 2:
        Two_Wire_Mode2();
        break;
    case 3:
        Float_Switch();
        break;
    /*case 4:
        Three_Wire_Mode2();
        break;*/
    default:
        //nothing();
        break;
    }
}

void Analog_PLC_Handler(){

    Loc_PLC_I_Count = PLC_I_count;  // Reduce noise/more stable

    if(PLC_V_OR_I == 1 && ON_OFF_FLAG == 0){    // 1 for voltage control 0V to 10V
        if(PLC_V_count >= PLC_V_min_Count){
            V_RPM = (unsigned int)(((PLC_V_count - PLC_V_min_Count)*30)/(PLC_V_max_Count - PLC_V_min_Count));   //Normalization between 0 to 30 //and then type-casting for descrete-stable RPM //formula built, to step-up the RPM by 100
            V_RPM *= 100;
        }
        else{
            V_RPM = 0;
        }

        if(V_RPM <= 3000){
            SPEED_RPM_REF_UI = V_RPM;
        }
        else{
            SPEED_RPM_REF_UI = 3000;
        }
    }
    else if(PLC_V_OR_I == 2 && ON_OFF_FLAG == 0){   // 2 for current control 4mA to 20mA
        if(First == 1){
            I_Mean1 = Loc_PLC_I_Count;
            First = 0;;
        }
        else{
            I_Mean1 = ((I_Mean1+Loc_PLC_I_Count)/2);
            I_Mean2 = ((I_Mean2+I_Mean1)/2);
            //I_Mean3 = ((I_Mean3+I_Mean2)/2);
        }

        if(I_Mean2 >= PLC_I_min_Count){
            I_RPM = (unsigned int)(((I_Mean2 - PLC_I_min_Count)*30)/(PLC_I_max_Count - PLC_I_min_Count));   //Normalization between 0 to 30 //and then type-casting for descrete-stable RPM //formula built, to step-up the RPM by 100
            I_RPM *= 100;
        }
        else{
            I_RPM = 0;
        }

        if(I_RPM <= 3000){
            SPEED_RPM_REF_UI = I_RPM;
        }
        else{
            SPEED_RPM_REF_UI = 3000;
        }
    }
    else{
        SPEED_RPM_REF_UI = 0;
    }
}


void Two_Wire_Mode1(){
   // if((Parameter_DI[1].Parameter_FLAG == 1)&&(Parameter_DI[2].Parameter_FLAG == 1)){   // TO check that the FWD and REV is selected or not
//        if((loc_plc[Parameter_DI[1].PLC_DI] == 1)&&(loc_plc[Parameter_DI[2].PLC_DI] == 0)){
        if((loc_plc[2] == 1)&&(loc_plc[3] == 0)){
            if(c != 1){
                if(c != 0){
                    SOFT_STOP_FLAG = 1;
                }
                c = 1;
            }
            PLC_Froward();
        }
//        else if((loc_plc[Parameter_DI[1].PLC_DI] == 0)&&(loc_plc[Parameter_DI[2].PLC_DI] == 1)){
        else if((loc_plc[2] == 0)&&(loc_plc[3] == 1)){
            if(c != 2){
                SOFT_STOP_FLAG = 1;
                c = 2;
            }
            PLC_Reverse();
        }
        else{
            PLC_Stop();
        }
//    }
//    else{
//        // Message that FWD/REV is not selected
//    }
}

void Two_Wire_Mode2(){
  ///  if((Parameter_DI[1].Parameter_FLAG == 1)&&(Parameter_DI[2].Parameter_FLAG == 1)){   // TO check that the FWD and REV is selected or not
//        if(loc_plc[Parameter_DI[1].PLC_DI] == 0){
    if(loc_plc[2] == 0){
            PLC_Stop();
        }
    else if (loc_plc[2] == 1){
        //        if(loc_plc[Parameter_DI[2].PLC_DI] == 0){
        if(loc_plc[3] == 0){
            if(c != 3){
                SOFT_STOP_FLAG = 1;
                c = 3;
            }
            PLC_Froward();
        }
        else if(loc_plc[3] == 1){
            if(c != 4){
                SOFT_STOP_FLAG = 1;
                c = 4;
            }
            PLC_Reverse();
        }
    }
//    }
//    else{
//        // Message that FWD/REV is not selected
//    }
}

/*
void Three_Wire_Mode1(){
    if((Parameter_DI[1].Parameter_FLAG == 1)&&(Parameter_DI[2].Parameter_FLAG == 1)&&(Parameter_DI[3].Parameter_FLAG == 1)){   // TO check that the FWD, REV and 3-Wire Control is selected or not
        if(loc_plc[Parameter_DI[3].PLC_DI] == 0){
            FWD_MOMENTARY_FLAG = 0;
            REV_MOMENTARY_FLAG = 0;
            PLC_Stop();
        }
        else{
            if(FWD_MOMENTARY_FLAG == 1 && REV_MOMENTARY_FLAG == 0){
                FWD_MOMENTARY_FLAG = 0;
                if(c != 5){
                    PLC_Stop();
                    c = 5;
                }
                PLC_Froward();
            }
            if(FWD_MOMENTARY_FLAG == 0 && REV_MOMENTARY_FLAG == 1){
                REV_MOMENTARY_FLAG = 0;
                if(c != 6){
                    PLC_Stop();
                    c = 6;
                }
                PLC_Reverse();
            }
        }
    }
    else{
        // Message that FWD/REV/Command is not selected
    }
}

void Three_Wire_Mode2(){
    if((Parameter_DI[1].Parameter_FLAG == 1)&&(Parameter_DI[2].Parameter_FLAG == 1)&&(Parameter_DI[3].Parameter_FLAG == 1)){   // TO check that the FWD, REV and 3-Wire Control is selected or not
        if(loc_plc[Parameter_DI[3].PLC_DI] == 0){
            PLC_Stop();
            FWD_MOMENTARY_FLAG = 0;
        }
        else{
            if(FWD_MOMENTARY_FLAG == 1){
                if(loc_plc[Parameter_DI[2].PLC_DI] == 0){
                    if(c != 7){
                        SOFT_STOP_FLAG = 1;
                        c = 7;
                    }
                    PLC_Froward();
                }
                else{
                    if(c != 8){
                        SOFT_STOP_FLAG = 1;
                        c = 8;
                    }
                    PLC_Reverse();
                }
            }
        }
    }
    else{
        // Message that FWD/REV/Command is not selected
    }
}

*/

/*
//structure : DI, Parameter, Func, Func_FLAG.
//  First The DIs available are
   DI : DI1, DI2, DI3, DI4, DI5, DI6, DI7, DI8.

   and the functions are
(   Func : 0 : nothing, 1 : Terminal_Control_Mode(2WM1, 2WM2, 3WM1, 3WM2), 3 : JOG, 4 : Multi_Speed_Select, 5 : Speed_Up_Down etc.
 Func_FLAG : {0,0,0,0,0,0,0}.) ??
   Parameter : FWD, REV, STOP, Speed_Up, Speed_Down
   Parameter_Flag : {0,0,0,0,0,0,0,0,0,0...}


//volatile PLC_Parameter Config_DI[8] = {};a
// Array{PLC inputs}, anathor for parameters and maybe more for the func: like 3-Wmode or 2 Wire mode



 *               DI(user)                                -->                     Para(user)
 *                  |                                                                |
 *                  |                                                                |
 *                  v                                                                v
 *            Para(Previous)                                                    DI(Previous)
 *      {Para already set on DI(user)}                     -->               DI already set on Para(user)
 *
 *
 *
 *          -->  First after that check the DI(user) that if it is already has some other Para(Previous) if no then no worry but
 *          -->  If yes then we need to either clear the Para(Previous) from the DI(User) or cancel the operation
 *
 *          -->  then we will check that: is Para(user) is already configured on any DI if no then no worry but
 *          -->  If yes then we need to either clear the DI(Previous) from the Para(User) or cancel the operation
 *
 *          -->  After that we will set the Para(user) to the DI(user). and update the Parameter_DI structure
 *
 *          --> NOTE: we need to update the Parameter_DI structure whenever we are updating/clearing the parameter (maybe it will be done while updating)
 *          -->



Now the below function is ready if you give it the DI and the Function it will first check the availability of both the parameter and the DI then according to the user demand it will link the DI to the Parameter.

To do that we could create 3 shared variable 2 for using in the function and 1 flag which is used to trigger this function. and it should regularly check the Flag and when it is 1 it will run the function once.

 */

bool Configurable_DIOs(unsigned char DI, unsigned char Para){
    unsigned char a;

    for(a = 0;a<6;a++){
        if((Parameter_DI[a].PLC_DI == DI) && (Parameter_DI[a].Parameter_FLAG == 1)){
            // This mean that the DI(user) that you are trying to configure is already configured to some Parameter(Previous) and we need to ask user (prompt DI(user) and Para(Previous)) if he want to change or not?
            // if user said yes then
            //if(Some_Condition){
            Parameter_DI[a].Parameter_FLAG = 0;
            //}
            //else{
            //    return(false);
            //}
        }
    }

    if(Parameter_DI[Para].Parameter_FLAG == true){
        // This mean that the para(user) that you are trying to configure is already configured to some DI(Previous) and we need to ask user (prompt Para(user) and DI(Previous) ) if he want to change or not?
        //if(Some_Condition){
        Parameter_DI[Para].Parameter_FLAG = 0;
        //}
        //else{
        //    return(false);
        //}
    }

    switch(Para){
    case 0:
        // Can have something related to clear that DI
        break;
    case 1:
        Parameter_DI[Para].PLC_DI = DI;
        Parameter_DI[Para].Parameter_FLAG = true;
        break;

    case 2:
        Parameter_DI[DI].PLC_DI = DI;
        Parameter_DI[DI].Parameter_FLAG = true;
        break;

    case 3:
        Parameter_DI[DI].PLC_DI = DI;
        Parameter_DI[DI].Parameter_FLAG = true;
        break;

    case 4:
        Parameter_DI[DI].PLC_DI = DI;
        Parameter_DI[DI].Parameter_FLAG = true;
        break;

    case 5:
        Parameter_DI[DI].PLC_DI = DI;
        Parameter_DI[DI].Parameter_FLAG = true;
        break;

    default:
        //nothing
        break;
    }
    return true;
}

void Speed_Ctrl_Digital(){
    //    if(Some_Speed_Select_FLAG){/*Code*/}
    if((loc_plc[Parameter_DI[4].PLC_DI] == 1) && (ON_OFF_FLAG == 1) && (Parameter_DI[4].Parameter_FLAG == 1)){
        if(SPEED_RPM_REF_UI < 2900){
            SPEED_RPM_REF_UI += 100;                    //Increase by 100 RPM
        }
        else if(SPEED_RPM_REF_UI >= 2900){
            SPEED_RPM_REF_UI = 3000;
        }
    }


    if((loc_plc[Parameter_DI[5].PLC_DI] == 1) && (ON_OFF_FLAG == 1) && (Parameter_DI[5].Parameter_FLAG == 1)){
        if(SPEED_RPM_REF_UI > 100){
            SPEED_RPM_REF_UI -= 100;                    //Decrease by 100 RPM
        }
        else if(SPEED_RPM_REF_UI < 100){
            SPEED_RPM_REF_UI = 0;
        }
    }
    DELAY_US(50000);
}


void PLC_Froward(){
    if(ON_OFF_FLAG == 0){
        DIR_ROTATION = 1;
        ON_OFF_FLAG = 1;
    }
}

void PLC_Reverse(){
    if(ON_OFF_FLAG == 0){
        DIR_ROTATION = 0;
        ON_OFF_FLAG = 1;
    }
}

void PLC_Stop(){
    if(SOFT_STOP_FLAG == 0){
        SOFT_STOP_FLAG = 1;
    }
}


void RELAY1_H(){
    GpioDataRegs.GPASET.bit.GPIO21 = 1;    //EXT_DRY1_DSP/   /GPIO21/   /Relay/   /SET/
}

void RELAY1_L(){
    GpioDataRegs.GPACLEAR.bit.GPIO21 = 1;    //EXT_DRY1_DSP/   /GPIO21/   /Relay/   /CLEAR/
}

void RELAY2_H(){
    GpioDataRegs.GPASET.bit.GPIO22 = 1;    //EXT_DRY2_DSP/   /GPIO22/   /Relay/   /SET/
}

void RELAY2_L(){
    GpioDataRegs.GPACLEAR.bit.GPIO22 = 1;    //EXT_DRY2_DSP/   /GPIO22/   /Relay/   /CLEAR/
}


//void Analog_PLC_Output(){
//    if(PLC_A_Out == 1){
//        DAC = 4090; //0 TO 4090
//    }
//}

void Float_Switch(){

        if((loc_plc[2] == 1)&&(loc_plc[3] == 0)){
            if(c != 1){
                if(c != 0){
                    SOFT_STOP_FLAG = 1;
                }
                c = 1;
            }
            PLC_Froward();
        }

        else if((loc_plc[2] == 0)&&(loc_plc[3] == 1)){
            PLC_Stop();
        }

}
