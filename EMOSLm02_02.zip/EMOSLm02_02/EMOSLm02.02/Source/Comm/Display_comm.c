
#include <Headers/Project_Header/Init.h>


unsigned char slaveAddress = 0x11;
unsigned char *frame;
unsigned char dataFrame[40];
unsigned char response_flag;
                                                                 // stores the index just after most recent FRAME detection.
unsigned int CRC;
const unsigned char recv_buffer_size = 40;//100;//34;
unsigned int address = 0x0000;
unsigned int quantity = 0x0000;
unsigned int data = 0x0000;
float float_temp = 0;
uint32_t int_temp = 0;
Uint16 MODBUS_registers[5];
unsigned char recent_CRC;
void Display_frame_write(unsigned char responseCode){
    unsigned char counter,j,response_length,loop=0;
    unsigned int CRC_response = 0x0000,address2,quantity2;
    unsigned int page_no,Location;
//    uint32_t int_temp;
//    float float_temp;
    unsigned int reg_Add = 0x0000;
    switch(responseCode){                                                                   // frame response generation
    case 0x01:                                                                              //Read Coil status
        address = dataFrame[2];
        address <<= 8;
        address |= dataFrame[3];
        quantity = dataFrame[4];
        quantity <<= 8;
        quantity |= dataFrame[5];

        dataFrame[2] = (quantity % 8)>0?(quantity/8)+1:(quantity/8);                        // generating a response frame
        for(counter = 0;counter<dataFrame[2];counter++){
                                                                                            //registers assigning goes here
        }
        CRC_response = CRC16_MODBUS(dataFrame,3+dataFrame[2]);
        dataFrame[3+dataFrame[2]] = CRC_response & 0x00FF;
        dataFrame[4+dataFrame[2]] = (CRC_response | 0x00FF) >> 8;
        response_length = 5+dataFrame[2];
        break;

    case 0x02:                                                                              //Read dicrete inputs status
        address = dataFrame[2];
        address <<= 8;
        address |= dataFrame[3];
        quantity = dataFrame[4];
        quantity <<= 8;
        quantity |= dataFrame[5];

        dataFrame[2] = (quantity % 8)>0?(quantity/8)+1:(quantity/8);                        // generating a response frame
        for(counter = 0;counter<dataFrame[2];counter++){
                                                                                            //register assigning goes here
        }
        CRC_response = CRC16_MODBUS(dataFrame,3+dataFrame[2]);
        dataFrame[3+dataFrame[2]] = CRC_response & 0x00FF;
        dataFrame[4+dataFrame[2]] = (CRC_response | 0x00FF) >> 8;
        response_length = 5+dataFrame[2];
        break;

    case 0x03:                                                                              //Read multiple holding registers
        address = dataFrame[2];
        address <<= 8;
        address |= dataFrame[3];
        quantity = dataFrame[4];
        quantity <<= 8;
        quantity |= dataFrame[5];

        dataFrame[2] = quantity*2;                                                          // generating a response frame
        reg_Add = address;//Memory_add[loop].modbus_address;
        for(counter = 0;counter<quantity;counter++){
            for( loop = 0;loop<350;loop++ )
            {
                if(reg_Add == Memory_add[loop].modbus_address)
                {
                    if((Memory_add[loop].Var_type == UINT_16)||(Memory_add[loop].Var_type == UINT_8)||(Memory_add[loop].Var_type == UINT_32))
                    {
                        uint32_t *x;
                        x = (uint32_t*)(RAM_OFFSET + reg_Add);
                        int_temp = *x;
                        //*x = *x *Memory_add[loop].Scale_Factor;
                        dataFrame[3 + (2*counter)] = (int_temp >>8)& 0xFF;
                        dataFrame[4 + (2*counter)] = (int_temp)& 0xFF;
                        //                     if(reg_Add == 0x1F00)
                        //                     {
                        int_temp = 0;

                        //                     }
                    }
                    else if (Memory_add[loop].Var_type == FLOAT)
                    {
                        float *x;
                        x = (float*)(RAM_OFFSET + reg_Add);
                        float_temp = *x;
                        int_temp = float_temp*Memory_add[loop].Scale_Factor;
                        //                         temp = *(uint32_t *)&x;
                        //                         *x = *x*10;
                        dataFrame[3 + (2*counter)] = (int_temp >>8)& 0xFF;
                        dataFrame[4 + (2*counter)] = (int_temp)& 0xFF;
                        //                         dataFrame[5 + (2*counter)] = (int_temp <<8)& 0xFF;
                        //                         dataFrame[6 + (2*counter)] = (int_temp)& 0xFF;
                    }

                }
                else
                {
                    //nothing
                }
                // loop++;

            }
            reg_Add = reg_Add+2;

        }
        CRC_response = CRC16_MODBUS(dataFrame,3+dataFrame[2]);
        dataFrame[3+dataFrame[2]] = CRC_response & 0x00FF;
        dataFrame[4+dataFrame[2]] = (CRC_response | 0x00FF) >> 8;
        response_length = 5+dataFrame[2];
        break;

    case 0x04:                                                                              //Read multiple input registers
        address = dataFrame[2];
        address <<= 8;
        address |= dataFrame[3];
        quantity = dataFrame[4];
        quantity <<= 8;
        quantity |= dataFrame[5];

        dataFrame[2] = quantity*2;                                                          // generating a response frame
        for(counter = 0;counter<dataFrame[2];counter++){
            dataFrame[3+(2*counter)] = (MODBUS_registers[counter] | 0x00FF) >> 8;
            dataFrame[4+(2*counter)] = MODBUS_registers[counter] & 0x00FF;
        }
        CRC_response = CRC16_MODBUS(dataFrame,3+dataFrame[2]);
        dataFrame[3+dataFrame[2]] = (CRC_response >> 8) & 0x00FF;    // changed by satish ************
        dataFrame[4+dataFrame[2]] = CRC_response & 0x00FF;            //
//        dataFrame[3+dataFrame[2]] = CRC_response & 0x00FF;
//        dataFrame[4+dataFrame[2]] = (CRC_response | 0x00FF) >> 8;
        response_length = 5+dataFrame[2];
        break;

    case 0x05:                                                                              //write a single discrete output
        address = dataFrame[2];
        address <<= 8;
        address |= dataFrame[3];
        data = dataFrame[4];
        data <<= 8;
        data |= dataFrame[5];

        //playing with data goes here

        response_length = 8;
        break;

    case 0x06:                                                                              //write single holding register
        address = dataFrame[2];
        address <<= 8;
        address |= dataFrame[3];
        data = dataFrame[4];
        data <<= 8;
        data |= dataFrame[5];
        reg_Add = address;

        for( loop = 0;loop<350;loop++ )
        {
            if(reg_Add == Memory_add[loop].modbus_address)
            {


                if((ON_OFF_FLAG == 0)&&(reg_Add<0x1F00)){
                    page_no = (reg_Add/256)+2;
                    Location = (reg_Add%256);
                    if((Memory_add[loop].Var_type == UINT_16)||(Memory_add[loop].Var_type == UINT_8)||(Memory_add[loop].Var_type == UINT_32)){
                        uint32_t *x;
                        unsigned char int_data[2];
                        x = (uint32_t*)(RAM_OFFSET + reg_Add);

                        int_data[0] = dataFrame[4];
                        int_data[1] = dataFrame[5];
                        *x = int_data[0];
                        *x = (*x<<8)|int_data[1];
                     //   if(reg_Add != 0x0000){
                            EEPROM_WriteInt(page_no,Location,*x);
                            *x = *x /Memory_add[loop].Scale_Factor;
                     //   }
                        if(reg_Add == 0x000C){
                            //P_PV_Avg_DELAY_TIMER = Minute_Count;
                            //MASTER_ON_OFF = 1;
                           // EEPROM_WriteInt(2,12,1);   //  MASTER_ON_OFF
                            P_PV_Avg_DELAY_TIMER = Minute_Count;
                            ON_OFF_FLAG    = 1;
                            Exit_Count_SS = Minute_Count;
                        }

                    }
                    else if (Memory_add[loop].Var_type == FLOAT){
                        float *x;
                        uint32_t y;
                        unsigned char float_data[2];
                        x = (float*)(RAM_OFFSET + reg_Add);
                        float_data[0] = dataFrame[4];
                        float_data[1] = dataFrame[5];
                        y = float_data[0];
                        y = (y<<8)|float_data[1];
                        EEPROM_WriteInt(page_no,Location,y);
                        *x = (float)y;
                        *x = *x /Memory_add[loop].Scale_Factor;

                        if(reg_Add == 0x0B0E){
                            INVERTER_PERIOD_EEPROM = 120000000/(SWITCH_FREQ*2);
                            EALLOW;
                            EPwm5Regs.TBPRD                     = INVERTER_PERIOD_EEPROM;
                            EPwm6Regs.TBPRD                     = INVERTER_PERIOD_EEPROM;
                            EPwm7Regs.TBPRD                     = INVERTER_PERIOD_EEPROM;
                            EDIS;
                        }
                    }
                    //Variable_Init();
                }
                else
                {
                    if((Memory_add[loop].Var_type == UINT_16)||(Memory_add[loop].Var_type == UINT_8)||(Memory_add[loop].Var_type == UINT_32)){
                        uint32_t *x;
                        unsigned char int_data[2];
                        x = (uint32_t*)(RAM_OFFSET + reg_Add);

                        int_data[0] = dataFrame[4];
                        int_data[1] = dataFrame[5];
                        *x = int_data[0];
                        *x = (*x<<8)|int_data[1];
                        //EEPROM_WriteInt(page_no,Location,*x);
                        *x = *x /Memory_add[loop].Scale_Factor;
                    }
                    else if (Memory_add[loop].Var_type == FLOAT){
                        float *x;
                        uint32_t y;
                        unsigned char float_data[2];
                        x = (float*)(RAM_OFFSET + reg_Add);
                        float_data[0] = dataFrame[4];
                        float_data[1] = dataFrame[5];
                        y = float_data[0];
                        y = (y<<8)|float_data[1];
                        //  EEPROM_WriteInt(page_no,Location,y);
                        *x = (float)y;
                        *x = *x /Memory_add[loop].Scale_Factor;
                    }
                   // Variable_Init();
                }

            }
            else
            {
                //nothing
            }
            // loop++;

        }
        if(address == 0xAAAA){                                                         // write SPEED_RPM_REF_UI
                            Enter_Serial_Boot_Mode();
                        }
//                     reg_Add = reg_Add+2;

//        response_length = 8;

        CRC_response = CRC16_MODBUS(dataFrame,6);
        dataFrame[6] = CRC_response & 0x00FF;
        dataFrame[7] = (CRC_response >> 8) & 0x00FF;
        response_length = 8;
        break;

    case 0x08:                                                                              //Perform MODBUS diagnostics
        break;

    case 0x0F:                                                                              //Write multiple discrete outputs
        address = dataFrame[2];
        address <<= 8;
        address |= dataFrame[3];
        quantity = dataFrame[4];
        quantity <<= 8;
        quantity |= dataFrame[5];

        for(j=0;j<dataFrame[6];j++){
            data = dataFrame[7+j];

            //Response code goes here

        }

        CRC_response = CRC16_MODBUS(dataFrame,6);
        dataFrame[6] = CRC_response & 0x00FF;
        dataFrame[7] = (CRC_response | 0x00FF) >> 8;
        response_length = 8;
        break;

    case 0x10:                                                                              //write multiple holding registers.
        address = dataFrame[2];
        address <<= 8;
        address |= dataFrame[3];
        quantity = dataFrame[4];
        quantity <<= 8;
        quantity |= dataFrame[5];
        //quantity = quantity*2;
        reg_Add  = address;
        for(j=0;j<quantity;j++){
            data = dataFrame[7+(2*j)];
            data <<= 8;
            data |= dataFrame[8+(2*j)];

            for( loop = 0;loop<350;loop++ )
            {
                if(reg_Add == Memory_add[loop].modbus_address)
                {
                    page_no = (reg_Add/256)+2;
                    Location = (reg_Add%256);
                    if((Memory_add[loop].Var_type == UINT_16)||(Memory_add[loop].Var_type == UINT_8))
                    {
                        uint32_t *x;
                        unsigned char int_data[2];
                        x = (uint32_t*)(RAM_OFFSET + reg_Add);
                        int_data[0] = dataFrame[7+(2*j)];
                        int_data[1] = dataFrame[8+(2*j)];
                        *x = int_data[0];
                        *x = (*x<<8)|int_data[1];
                        EEPROM_WriteInt(page_no,Location,*x);
                        *x = *x /Memory_add[loop].Scale_Factor;
                    }
                    else if (Memory_add[loop].Var_type == FLOAT)
                    {
                        float *x;
                        uint32_t y;
                        unsigned char float_data[2];
                        x = (float*)(RAM_OFFSET + reg_Add);
                        float_data[0] = dataFrame[7+(2*j)];
                        float_data[1] = dataFrame[8+(2*j)];
                        y = float_data[0];
                        y = (y<<8)|float_data[1];
                        EEPROM_WriteInt(page_no,Location,y);
                        *x = (float)y;
                        *x = *x /Memory_add[loop].Scale_Factor;

                    }
                    if(reg_Add == 0x0010){
                        Date_RTC = dataFrame[7]<<8|dataFrame[8];
                        set_date_alone_BQ32(Date_RTC);
                    }
                    else if(reg_Add == 0x0012){
                        Month_RTC = dataFrame[9]<<8|dataFrame[10];
                        set_month_alone_BQ32(Month_RTC);
                    }
                    else if(reg_Add == 0x0014){
                        Year_RTC = dataFrame[11]<<8|dataFrame[12];
                        set_year_alone_BQ32(Year_RTC);
                    }
                    else if(reg_Add == 0x0016){
                        Hour_RTC = dataFrame[7]<<8|dataFrame[8];
                        set_hour_time_BQ32(Hour_RTC);
                    }
                    else if(reg_Add == 0x0018){
                        Minute_RTC = dataFrame[9]<<8|dataFrame[10];
                        set_minute_time_BQ32(Minute_RTC);
                    }
                    //x = x+(2*Memory_add[loop].quantity_reg);
                    //                     x++;
                    //                     address= address+2;
                    //var_type  = Memory_add[loop].Var_type;
                    //                            quantity =  (dataFrame[bfr+4]<<8) & 0xFF;
                    //                            quantity |=  (dataFrame[bfr+5]) & 0xFF;



                }
                else
                {
                    //nothing
                }
                // loop++;

            }
            reg_Add = reg_Add+2;

            //Response code goes here

        }

        CRC_response = CRC16_MODBUS(dataFrame,6);
        dataFrame[6] = CRC_response & 0x00FF;
        dataFrame[7] = (CRC_response | 0x00FF) >> 8;
        response_length = 8;
        break;

    case 0x17:                                                                              //Read/write multiple holding registers
        address = dataFrame[2];
        address <<= 8;
        address |= dataFrame[3];
        quantity = dataFrame[4];
        quantity <<= 8;
        quantity |= dataFrame[5];


        address2 = dataFrame[6];
        address2 <<= 8;
        address2 |= dataFrame[7];
        quantity2 = dataFrame[8];
        quantity2 <<= 8;
        quantity2 |= dataFrame[9];

        for(j=0;j<quantity2;j++){
            data = dataFrame[11+(2*j)];
            data <<= 8;
            data |= dataFrame[12+(2*j)];

            //Write code goes here
        }

        dataFrame[2] = quantity*2;                                                          // generating a response frame
        for(counter = 0;counter<dataFrame[2];counter++){
            dataFrame[3+(2*counter)] = (MODBUS_registers[counter] | 0x00FF) >> 8;
            dataFrame[4+(2*counter)] = MODBUS_registers[counter] & 0x00FF;
        }
        // Read instructions goes here

        CRC_response = CRC16_MODBUS(dataFrame,3+dataFrame[2]);
        dataFrame[3+dataFrame[2]] = CRC_response & 0x00FF;
        dataFrame[4+dataFrame[2]] = (CRC_response | 0x00FF) >> 8;
        response_length = 5+dataFrame[2];
        break;
    }

    Display_scia.tx_target_count = response_length;                                           // Transmit Response Packet
    Display_scia.sci_send_buff = dataFrame;                                                                  // Arjun - Change for Half-duplex mode
    scia_xmit(*Display_scia.sci_send_buff);
    free(Display_scia.sci_send_buff);
    free(Display_scia.sci_recv_buff);
    free(dataFrame);
}

unsigned char Display_frame_read(unsigned char startAddress){
//    unsigned char recent_CRC;
    recent_CRC = startAddress;                                                              // variable to store address of buffer
    unsigned char i = startAddress;



    if((SciaRegs.SCIRXST.bit.RXERROR == 1 ) || (SciaRegs.SCIRXST.bit.FE == 1) || (SciaRegs.SCIRXST.bit.BRKDT == 1)){            //Re-init Display : IN CASE OF FRAME ERROR OR RECEIVE ERROR
        EALLOW;
        scia_fifo_init();
        EDIS;
    }

    while(i!=Display_scia.rx_count){
        response_flag = 0;
        if(Display_scia.sci_recv_buff[i] == slaveAddress){                                    // frame processing begins
            if(Display_scia.sci_recv_buff[(i+1)%recv_buffer_size] == 0x03 ||
                    Display_scia.sci_recv_buff[(i+1)%recv_buffer_size] == 0x06){
                frame = &Display_scia.sci_recv_buff[i];                                       // pointer to start address of frame
                replicateFrame(i,8);                                                        // copy the frame data to a array

                CRC = CRC16_MODBUS(dataFrame,8);                                            // calculate the CRC value of the input packet
                if(CRC == 0x0000){

                    response_flag = Display_scia.sci_recv_buff[(i+1)%recv_buffer_size];       // store a value of function code of frame into a variable
                    i += 7;                                                                 // jump to next address after frame
                    recent_CRC = (i+1)%recv_buffer_size;                                    // store the address of next value after frame of buffer
                    Display_frame_write(response_flag);                                       // frame response generation

                }
            }
            else if(Display_scia.sci_recv_buff[(i+1)%recv_buffer_size] == 0x0F ||
                    Display_scia.sci_recv_buff[(i+1)%recv_buffer_size] == 0x10){
                frame = &Display_scia.sci_recv_buff[i];                                       // pointer to start address of frame
                replicateFrame(i,9+Display_scia.sci_recv_buff[(i+6)%recv_buffer_size]);       // copy the frame data to a array

                CRC = CRC16_MODBUS(dataFrame,9+Display_scia.sci_recv_buff[(i+6)%recv_buffer_size]);// calculate the CRC value of the input packet
                if(CRC == 0x0000){


                    response_flag = Display_scia.sci_recv_buff[(i+1)%recv_buffer_size];       // store a value of function code of frame into a variable
                    i += (8 + Display_scia.sci_recv_buff[(i+6)%recv_buffer_size]);            // jump to next address after frame
                    recent_CRC = (i+1)%recv_buffer_size;                                    // store the address of next value after frame of buffer
                    Display_frame_write(response_flag);                                       // frame response generation

                }
            }
            else if(Display_scia.sci_recv_buff[(i+1)%recv_buffer_size] == 0x17){
                frame = &Display_scia.sci_recv_buff[i];                                       // pointer to start address of frame
                replicateFrame(i,13+Display_scia.sci_recv_buff[(i+10)%recv_buffer_size]);     // copy the frame data to a array

                CRC = CRC16_MODBUS(dataFrame,13+Display_scia.sci_recv_buff[(i+10)%recv_buffer_size]);// calculate the CRC value of the input packet
                if(CRC == 0x0000){


                    response_flag = Display_scia.sci_recv_buff[(i+1)%recv_buffer_size];       // store a value of function code of frame into a variable
                    i += (12 + Display_scia.sci_recv_buff[(i+10)%recv_buffer_size]);          // jump to next address after frame
                    recent_CRC = (i+1)%recv_buffer_size;                                    // store the address of next value after frame of buffer
                    Display_frame_write(response_flag);                                       // frame response generation

                }
            }
        }

        i += 1;
        i %= recv_buffer_size;
    }
    return recent_CRC;
}

void Enter_Serial_Boot_Mode(void){
//    int i=0;

    DINT;
    asm(" NOP");
    DRTM;
    asm(" NOP");

    EALLOW;
    IER = 0x0000;                                                               // Interrupt should be disable before calling the boot loader
    IFR = 0x0000;
    PieCtrlRegs.PIECTRL.bit.ENPIE = 0; // Disable the PIE
    WdRegs.WDCR.all = 0x0068;

        ((void (*)())0x003fe0c4)(0x21);

        asm(" LB   0x000000");
    EDIS;
}
