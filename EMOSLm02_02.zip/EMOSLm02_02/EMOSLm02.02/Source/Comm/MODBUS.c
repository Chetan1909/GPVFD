/*
 * MODBUS.c
 *
 *  Created on: 25-Aug-2023
 *      Author: Dipesh
 */

#include <Headers/Project_Header/Init.h>

unsigned char *frame1;
unsigned char dataFrame1[40];
unsigned char response_flag1;
                                                                 // stores the index just after most recent FRAME detection.
unsigned int CRC1;
const unsigned char recv_buffer_size1 = 40;//100;//34;
unsigned int address1 = 0x0000;
unsigned int quantity1 = 0x0000;
unsigned int data1 = 0x0000;
float float_temp1 = 0;
uint32_t int_temp1 = 0;
Uint16 MODBUS_registers1[5];

void replicateFrame(unsigned char startAddress,unsigned char size){
    unsigned char i = 0;
    for(i=0;i<size;i++){
        dataFrame[i] = Display_scia.sci_recv_buff[(startAddress+i) % recv_buffer_size];
    }
}
void replicate_485Frame(unsigned char startAddress,unsigned char size){
    unsigned char i = 0;
    for(i=0;i<size;i++){
        dataFrame1[i] = RS485_scib.sci_recv_buff[(startAddress+i) % recv_buffer_size1];
    }
}

unsigned int CRC16_MODBUS(unsigned char *buf, int len){
    unsigned int CRC1 = 0xFFFF;
    int pos=0,i=0;
    for (pos = 0; pos < len; pos++){
        CRC1 ^= (unsigned int)buf[pos];                                                      // XOR byte into least sig. byte of CRC1
        for ( i = 8; i != 0; i--)                                                           // Loop over each bit
        {
            if ((CRC1 & 0x0001) != 0)                                                        // If the LSB is set
            {
                CRC1 >>= 1;                                                                  // Shift right and XOR 0xA001
                CRC1 ^= 0xA001;
            }
            else
                CRC1 >>= 1;                                                                  // Just shift right
        }
    }
    return CRC1;
}

void RS485_frame_write(unsigned char responseCode){
    unsigned char counter,j,response_length,loop=0;
    unsigned int CRC_response = 0x0000,address2,quantity2;
    unsigned int page_no,Location;
//    uint32_t int_temp1;
//    float float_temp1;
    unsigned int reg_Add=0x0000;
    MODBUS_registers1[0] = 0xABCD;                                                           //Speed
    MODBUS_registers1[1] = 0x23AE;                                                           //Voltage
    MODBUS_registers1[2] = 0x3742;                                                           //Current
    MODBUS_registers1[3] = 0x9821;                                                           //Frequency
    MODBUS_registers1[4] = 0x9328;                                                           //other attribute

    switch(responseCode){                                                                   // frame response generation
    case 0x01:                                                                              //Read Coil status
        address1 = dataFrame1[2];
        address1 <<= 8;
        address1 |= dataFrame1[3];
        quantity1 = dataFrame1[4];
        quantity1 <<= 8;
        quantity1 |= dataFrame1[5];

        dataFrame1[2] = (quantity1 % 8)>0?(quantity1/8)+1:(quantity1/8);                        // generating a response frame
        for(counter = 0;counter<dataFrame1[2];counter++){
                                                                                            //registers assigning goes here
        }
        CRC_response = CRC16_MODBUS(dataFrame1,3+dataFrame1[2]);
        dataFrame1[3+dataFrame1[2]] = CRC_response & 0x00FF;
        dataFrame1[4+dataFrame1[2]] = (CRC_response | 0x00FF) >> 8;
        response_length = 5+dataFrame1[2];
        break;

    case 0x02:                                                                              //Read dicrete inputs status
        address1 = dataFrame1[2];
        address1 <<= 8;
        address1 |= dataFrame1[3];
        quantity1 = dataFrame1[4];
        quantity1 <<= 8;
        quantity1 |= dataFrame1[5];

        dataFrame1[2] = (quantity1 % 8)>0?(quantity1/8)+1:(quantity1/8);                        // generating a response frame
        for(counter = 0;counter<dataFrame1[2];counter++){
                                                                                            //register assigning goes here
        }
        CRC_response = CRC16_MODBUS(dataFrame1,3+dataFrame1[2]);
        dataFrame1[3+dataFrame1[2]] = CRC_response & 0x00FF;
        dataFrame1[4+dataFrame1[2]] = (CRC_response | 0x00FF) >> 8;
        response_length = 5+dataFrame1[2];
        break;

    case 0x03:                                                                              //Read multiple holding registers
        address1 = dataFrame1[2];
        address1 <<= 8;
        address1 |= dataFrame1[3];
        quantity1 = dataFrame1[4];
        quantity1 <<= 8;
        quantity1 |= dataFrame1[5];

        dataFrame1[2] = quantity1*2;                                                          // generating a response frame
        reg_Add = address1;//Memory_add[loop].modbus_address;
        for(counter = 0;counter<quantity1;counter++){
            /*if((address1+counter) == 0xABCD){                                                // read ON_OFF_FLAG
                dataFrame1[3+(2*counter)] = (ON_OFF_FLAG | 0x00FF) >> 8;
                dataFrame1[4+(2*counter)] = ON_OFF_FLAG & 0x00FF;
            }
            else if((address1+counter) == 0xABCE){                                           // read SPEED_MODE_SELECT
                dataFrame1[3+(2*counter)] = (SPEED_MODE_SELECT | 0x00FF) >> 8;
                dataFrame1[4+(2*counter)] = SPEED_MODE_SELECT & 0x00FF;
            }
            else if((address1+counter) == 0xABCF){                                           // read SPEED_RPM_REF_UI
                dataFrame1[3+(2*counter)] = (SPEED_RPM_REF_UI | 0x00FF) >> 8;
                dataFrame1[4+(2*counter)] = SPEED_RPM_REF_UI & 0x00FF;
            }
            else if((address1+counter) == 0x0100){                                           // read SPEED_RPM_REF_UI
                           dataFrame1[3+(2*counter)] = (MOTOR_TYPE | 0x00FF) >> 8;
                           dataFrame1[4+(2*counter)] = MOTOR_TYPE & 0x00FF;
                       } */
//            dataFrame1[3+(2*counter)] = (* | 0x00FF) >> 8;
//            dataFrame1[4+(2*counter)] = MOTOR_TYPE & 0x00FF;
//            Register_add =  (dataFrame1[bfr+2]<<8) & 0xFF;
//            Register_add |=  (dataFrame1[bfr+3]) & 0xFF;

             for( loop = 0;loop<350;loop++ )
             {
                 if(reg_Add == Memory_add[loop].modbus_address)
                 {
//                     MOTOR_TYPE = 99;
//                     CONTROL_MODE = 100;
//                     RATED_VOLT_IM = 250.35;
//                     RATED_CURR_IM = 123.15;
//                     RATED_FREQ_IM = 100.77;
//                     RATED_OMEGA_IM = 125.468;
//                     MOTOR_POWER = 151.55;
//                     RATED_COS_PHI_IM = 454.00;
//                     W_Slip_Est = 87.99;//Incorrect value
//                     Rs = 5.66;
//                     Rr = 78.5;
//                     Llr = 69.96;
//                     Lls = 123.45;
//                     Lm = 88.28;
//                     RATED_POLE_IM = 121;
//                     TORQUE_PERCENT_IM = 78.54;



                     if((Memory_add[loop].Var_type == UINT_16)||(Memory_add[loop].Var_type == UINT_8))
                     {

                         uint32_t *x;
                         x = (uint32_t*)(RAM_OFFSET + reg_Add);
                         int_temp1 = *x;
                    //*x = *x *Memory_add[loop].Scale_Factor;
                     dataFrame1[3 + (2*counter)] = (int_temp1 >>8)& 0xFF;
                     dataFrame1[4 + (2*counter)] = (int_temp1)& 0xFF;
                     }
                     else if (Memory_add[loop].Var_type == FLOAT)
                     {
                         float *x;
                         x = (float*)(RAM_OFFSET + reg_Add);
                         float_temp1 = *x;
                         int_temp1 = float_temp1*Memory_add[loop].Scale_Factor;
//                         temp = *(uint32_t *)&x;
//                         *x = *x*10;
                         dataFrame1[3 + (2*counter)] = (int_temp1 >>8)& 0xFF;
                         dataFrame1[4 + (2*counter)] = (int_temp1)& 0xFF;
//                         dataFrame1[5 + (2*counter)] = (int_temp1 <<8)& 0xFF;
//                         dataFrame1[6 + (2*counter)] = (int_temp1)& 0xFF;
                     }

                     //x = x+(2*Memory_add[loop].quantity_reg);
//                     x++;
//                     address1= address1+2;
                     //var_type  = Memory_add[loop].Var_type;
                     //                            quantity1 =  (dataFrame1[bfr+4]<<8) & 0xFF;
                     //                            quantity1 |=  (dataFrame1[bfr+5]) & 0xFF;



                 }
                 else
                 {
                     //nothing
                 }
                // loop++;

             }
             reg_Add = reg_Add+2;

        }
        CRC_response = CRC16_MODBUS(dataFrame1,3+dataFrame1[2]);
        dataFrame1[3+dataFrame1[2]] = CRC_response & 0x00FF;
        dataFrame1[4+dataFrame1[2]] = (CRC_response | 0x00FF) >> 8;
        response_length = 5+dataFrame1[2];
        break;

    case 0x04:                                                                              //Read multiple input registers
        address1 = dataFrame1[2];
        address1 <<= 8;
        address1 |= dataFrame1[3];
        quantity1 = dataFrame1[4];
        quantity1 <<= 8;
        quantity1 |= dataFrame1[5];

        dataFrame1[2] = quantity1*2;                                                          // generating a response frame
        for(counter = 0;counter<dataFrame1[2];counter++){
            dataFrame1[3+(2*counter)] = (MODBUS_registers1[counter] | 0x00FF) >> 8;
            dataFrame1[4+(2*counter)] = MODBUS_registers1[counter] & 0x00FF;
        }
        CRC_response = CRC16_MODBUS(dataFrame1,3+dataFrame1[2]);
        dataFrame1[3+dataFrame1[2]] = (CRC_response >> 8) & 0x00FF;    // changed by satish ************
        dataFrame1[4+dataFrame1[2]] = CRC_response & 0x00FF;            //
//        dataFrame1[3+dataFrame1[2]] = CRC_response & 0x00FF;
//        dataFrame1[4+dataFrame1[2]] = (CRC_response | 0x00FF) >> 8;
        response_length = 5+dataFrame1[2];
        break;

    case 0x05:                                                                              //write a single discrete output
        address1 = dataFrame1[2];
        address1 <<= 8;
        address1 |= dataFrame1[3];
        data1 = dataFrame1[4];
        data1 <<= 8;
        data1 |= dataFrame1[5];

        //playing with data1 goes here

        response_length = 8;
        break;

    case 0x06:                                                                              //write single holding register
        address1 = dataFrame1[2];
        address1 <<= 8;
        address1 |= dataFrame1[3];
        data1 = dataFrame1[4];
        data1 <<= 8;
        data1 |= dataFrame1[5];
        reg_Add = address1;

        for( loop = 0;loop<350;loop++ )
        {
            if(reg_Add == Memory_add[loop].modbus_address)
            {
                if((ON_OFF_FLAG == 0)&&(reg_Add<0x1F00)){
                    page_no = (reg_Add/256)+2;
                    Location = (reg_Add%256);
                    if((Memory_add[loop].Var_type == UINT_16)||(Memory_add[loop].Var_type == UINT_8)||(Memory_add[loop].Var_type == UINT_32)){
                        uint32_t *x;
                        unsigned char int_data[2];
                        x = (uint32_t*)(RAM_OFFSET + reg_Add);

                        int_data[0] = dataFrame1[4];
                        int_data[1] = dataFrame1[5];
                        *x = int_data[0];
                        *x = (*x<<8)|int_data[1];
                        EEPROM_WriteInt(page_no,Location,*x);
                        *x = *x /Memory_add[loop].Scale_Factor;
                        if(reg_Add == 0x000C){
                            P_PV_Avg_DELAY_TIMER = Minute_Count;
                            ON_OFF_FLAG    = 1;
                            Exit_Count_SS = Minute_Count;
                        }
                    }
                    else if (Memory_add[loop].Var_type == FLOAT){
                        float *x;
                        uint32_t y;
                        unsigned char float_data[2];
                        x = (float*)(RAM_OFFSET + reg_Add);
                        float_data[0] = dataFrame1[4];
                        float_data[1] = dataFrame1[5];
                        y = float_data[0];
                        y = (y<<8)|float_data[1];
                        EEPROM_WriteInt(page_no,Location,y);
                        *x = (float)y;
                        *x = *x /Memory_add[loop].Scale_Factor;
                    }
                    //Variable_Init();
                }
                else
                {
                    if((Memory_add[loop].Var_type == UINT_16)||(Memory_add[loop].Var_type == UINT_8)||(Memory_add[loop].Var_type == UINT_32)){
                        uint32_t *x;
                        unsigned char int_data[2];
                        x = (uint32_t*)(RAM_OFFSET + reg_Add);

                        int_data[0] = dataFrame1[4];
                        int_data[1] = dataFrame1[5];
                        *x = int_data[0];
                        *x = (*x<<8)|int_data[1];
                        //EEPROM_WriteInt(page_no,Location,*x);
                        *x = *x /Memory_add[loop].Scale_Factor;
                    }
                    else if (Memory_add[loop].Var_type == FLOAT){
                        float *x;
                        uint32_t y;
                        unsigned char float_data[2];
                        x = (float*)(RAM_OFFSET + reg_Add);
                        float_data[0] = dataFrame1[4];
                        float_data[1] = dataFrame1[5];
                        y = float_data[0];
                        y = (y<<8)|float_data[1];
                        //  EEPROM_WriteInt(page_no,Location,y);
                        *x = (float)y;
                        *x = *x /Memory_add[loop].Scale_Factor;
                    }
                    // Variable_Init();
                }

            }
            else
            {
                //nothing
            }
            // loop++;

        }

//                     reg_Add = reg_Add+2;

        response_length = 8;
        break;

    case 0x08:                                                                              //Perform MODBUS diagnostics
        break;

    case 0x0F:                                                                              //Write multiple discrete outputs
        address1 = dataFrame1[2];
        address1 <<= 8;
        address1 |= dataFrame1[3];
        quantity1 = dataFrame1[4];
        quantity1 <<= 8;
        quantity1 |= dataFrame1[5];

        for(j=0;j<dataFrame1[6];j++){
            data1 = dataFrame1[7+j];

            //Response code goes here

        }

        CRC_response = CRC16_MODBUS(dataFrame1,6);
        dataFrame1[6] = CRC_response & 0x00FF;
        dataFrame1[7] = (CRC_response | 0x00FF) >> 8;
        response_length = 8;
        break;

    case 0x10:                                                                              //write multiple holding registers.
        address1 = dataFrame1[2];
        address1 <<= 8;
        address1 |= dataFrame1[3];
        quantity1 = dataFrame1[4];
        quantity1 <<= 8;
            quantity1 |= dataFrame1[5];
        //quantity1 = quantity1*2;
        reg_Add  = address1;
        for(j=0;j<quantity1;j++){
            data1 = dataFrame1[7+(2*j)];
            data1 <<= 8;
            data1 |= dataFrame1[8+(2*j)];

            for( loop = 0;loop<350;loop++ )
            {
                if(reg_Add == Memory_add[loop].modbus_address)
                {
                    page_no = (reg_Add/256)+2;
                    Location = (reg_Add%256);
                    if((Memory_add[loop].Var_type == UINT_16)||(Memory_add[loop].Var_type == UINT_8))
                    {
                        uint32_t *x;
                        unsigned char int_data[2];
                        x = (uint32_t*)(RAM_OFFSET + reg_Add);
                        int_data[0] = dataFrame1[7+(2*j)];
                        int_data[1] = dataFrame1[8+(2*j)];
                        *x = int_data[0];
                        *x = (*x<<8)|int_data[1];
                        EEPROM_WriteInt(page_no,Location,*x);
                        *x = *x /Memory_add[loop].Scale_Factor;
                    }
                    else if (Memory_add[loop].Var_type == FLOAT)
                    {
                        float *x;
                        uint32_t y;
                        unsigned char float_data[2];
                        x = (float*)(RAM_OFFSET + reg_Add);
                        float_data[0] = dataFrame1[7+(2*j)];
                        float_data[1] = dataFrame1[8+(2*j)];
                        y = float_data[0];
                        y = (y<<8)|float_data[1];
                        EEPROM_WriteInt(page_no,Location,y);
                        *x = (float)y;
                        *x = *x /Memory_add[loop].Scale_Factor;

                    }

                    //x = x+(2*Memory_add[loop].quantity_reg);
                    //                     x++;
                    //                     address1= address1+2;
                    //var_type  = Memory_add[loop].Var_type;
                    //                            quantity1 =  (dataFrame1[bfr+4]<<8) & 0xFF;
                    //                            quantity1 |=  (dataFrame1[bfr+5]) & 0xFF;



                }
                else
                {
                    //nothing
                }
                // loop++;

            }
                                 reg_Add = reg_Add+2;

            //Response code goes here

        }

        CRC_response = CRC16_MODBUS(dataFrame1,6);
        dataFrame1[6] = CRC_response & 0x00FF;
        dataFrame1[7] = (CRC_response | 0x00FF) >> 8;
        response_length = 8;
        break;

    case 0x17:                                                                              //Read/write multiple holding registers
        address1 = dataFrame1[2];
        address1 <<= 8;
        address1 |= dataFrame1[3];
        quantity1 = dataFrame1[4];
        quantity1 <<= 8;
        quantity1 |= dataFrame1[5];


        address2 = dataFrame1[6];
        address2 <<= 8;
        address2 |= dataFrame1[7];
        quantity2 = dataFrame1[8];
        quantity2 <<= 8;
        quantity2 |= dataFrame1[9];

        for(j=0;j<quantity2;j++){
            data1 = dataFrame1[11+(2*j)];
            data1 <<= 8;
            data1 |= dataFrame1[12+(2*j)];

            //Write code goes here
        }

        dataFrame1[2] = quantity1*2;                                                          // generating a response frame
        for(counter = 0;counter<dataFrame1[2];counter++){
            dataFrame1[3+(2*counter)] = (MODBUS_registers1[counter] | 0x00FF) >> 8;
            dataFrame1[4+(2*counter)] = MODBUS_registers1[counter] & 0x00FF;
        }
        // Read instructions goes here

        CRC_response = CRC16_MODBUS(dataFrame1,3+dataFrame1[2]);
        dataFrame1[3+dataFrame1[2]] = CRC_response & 0x00FF;
        dataFrame1[4+dataFrame1[2]] = (CRC_response | 0x00FF) >> 8;
        response_length = 5+dataFrame1[2];
        break;
    }

    RS485_scib.tx_target_count = response_length;                                           // Transmit Response Packet
    RS485_scib.sci_send_buff = dataFrame1;
    RS485_TX_EN = true;                                                                     // Arjun - Change for Half-duplex mode
    GpioDataRegs.GPBCLEAR.bit.GPIO32 = 1;                                                   // Arjun - make the RS485_EN pin log to enable RS485 transmission
    scib_xmit(*RS485_scib.sci_send_buff);
    free(RS485_scib.sci_send_buff);
    free(RS485_scib.sci_recv_buff);
    free(dataFrame1);
}

unsigned char RS485_frame_read(unsigned char startAddress){
    unsigned char recent_CRC;
    recent_CRC = startAddress;                                                              // variable to store address1 of buffer
    unsigned char i = startAddress;

    if(RS485_TX_EN == false){
        GpioDataRegs.GPBSET.bit.GPIO32 = 1;                     // make the RS485_EN pin high to enable RS485 receiving
    }else{
        GpioDataRegs.GPBCLEAR.bit.GPIO32 = 1;                                                   // make the RS485_EN pin log to enable RS485 transmission
    }


    if((ScibRegs.SCIRXST.bit.RXERROR == 1 ) || (ScibRegs.SCIRXST.bit.FE == 1) || (ScibRegs.SCIRXST.bit.BRKDT == 1)){            //Re-init RS485 : IN CASE OF FRAME ERROR OR RECEIVE ERROR
        EALLOW;
        scib_fifo_init();
        EDIS;
    }

    while(i!=RS485_scib.rx_count){
        response_flag = 0;
        if(RS485_scib.sci_recv_buff[i] == slaveAddress){                                    // frame processing begins
            if(RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1] == 0x01 ||
                    RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1] == 0x02 ||
                    RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1] == 0x03 ||
                    RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1] == 0x04 ||
                    RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1] == 0x05 ||
                    RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1] == 0x06){
                frame = &RS485_scib.sci_recv_buff[i];                                       // pointer to start address1 of frame
                replicate_485Frame(i,8);                                                        // copy the frame data1 to a array

                CRC1 = CRC16_MODBUS(dataFrame1,8);                                            // calculate the CRC1 value of the input packet
                if(CRC1 == 0x0000){

                    response_flag = RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1];       // store a value of function code of frame into a variable
                    i += 7;                                                                 // jump to next address1 after frame
                    recent_CRC = (i+1)%recv_buffer_size1;                                    // store the address1 of next value after frame of buffer
                    RS485_frame_write(response_flag);                                       // frame response generation

                }
            }
            else if(RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1] == 0x0F ||
                    RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1] == 0x10){
                frame = &RS485_scib.sci_recv_buff[i];                                       // pointer to start address1 of frame
                replicate_485Frame(i,9+RS485_scib.sci_recv_buff[(i+6)%recv_buffer_size1]);       // copy the frame data1 to a array

                CRC1 = CRC16_MODBUS(dataFrame1,9+RS485_scib.sci_recv_buff[(i+6)%recv_buffer_size1]);// calculate the CRC1 value of the input packet
                if(CRC1 == 0x0000){


                    response_flag = RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1];       // store a value of function code of frame into a variable
                    i += (8 + RS485_scib.sci_recv_buff[(i+6)%recv_buffer_size1]);            // jump to next address1 after frame
                    recent_CRC = (i+1)%recv_buffer_size1;                                    // store the address1 of next value after frame of buffer
                    RS485_frame_write(response_flag);                                       // frame response generation

                }
            }
            else if(RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1] == 0x17){
                frame = &RS485_scib.sci_recv_buff[i];                                       // pointer to start address1 of frame
                replicate_485Frame(i,13+RS485_scib.sci_recv_buff[(i+10)%recv_buffer_size1]);     // copy the frame data1 to a array

                CRC1 = CRC16_MODBUS(dataFrame1,13+RS485_scib.sci_recv_buff[(i+10)%recv_buffer_size1]);// calculate the CRC1 value of the input packet
                if(CRC1 == 0x0000){


                    response_flag = RS485_scib.sci_recv_buff[(i+1)%recv_buffer_size1];       // store a value of function code of frame into a variable
                    i += (12 + RS485_scib.sci_recv_buff[(i+10)%recv_buffer_size1]);          // jump to next address1 after frame
                    recent_CRC = (i+1)%recv_buffer_size1;                                    // store the address1 of next value after frame of buffer
                    RS485_frame_write(response_flag);                                       // frame response generation

                }
            }
        }

        i += 1;
        i %= recv_buffer_size1;
    }
    return recent_CRC;
}


