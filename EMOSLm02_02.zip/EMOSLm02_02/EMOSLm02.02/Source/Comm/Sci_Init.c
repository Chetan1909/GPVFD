/*
 * Sci_Init.c
 *
 *  Created on: 26-Jul-2023
 *      Author: Arjun Yadav
 */
/*****************************************ABOUT**********************************************/
/*
 * This file deals with various initializations required for SCI Communication
 * Also it has all the basic level APIs for SCI Communication
 */
/********************************************************************************************/

#include <Headers/Project_Header/Init.h>

unsigned char temp;

struct SCI_VAR RS485_scib;
struct SCI_VAR Display_scia;

void Configure_Display_scia(void){
    scia_fifo_init();                                           //configuring SCI Communication module
//    GpioDataRegs.GPBSET.bit.GPIO32 = 1;                         // make the RS485_EN pin high to enable RS485 receiving
}

void ConfigureRS485(void){
    scib_fifo_init();                                           //configuring SCI Communication module
    GpioDataRegs.GPBSET.bit.GPIO32 = 1;                         // make the RS485_EN pin high to enable RS485 receiving
}

void scia_fifo_init(void){
    Display_scia.BAUD_RATE                = 4;                    //EEPROM_ReadByte(19,6);

    EALLOW;
    SciaRegs.SCICCR.all                 = 0x0007;               // 1 stop bit, Parity Disable, Loop back Disable, 8 char bits, idle-line protocol
    SciaRegs.SCICTL1.all                = 0x0003;               // enable TX, RX // Disable RX ERR, SLEEP Disable // TXWAKE, internal SCICLK
    SciaRegs.SCICTL2.bit.TXINTENA       = 1;                    // TXRDY interrupt Enable
    SciaRegs.SCICTL2.bit.RXBKINTENA     = 1;                    // RXRDY interrupt Enable

    switch(Display_scia.BAUD_RATE){
    case 1:
        SciaRegs.SCIHBAUD.all           = 0x0003;               //4800
        SciaRegs.SCILBAUD.all           = 0x000D;
        break;

    case 2:
        SciaRegs.SCIHBAUD.all           = 0x0001;               //9600
        SciaRegs.SCILBAUD.all           = 0x0086;
        break;

    case 3:
        SciaRegs.SCIHBAUD.all           = 0x0000;               //19200
        SciaRegs.SCILBAUD.all           = 0x00C3;
        break;

    case 4:
        SciaRegs.SCIHBAUD.all           = 0x0000;               //38400
        SciaRegs.SCILBAUD.all           = 0x0061;
        break;

    case 5:
        SciaRegs.SCIHBAUD.all           = 0x0000;               //57600
        SciaRegs.SCILBAUD.all           = 0x0041;
        break;

    case 6:
        SciaRegs.SCIHBAUD.all           = 0x0000;               //115200
        SciaRegs.SCILBAUD.all           = 0x0020;
        break;

    default:
        SciaRegs.SCIHBAUD.all           = 0x0001;               //9600
        SciaRegs.SCILBAUD.all           = 0x0086;
        break;
    }

    SciaRegs.SCIFFTX.all                = 0xC021;
    SciaRegs.SCIFFRX.all                = 0x0021;
    SciaRegs.SCIFFCT.all                = 0x0000;
    SciaRegs.SCICTL1.all                = 0x0023;               // Relinquish SCI from Reset
    SciaRegs.SCIFFTX.bit.TXFIFORESET    = 1;
    SciaRegs.SCIFFRX.bit.RXFIFORESET    = 1;
    EDIS;
}

void scia_xmit(unsigned char a){
    while (SciaRegs.SCIFFTX.bit.TXFFST != 0);
    SciaRegs.SCITXBUF.all               = a;                    //SCITXBUF � transmitter data buffer register.
                                                                //Contains data (loaded by the CPU) to be transmitted
    SciaRegs.SCIFFTX.bit.TXFFINTCLR     = 1;
}

void scia_msg(char * msg){
    while(*msg !='\0'){
        scia_xmit(*msg);
        msg++;
    }
}

/***************************************RS485_TXD_ISR*******************************************/
/*
 * This interrupt is serving all the transmissions through RS485
 */
/********************************************************************************************/

__interrupt void sciaTxFifoIsr(void){
    EINT;                                                       // Enable Global interrupt INTM
    if(Display_scia.tx_count < Display_scia.tx_target_count){
        Display_scia.sci_send_buff++;
        scia_xmit(*Display_scia.sci_send_buff);

        Display_scia.tx_count++;
    }
    else{
        Display_scia.tx_count             = 1;
        Display_scia.tx_target_count      = 0;
//        RS485_TX_EN = false;
        free(Display_scia.sci_send_buff);
    }
    PieCtrlRegs.PIEACK.all              = PIEACK_GROUP9;        // Issue PIE ACK
}

/***************************************RS485_RXD_ISR*******************************************/
/*
 * This interrupt is serving all the receiving through RS485
 */
/********************************************************************************************/

__interrupt void sciaRxFifoIsr(void){
    EINT;

//    if(RS485_TX_EN == false)
    {
        Display_scia.sci_recv_buff[Display_scia.rx_count] = SciaRegs.SCIRXBUF.bit.SAR;
        Display_scia.rx_count++;                                      //store the incoming bytes to recieve buffer.
        Display_scia.rx_count %= recv_buffer_size;
    }
//    else
//    {
//        temp = SciaRegs.SCIRXBUF.all;
//    }

    SciaRegs.SCIFFCT.all                = 0x00;
    SciaRegs.SCIFFRX.bit.RXFFOVRCLR     = 1;                    // Clear Overflow flag
    SciaRegs.SCIFFRX.bit.RXFFINTCLR     = 1;                    // Clear Interrupt flag
    PieCtrlRegs.PIEACK.all              = PIEACK_GROUP9;        // Issue PIE ack

}
/***************RS485*******************************/

void scib_fifo_init(void){
    RS485_scib.BAUD_RATE                = 2;                    //EEPROM_ReadByte(19,6);

    EALLOW;
    ScibRegs.SCICCR.all                 = 0x0007;               // 1 stop bit, Parity Disable, Loop back Disable, 8 char bits, idle-line protocol
    ScibRegs.SCICTL1.all                = 0x0003;               // enable TX, RX // Disable RX ERR, SLEEP Disable // TXWAKE, internal SCICLK
    ScibRegs.SCICTL2.bit.TXINTENA       = 1;                    // TXRDY interrupt Enable
    ScibRegs.SCICTL2.bit.RXBKINTENA     = 1;                    // RXRDY interrupt Enable

    switch(RS485_scib.BAUD_RATE){
    case 1:
        ScibRegs.SCIHBAUD.all           = 0x0003;               //4800
        ScibRegs.SCILBAUD.all           = 0x000D;
        break;

    case 2:
        ScibRegs.SCIHBAUD.all           = 0x0001;               //9600
        ScibRegs.SCILBAUD.all           = 0x0086;
        break;

    case 3:
        ScibRegs.SCIHBAUD.all           = 0x0000;               //19200
        ScibRegs.SCILBAUD.all           = 0x00C3;
        break;

    case 4:
        ScibRegs.SCIHBAUD.all           = 0x0000;               //38400
        ScibRegs.SCILBAUD.all           = 0x0061;
        break;

    case 5:
        ScibRegs.SCIHBAUD.all           = 0x0000;               //57600
        ScibRegs.SCILBAUD.all           = 0x0041;
        break;

    case 6:
        ScibRegs.SCIHBAUD.all           = 0x0000;               //115200
        ScibRegs.SCILBAUD.all           = 0x0020;
        break;

    default:
        ScibRegs.SCIHBAUD.all           = 0x0001;               //9600
        ScibRegs.SCILBAUD.all           = 0x0086;
        break;
    }

    ScibRegs.SCIFFTX.all                = 0xC021;
    ScibRegs.SCIFFRX.all                = 0x0021;
    ScibRegs.SCIFFCT.all                = 0x0000;
    ScibRegs.SCICTL1.all                = 0x0023;               // Relinquish SCI from Reset
    ScibRegs.SCIFFTX.bit.TXFIFORESET    = 1;
    ScibRegs.SCIFFRX.bit.RXFIFORESET    = 1;
    EDIS;
}

void scib_xmit(unsigned char a){
    while (ScibRegs.SCIFFTX.bit.TXFFST != 0);
    ScibRegs.SCITXBUF.all               = a;                    //SCITXBUF � transmitter data buffer register.
                                                                //Contains data (loaded by the CPU) to be transmitted
    ScibRegs.SCIFFTX.bit.TXFFINTCLR     = 1;
}

void scib_msg(char * msg){
    while(*msg !='\0'){
        scib_xmit(*msg);
        msg++;
    }
}

/***************************************RS485_TXD_ISR*******************************************/
/*
 * This interrupt is serving all the transmissions through RS485
 */
/********************************************************************************************/

__interrupt void scibTxFifoIsr(void){
    EINT;                                                       // Enable Global interrupt INTM
    while(RS485_scib.tx_count < RS485_scib.tx_target_count){
        RS485_scib.sci_send_buff++;
        scib_xmit(*RS485_scib.sci_send_buff);

        RS485_scib.tx_count++;
    }
    if(RS485_scib.tx_count >= RS485_scib.tx_target_count){
        RS485_scib.tx_count             = 1;
        RS485_scib.tx_target_count      = 0;
        RS485_TX_EN = false;
        free(RS485_scib.sci_send_buff);
    }
    PieCtrlRegs.PIEACK.all              = PIEACK_GROUP9;        // Issue PIE ACK
}

/***************************************RS485_RXD_ISR*******************************************/
/*
 * This interrupt is serving all the receiving through RS485
 */
/********************************************************************************************/

__interrupt void scibRxFifoIsr(void){
    EINT;

    if(RS485_TX_EN == false)
    {
        RS485_scib.sci_recv_buff[RS485_scib.rx_count] = ScibRegs.SCIRXBUF.bit.SAR;
        RS485_scib.rx_count++;                                      //store the incoming bytes to recieve buffer.
        RS485_scib.rx_count %= recv_buffer_size;
    }
    else
    {
        temp = SciaRegs.SCIRXBUF.all;
    }

    ScibRegs.SCIFFCT.all                = 0x00;
    ScibRegs.SCIFFRX.bit.RXFFOVRCLR     = 1;                    // Clear Overflow flag
    ScibRegs.SCIFFRX.bit.RXFFINTCLR     = 1;                    // Clear Interrupt flag
    PieCtrlRegs.PIEACK.all              = PIEACK_GROUP9;        // Issue PIE ack

}
