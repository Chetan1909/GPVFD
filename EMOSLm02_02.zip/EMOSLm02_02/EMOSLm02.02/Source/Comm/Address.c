
#include <Headers/Project_Header/Init.h>






const Memory_map Memory_add[260] = {

                                    //  modbus add (Hex)      Variable type    Min       Max          Default        Memory Add (Hex)    Scaling Factor  No of registers

                                    {   0x0,                  UINT_16,      0,       1,          1,                0x100,                  1,               2      },   // Factory mode
                                    {   0x2,                  UINT_16,      0,       0,          0,                0x102,                  1,               2      },   // Language Sel
                                    {   0x4,                  UINT_16,      0,       1,          1,                0x104,                  1,               2      },  // Access Level Sel (Lock)
                                    {   0x6,                  UINT_16,      0,       9999,       1111,             0x106,                  1,               2      },  // Password
                                    {   0x8,                  UINT_16,      0,       1,          0,                0x108,                  1,               2      },  // EEPROM_DATA_VALID_FLAG
                                    {   0xA,                  UINT_16,      0,       1,          0,                0x10A,                  1,               2      },  // EEPROM_DATA_VALID_FLAG
                                    {   0xC,                  UINT_16,      0,       1,          0,                0x10C,                  1,               2      },  // EEPROM_DATA_VALID_FLAG
                                    {   0xE,                  FLOAT,        0,       9999,       100,              0x10C,                  100,             2      },  // EEPROM_DATA_VALID_FLAG
                                    {   0x10,                  UINT_16,      0,       1,          0,                0x108,                  1,               2      },  // Date_RTC
                                    {   0x12,                  UINT_16,      0,       1,          0,                0x10A,                  1,               2      },  // Month_RTC
                                    {   0x14,                  UINT_16,      0,       1,          0,                0x10C,                  1,               2      },  // Year_RTC
                                    {   0x16,                  UINT_16,        0,       9999,       100,              0x10C,                  1,             2      },  // Hour_RTC
                                    {   0x18,                  UINT_16,        0,       9999,       100,              0x10C,                  1,             2      },  // Minute_RTC
                                    {   0x1A,                  UINT_16,      0,       1,          0,                0x10A,                  1,               2      },  // Device_state_type
                                    {   0x1C,                  UINT_16,      0,       1,          0,                0x10C,                  1,               2      },  // Device_Type
                                    {   0x1E,                  UINT_16,        0,       9999,       100,              0x10C,                  1,             2      },  // Device_Sr_no
                                    {   0x20,                  UINT_16,        0,       9999,       100,              0x10C,                  1,             2      },  // Date_Code


                                    {   0x100,                UINT_16,      0,       2,          0,                0x180,                  1,               2      },   // Motor Type
                                    {   0x102,                UINT_16,      0,       9,          0,                0x182,                  1,               2      },  // Application Mode
                                    {   0x104,                UINT_16,      1,       2,          1,                0x184,                  1,               2      },  //  Control mode

                                    {   0x200,                FLOAT,        0,       1000,       415,              0x200,                  10,              2      },  // Induction Motor Nominal Voltage //RATED_VOLT_IM
                                    {   0x202,                FLOAT,        0,       1000,       15,               0x202,                  10,              2      },  // Induction Motor Nominal Current //RATED_CURR_IM
                                    {   0x204,                FLOAT,        0,       2000,       50,               0x204,                  1,               2      },  // Induction Motor Nominal Freq //RATED_FREQ_IM
                                    {   0x206,                FLOAT,        0,       1200,       3000,             0x206,                  1,              2      },  // Induction Motor Nominal Speed //RATED_OMEGA_IM
                                    {   0x208,                FLOAT,        0,       200,        15,               0x208,                  1,             2      },  // Induction Motor Nominal Power //MOTOR_POWER
                                    {   0x20A,                FLOAT,        0,       1,          0.85,             0x20A,                  100,             2      },  // Induction Motor Nominal PF //RATED_COS_PHI_IM
                                    {   0x20C,                FLOAT,        000,     000,        000,              0x20C,                  100,             2      },  // Induction Motor Nominal Slip //W_Slip_Est
                                    {   0x20E,                FLOAT,        0,       10,         0.45,             0x20E,                  100,             2      },  // Induction Motor stator Resistance //Rs
                                    {   0x210,                FLOAT,        0,       10,         0.85,             0x210,                  100,             2      },  // Induction Motor rotor Resistance // Rr
                                    {   0x212,                FLOAT,        0,       6,          0.04,             0x212,                  10000,           2      },  // Induction Motor Llr // Llr
                                    {   0x214,                FLOAT,        0,       6,          0.05,             0x214,                  10000,           2      },  // Induction Motor Lls // Lls
                                    {   0x216,                FLOAT,        0,       6,          0.03,             0x216,                  10000,           2      },  // Induction Motor Lm // Lm
                                    {   0x218,                UINT_32,      2,       20,         2,                0x218,                  1,               2      },  // Induction Motor poles // RATED_POLE_IM
                                    {   0x21A,                FLOAT,        0,       100,        10,               0x21A,                  100,             2      },  // Induction Stall Torque perc limit // TORQUE_PERCENT_IM

                                    {   0x300,                FLOAT,        0,       1000,       280,              0x280,                  10,              2      },  // PMSM Motor Nominal Voltage // RATED_VOLT_PM
                                    {   0x302,                FLOAT,        0,       1000,       15,               0x282,                  10,              2      },  // PMSM Motor Nominal Current // RATED_CURR_PM
                                    {   0x304,                FLOAT,        0,       2000,       150,              0x284,                  1,               2      },  // PMSM Motor Nominal Freq // RATED_FREQ_PM
                                    {   0x306,                FLOAT,        0,       1200,       3000,             0x286,                  1,              2      },  // PMSM Motor Nominal Speed // RATED_OMEGA_PM
                                    {   0x308,                FLOAT,        0,       200,        15,               0x288,                  1,             2      },  // PMSM Motor Nominal Power // MOTOR_POWER_PM
                                    {   0x30A,                FLOAT,        0,       1,          0.85,             0x28A,                  100,             2      },  // PMSM Motor Nominal PF // RATED_COS_PHI_PM
                                    {   0x30C,                FLOAT,        0,       10,         0.4,              0x28C,                  100,             2      },  // PMSM Motor stator Resistance // Rs_PM
                                    {   0x30E,                FLOAT,        0,       6,          0.006,            0x28E,                  10000,           2      },  // PMSM Motor Ld // Ld_PM
                                    {   0x310,                FLOAT,        0,       6,          0.008,            0x290,                  10000,           2      },  // PMSM Motor Lq // Lq_PM
                                    {   0x312,                UINT_32,      0,       10,         0.03,             0x292,                  1,               2      },  // PMSM Motor poles // RATED_POLE_PM
                                    {   0x314,                FLOAT,        2,       20,         2,                0x294,                  100,             2      },  // PMSM Stall Torque perc limit // TORQUE_PERCENT_PM
                                    {   0x316,                FLOAT,        2,       20,         2,                0x296,                  100,             2      },  //IMP_Factor


                                    {   0x400,                FLOAT,        0,       1000,       415,              0x300,                  10,              2      },  // SynRm Motor Nominal Voltage
                                    {   0x402,                FLOAT,        0,       1000,       15,               0x302,                  10,              2      },  // SynRm Motor Nominal Current
                                    {   0x404,                FLOAT,        0,       2000,       50,               0x304,                  1,               2      },  // SynRm Motor Nominal Freq
                                    {   0x406,                FLOAT,        0,       1200,       3000,             0x306,                  10,              2      },  // SynRm Motor Nominal Speed
                                    {   0x408,                FLOAT,        0,       200,        15,               0x308,                  100,             2      },  // SynRm Motor Nominal Power
                                    {   0x40A,                FLOAT,        0,       1,          0.85,             0x30A,                  100,             2      },  // SynRm Motor Nominal PF
                                    {   0x40C,                FLOAT,        000,     000,        000,              0x30C,                  100,             2      },  // SynRm Motor Nominal Slip
                                    {   0x40E,                FLOAT,        0,       10,         0.45,             0x30E,                  100,             2      },  // SynRm Motor stator Resistance
                                    {   0x410,                FLOAT,        0,       10,         0.85,             0x310,                  100,             2      },  // SynRm Motor rotor Resistance
                                    {   0x412,                FLOAT,        0,       6,          0.04,             0x312,                  10000,           2      },  // SynRm Motor Llr
                                    {   0x414,                FLOAT,        0,       6,          0.05,             0x314,                  10000,           2      },  // SynRm Motor Lls
                                    {   0x416,                FLOAT,        0,       6,          0.03,             0x316,                  10000,           2      },  // SynRm Motor Lm
                                    {   0x418,                UINT_32,      0,       10,         0.03,             0x318,                  1,               2      },  // SynRm Motor poles
                                    {   0x41A,                FLOAT,        2,       20,         2,                0x31A,                  100,             2      },  // SynRm Stall Torque perc limit

                                    {   0x500,                UINT_32,      1,       3,          9,                0x100,                  1,               2      },   // Select Speed mode from Display/485/RMS // SPEED_MODE_SELECT
                                    {   0x502,                UINT_32,      1,       1,          9,                0x382,                  1,               2      },   // Const speed select  // CONST_SPEED_REF_SOURCE
                                    {   0x504,                UINT_32,      0,       120000,     100,              0x384,                  1,               2      },   // Const speed 1   // CONST_SPEED_REF_1
                                    {   0x506,                UINT_32,      0,       120000,     200,              0x386,                  1,               2      },   // Const speed 2  // CONST_SPEED_REF_2
                                    {   0x508,                UINT_32,      0,       120000,     300,              0x388,                  1,               2      },   // Const speed 3  // CONST_SPEED_REF_3
                                    {   0x50A,                UINT_32,      0,       120000,     500,              0x38A,                  1,               2      },   // Const speed 4  // CONST_SPEED_REF_4
                                    {   0x50C,                UINT_32,      0,       120000,     700,              0x38C,                  1,               2      },   // Const speed 5  // CONST_SPEED_REF_5
                                    {   0x50E,                UINT_32,      0,       120000,     1000,             0x38E,                  1,               2      },   // Const speed 6  // CONST_SPEED_REF_6
                                    {   0x510,                UINT_32,      0,       120000,     1500,             0x390,                  1,               2      },   // Const speed 7  // CONST_SPEED_REF_7
                                    {   0x512,                UINT_32,      0,       120000,     2000,             0x392,                  1,               2      },   //Const speed 8 // CONST_SPEED_REF_8
                                    {   0x514,                UINT_32,      0,       120000,      2500,             0x394,                  1,               2      },   //Const speed 9  // CONST_SPEED_REF_9
                                    {   0x516,                UINT_32,      1,       1,          500,                0x396,                  1,               2      },   // VARIABLE_SPEED_REF_SOURCE
                                    {   0x518,                UINT_32,      0,       500,        120000,           0x398,                  1,               2      },   // SPEED_RPM_REF_UI

                                    {   0x600,                UINT_16,      0,       1,          1,                0x400,                  1,               2      },   // INPUT_UNBALANCE_LIMIT
                                    {   0x602,                UINT_16,      0,       1,          0,                0x402,                  1,               2      },   // UV_Enable
                                    {   0x604,                UINT_16,      0,       1,          0,                0x404,                  1,               2      },   // OV_Enable
                                    {   0x606,                UINT_16,      0,       1,          1,                0x406,                  1,               2      },   // OVER_TEMP_Enable
                                    {   0x608,                UINT_16,      0,       1,          1,                0x408,                  1,               2      },   // OC_Enable
                                    {   0x60A,                UINT_16,      0,       1,          0,                0x40A,                  1,               2      },   // Over_Load_enable
                                    {   0x60C,                UINT_16,      0,       1,          0,                0x40C,                  1,               2      },   // Over_Speed_Enable
                                    {   0x60E,                UINT_16,      0,       1,          0,                0x40E,                  1,               2      },   // DRY_Run_Enable

                                    {   0x700,                FLOAT,        0,       100,        50,               0x480,                  10,              2      },   // INPUT_VOLT_UNBALANCE_LIMIT
                                    {   0x702,                FLOAT,        100,     1000,       750,              0x482,                  10,              2      },   // DC_BUS_OV_LIMIT
                                    {   0x704,                FLOAT,        0,       150,        120,              0x484,                  10,              2      },   // DCBUS_UNDER_VOLT
                                    {   0x706,                FLOAT,        0,       100,        85,               0x486,                  10,              2      },   // VFD_OVER_TEMP_LIMIT
                                    {   0x708,                FLOAT,        0,       100,        85,               0x488,                  10,              2      },   // VFD_OVER_TEMP_LIMIT
                                    {   0x70A,                FLOAT,        0,       100,        85,               0x48A,                  10,              2      },   // VFD_OVER_TEMP_LIMIT
                                    {   0x70C,                FLOAT,        0,       100,        24,               0x48C,                  100,             2      },   // OVER_CURR_LIMIT
                                    {   0x70E,                FLOAT,        0,       100,        50,               0x48E,                  100,             2      },   // MAX_CURR_LIMIT
                                    {   0x710,                FLOAT,        0,       20,         5,                0x490,                  100,             2      },   // DRY_RUN_CURR_LIMIT
                                    {   0x712,                FLOAT,        0,       500,        100,              0x492,                  1,              2      },   // DRY_RUN_POWER_LIMIT
                                    {   0x714,                FLOAT,        0,       1000,       450,              0x494,                  10,              2      },   // VFD_OVER_VOLT_LIMIT
                                    {   0x716,                FLOAT,        0,       5,          1,                0x496,                  10,              2      },   // Torue_MIN
                                    {   0x718,                FLOAT,        0,       50,         10,               0x498,                  10,              2      },   // Torque_Max
                                    {   0x71A,                FLOAT,        0,       100,        1,                0x49A,                  1,               2      },   // Speed_Min
                                    {   0x71C,                FLOAT,        0,       200000,     3000,             0x49C,                  1,               2      },   // Speed_Max
                                    {   0x71E,                FLOAT,        0,       2000,       60,               0x49E,                  10,              2      },   // Freq_Min
                                    {   0x720,                FLOAT,        0,       100,        1,                0x4A0,                  10,              2      },    // Freq_Max
                                    {   0x722,                FLOAT,        0,       100,        1,                0x4A0,                  1,              2      },    // MAX_SOLAR_POWER
                                    {   0x724,                FLOAT,        0,       100,        1,                0x4A0,                  10,              2      },    // MAX_PV_CURRENT
                                    {   0x726,                FLOAT,        0,       100,        1,                0x4A0,                  10,              2      },    // MAX_OUTPUT_CURRENT

                                    {   0x800,                UINT_16,      0,       10,         1,                0x500,                  1,               2      },
                                    {   0x802,                UINT_16,      0,       10,         1,                0x502,                  1,               2      },
                                    {   0x804,                UINT_16,      0,       10,         1,                0x504,                  1,               2      },
                                    {   0x806,                UINT_16,      0,       10,         1,                0x506,                  1,               2      },

                                    {   0x900,                FLOAT,      0,       10,         180,                0x580,                  1,               2      },//MAX_FREQ_SET_PM
                                    {   0x902,                UINT_16,      0,       10,         1,                0x582,                  1,               2      },//FLAG_PARK_EEPROM
                                    {   0x904,                FLOAT,      0,       10,         2,                0x584,                  100,               2      },//SPEED_KP_PM
                                    {   0x906,                FLOAT,      0,       10,         5,                0x586,                  1000,               2      },//SPEED_KI_PM
                                    {   0x908,                FLOAT,      0,       10,         0,                0x588,                  10,               2      },//PMSM_THETA_FACTOR
                                    {   0x90A,                FLOAT,      0,       10,         500,                0x58A,                  1,               2      },//PMSM_MIN_RPM
                                    {   0x90C,                FLOAT,      0,       10,         30,                0x58C,                  10,               2      },//INIT_RAMP_TIME_PMSM
                                    {   0x90E,                FLOAT,      0,       10,         30,                0x58E,                  100,               2      },//INIT_VOLTPERCENT_FACTOR
                                    {   0x910,                FLOAT,      0,       10,         250,                0x590,                  10,               2      },//TORQUE_LIMIT_PM
                                    {   0x912,                FLOAT,      0,       10,         0,                0x592,                  10,               2      },//ID_REF_PM
                                    {   0x914,                FLOAT,      0,       10,         1,                0x594,                  10,               2      },//CURRENT_KP
                                    {   0x916,                FLOAT,      0,       10,         1,                0x596,                  10,               2      },//CURRENT_KI
                                    {   0x918,                FLOAT,      0,       10,         1,                0x598,                  10,               2      },//CURR_ERROR_LIMIT_PM
                                    {   0x91A,                FLOAT,      0,       10,         1,                0x59A,                  1,               2      },//VOLT_OUTPUT_LIMIT_PM
                                    {   0x91C,                FLOAT,      0,       10,         1,                0x59C,                  10,               2      },//START_CURRRENT_LIMIT
                                    {   0x91E,                FLOAT,      0,       10,         1,                0x59E,                  10,               2      },//ISTART_PM_FACTOR
                                    {   0x920,                FLOAT,      0,       10,         1,                0x510,                  10,               2      },//VFD_VDC_STEP
                                    {   0x922,                FLOAT,      0,       10,         1,                0x512,                  100,               2      },//VFD_VDC_KP
                                    {   0x924,                FLOAT,      0,       10,         1,                0x514,                  100,               2      },//VFD_VDC_KI




                                    {   0xA00,                UINT_16,      0,       10,         1,                0x600,                  1,               2      },
                                    {   0xA02,                UINT_16,      0,       10,         1,                0x602,                  1,               2      },
                                    {   0xA04,                UINT_16,      0,       10,         1,                0x604,                  1,               2      },
                                    {   0xA06,                UINT_16,      0,       10,         1,                0x606,                  1,               2      },


                                    {   0xB00,                UINT_16,      1,       2,          1,                0x680,                  1,               2      },
                                    {   0xB02,                UINT_16,      0,       1,          1,                0x682,                  1,               2      },
                                    {   0xB04,                UINT_16,      00,      00,         00,               0x684,                  1,               2      },
                                    {   0xB06,                UINT_16,      0,       1,          0,                0x686,                  1,               2      },
                                    {   0xB08,                UINT_16,      0,       1,          0,                0x688,                  1,               2      },
                                    {   0xB0A,                UINT_16,      00,      00,         00,               0x68A,                  1,               2      },
                                    {   0xB0C,                UINT_16,      0,       1,          0,                0x68C,                  1,               2      },
                                    {   0xB0E,                FLOAT,      0,       9,          0,                0x68E,                  1,               2      },
                                    {   0xB10,                UINT_16,      0,       9,          0,                0x690,                  1,               2      },
                                    {   0xB12,                UINT_16,      0,       100,        50,               0x692,                  1,               2      },
                                    {   0xB14,                UINT_16,      0,       9,          1,                0x694,                  1,               2      },
                                    {   0xB16,                UINT_16,      0,       9,          0,                0x696,                  1,               2      },
                                    {   0xB18,                UINT_16,      0,       1,          0,                0x698,                  1,               2      },
                                    {   0xB1A,                UINT_16,      0,       1,          0,                0x69A,                  1,               2      },
                                    {   0xB1C,                UINT_16,      0,       1,          0,                0x69C,                  1,               2      },
                                    {   0xB1E,                UINT_16,      0,       1,          0,                0x69E,                  1,               2      },
                                    {   0xB20,                UINT_16,      0,       1,          0,                0x6A0,                  1,               2      },
                                    {   0xB22,                UINT_16,      0,       1,          0,                0x6A2,                  1,               2      },

                                    {   0xC00,                FLOAT,        50,      60,         50,               0x700,                  10,              2      },
                                    {   0xC02,                FLOAT,        0,       1000,       100,              0x702,                  10,              2      },
                                    {   0xC04,                FLOAT,        0,       100,        50,               0x704,                  10,              2      },
                                    {   0xC06,                FLOAT,        50,      60,         50,               0x706,                  100,             2      },
                                    {   0xC08,                FLOAT,        200,     400,        100,              0x708,                  1,              2      },
                                    {   0xC0A,                FLOAT,        200,     500,        350,              0x70A,                  1,              2      },
                                    {   0xC0C,                FLOAT,        0,       20,         10,               0x70C,                  10,             2      },
//                                    {   0xC0E,                UINT_16,        0,       1000,       100,              0x70E,                  1,              2      },
//                                    {   0xC10,                UINT_16,        0,       1000,       200,              0x710,                  1,              2      },
//                                    {   0xC12,                UINT_16,        0,       5000,       3750,             0x712,                  1,               2      },

                                    {   0xD00,                FLOAT,        50,      60,         50,               0x780,                  1,              2      },
                                    {   0xD02,                FLOAT,        50,      60,         50,               0x782,                  10,              2      },
                                    {   0xD04,                FLOAT,        200,     400,        100,              0x784,                  1,              2      },
                                    {   0xD06,                FLOAT,        200,     500,        350,              0x786,                  10,              2      },
                                    {   0xD08,                FLOAT,        0,       20,         10,               0x788,                  1,             2      },
                                    {   0xD0A,                FLOAT,        0,       1000,       100,              0x78A,                  10,              2      },
                                    {   0xD0C,                FLOAT,        0,       5000,       3750,             0x78C,                  1,              2      },
                                    {   0xD0E,                FLOAT,        0,       1000,       200,              0x78E,                  10,              2      },
                                    {   0xD10,                FLOAT,        0,       1000,       200,              0x790,                  1,              2      },
                                    {   0xD12,                FLOAT,        0,       1000,       200,              0x792,                  10,              2      },
                                    {   0xD14,                FLOAT,        0,       1000,       200,              0x794,                  10,              2      },

                                    {   0xE00,                FLOAT,        0,       0,          0,                0x800,                  1000,              2      },
                                    {   0xE02,                FLOAT,        0,       0,          0,                0x802,                  1000,              2      },
                                    {   0xE04,                FLOAT,        0,       0,          0,                0x804,                  1000,               2      },

                                    {   0x0F00,                UINT_16,        0,       0,          0,                0x800,                  1,              2      },
                                    {   0x0F02,                UINT_16,        0,       0,          0,                0x802,                  1,              2      },
                                    {   0x0F04,                UINT_16,        0,       0,          0,                0x804,                  1,               2      },

                                    {    0x1F00,              UINT_16,      0,       1,          0,                 0x880,                 1,               1       },  //ON_OFF_FLAG
                                    {    0x1F02,              UINT_16,      0,       100,        50,                0x0021,                1,               1       },  //FAULT_CODE
                                    {    0x1F04,              FLOAT,        0,       250.0,      50,                0x0022,                10,              1       },  //VDC_BUS
                                    {    0x1F06,              FLOAT,        0,       100,        50,                0x0023,                10,              1       },  //Input_Vol_RY
                                    {    0x1F08,              FLOAT,        0,       100,        50,                0x0024,                10,              1       },  //Input_Vol_YB
                                    {    0x1F0A,              FLOAT,        0,       100,        50,                0x0025,                10,              1       },  //Input_Vol_BR
                                    {    0x1F0C,              FLOAT,        0,       100,        50,                0x0026,                10,              1       },  //Input_Curr_R
                                    {    0x1F0E,              FLOAT,        0,       100,        50,                0x0027,                1,              1       },  //Input_Curr_Y
                                    {    0x1F10,              FLOAT,        0,       100,        50,                0x0028,                1,              1       },  //Input_Curr_B
//                                    {    0x1F12,              FLOAT,        0,       100,        50,                0x0029,                10,              1       },  //
//                                    {    0x1F14,              FLOAT,        0,       100,        50,                0x0030,                10,              1       },  //
//                                    {    0x1F16,              FLOAT,        0,       100,        50,                0x0031,                10,              1       },  //
//                                    {    0x1F18,              FLOAT,        0,       100,        50,                0x0032,                10,              1       },  //
                                    {    0x1F1A,              FLOAT,        0,       100,        50,                0x0033,                10,              1       },  //
                                    {    0x1F1C,              FLOAT,        0,       100,        50,                0x0034,                10,              1       },  //RATED_POLE_IM
                                    {    0x1F1E,              FLOAT,        0,       100,        50,                0x0035,                10,              1       },  //Output_Vol_UV

                                    {    0x1F20,              FLOAT,        0,       100,        50,                0x0020,                10,              1       },  //Output_Vol_VW
                                    {    0x1F22,              FLOAT,        0,       100,        50,                0x0021,                10,              1       },  //Output_Vol_WU
                                    {    0x1F24,              FLOAT,        0,       250.0,      50,                0x0022,                10,              1       },  //Output_Curr_U
                                    {    0x1F26,              FLOAT,        0,       100,        50,                0x0023,                10,              1       },  //Output_Curr_V
                                    {    0x1F28,              FLOAT,        0,       100,        50,                0x0024,                1,              1       },  //Output_Curr_W
//                                    {    0x1F2A,              FLOAT,        0,       100,        50,                0x0025,                10,              1       },  //Freq
                                    {    0x1F2C,              UINT_16,        0,       100,        50,                0x0026,                1,              1       },  //
                                    {    0x1F2E,              FLOAT,        0,       100,        50,                0x0027,                1000,              1       },  //Live_Torque
                                    {    0x1F30,              FLOAT,        0,       100,        50,                0x0028,                10,              1       },  //
//                                    {    0x1F32,              FLOAT,        0,       100,        50,                0x0029,                10,              1       },  //
//                                    {    0x1F34,              FLOAT,        0,       100,        50,                0x0030,                10,              1       },  //
                                    {    0x1F36,              FLOAT,        0,       100,        50,                0x0031,                10,              1       },  //
                                    {    0x1F38,              FLOAT,        0,       100,        50,                0x0032,                10,              1       },  //
//                                    {    0x1F3A,              FLOAT,        0,       100,        50,                0x0033,                10,              1       },  //TEMP_HS
//                                    {    0x1F3C,              FLOAT,        0,       100,        50,                0x0034,                10,              1       },  //TEMP_INV
//                                    {    0x1F3E,              FLOAT,        0,       100,        50,                0x0035,                10,              1       },  //
//
//                                    {    0x1F40,              FLOAT,        0,       100,        50,                0x0020,                1,               1       },  //
//                                    {    0x1F42,              FLOAT,        0,       100,        50,                0x0021,                1,               1       },  //
                                    {    0x1F44,              FLOAT,        0,       250.0,      50,                0x0022,                10,              1       },  //
                                    {    0x1F46,              FLOAT,        0,       100,        50,                0x0023,                10,              1       },  //
//                                    {    0x1F48,              FLOAT,        0,       100,        50,                0x0024,                10,              1       },  //Speed_Ref_VFD_Max
//                                    {    0x1F4A,              FLOAT,        0,       100,        50,                0x0025,                10,              1       },  //Torque_Ref
//                                    {    0x1F4C,              FLOAT,        0,       100,        50,                0x0026,                1,               1       },  //
//                                    {    0x1F4E,              FLOAT,        0,       100,        50,                0x0028,                10,              1       },  //
                                    {    0x1F50,              FLOAT,        0,       100,        50,                0x0029,                10000,              1       },  //
                                    {    0x1F52,              FLOAT,        0,       100,        50,                0x0030,                10000,              1       },  //
                                    {    0x1F54,              FLOAT,        0,       100,        50,                0x0031,                1000,              1       },  //TOTAL_ENERGY
                                    {    0x1F56,              FLOAT,        0,       100,        50,                0x0032,                10,              1       },  //Cumulative_Energy
//                                    {    0x1F58,              FLOAT,        0,       100,        50,                0x0033,                10,              1       },  //Daily_Water_Discharge
//                                    {    0x1F5A,              FLOAT,        0,       100,        50,                0x0034,                10,              1       },  //Cummulative_Water_Discharge
//                                    {    0x1F5C,              FLOAT,        0,       100,        50,                0x0035,                10,              1       },  //Daily_Pump_Run_Hrs

                                    {    0x1F5E,              UINT_32,        0,       1,        1,                0x0020,                1,               1       },  //soft_stop_flag
                                    {    0x1F60,              FLOAT,        0,       100,        50,                0x0021,                1,               1       },  //test_var
//                                    {    0x1F62,              UINT_32,      0,       1,          500,               0x0021,                1,               1       },  //Motor RPM
//                                    {    0x1F70,              UINT_32,      0,       1,          500,               0x0021,                1,               1       },  //soft_stop_flag

};

/*void Factory_Mode(void){

    EEPROM_Default_Data_Write();    //write default parameters

    EEPROM_All_Data_Read();         //read default parameters

}*/
//#pragma LOCATION(MOTOR_TYPE, 0x0000A100)
//////int tempOffset;
//#pragma LOCATION(CONTROL_MODE, 0x0000A102)
//////int tempOffset1;
//#pragma LOCATION(RATED_VOLT_IM, 0x0000A104)
//////int tempOffset2;
//#pragma LOCATION(RATED_CURR_IM, 0x0000A106)
//////int tempOffset3;
//#pragma LOCATION(RATED_FREQ_IM, 0x0000A108)
////int tempOffset4;
//#pragma LOCATION(RATED_OMEGA_IM, 0x0000A10A)
//float tempOffset5;
//float RATED_OMEGA_IM;
