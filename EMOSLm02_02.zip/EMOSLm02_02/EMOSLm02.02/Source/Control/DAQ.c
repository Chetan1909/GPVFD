/*
 * ADC.c
 *
 *  Created on: 13-May-2023
 *      Author: pemen
 */
#include <Headers/Project_Header/Init.h>




void Read_ADC(void){

    float  Adca1 = 0, Adca3 = 0, Adca4 = 0, Adca5 = 0, Adca7 = 0, Adca8 = 0, Adca10 = 0, Adca11 = 0, Adca12 = 0, Adca14 =0 , Adca15 = 0;

    /*******************************ADC RESULTS REGISTERS****************************************/
    /*
     * As explained in the ABOUT section, this is where the instantaneous count (0to 4096)
     * will be stored in the selected variable.
     */
    /********************************************************************************************/

    Adca1   = AdcaResultRegs.ADCRESULT1;    //VDC_BUS_SNS_DSP
    Adca3   = AdcaResultRegs.ADCRESULT3;    //ANA_MUX_DSP
    Adca4   = AdcaResultRegs.ADCRESULT4;    //GRD_I1_SNS_DSP
    Adca5   = AdcaResultRegs.ADCRESULT5;    //INV_CURR_I2_SNS_DSP
    Adca7   = AdcaResultRegs.ADCRESULT7;    //PLC_V2V_SNS_DSP
    Adca8   = AdcaResultRegs.ADCRESULT8;    //RY_VOLT_SNS_DSP
    Adca10  = AdcaResultRegs.ADCRESULT10;   //YB_VLOT_SNS_DSP
    Adca11  = AdcaResultRegs.ADCRESULT11;   //INV_CURR_I1_SNS_DSP
    Adca12  = AdcaResultRegs.ADCRESULT12;   //PLC_I2V_SNS_DSP
    Adca14  = AdcaResultRegs.ADCRESULT14;   //VW_VOLT_SNS_DSP
    Adca15  = AdcaResultRegs.ADCRESULT15;   //UV_VOLT_SNS_DSP

    /**********************************ADC OFFSET REMOVAL****************************************/
    /*
     * Any offset (if there) is removed here in the voltage and current reading. Offset is
     * introduced by the circuit (usually reading AC voltages and currents) to pull up the
     * negative values to 0 level, or it can also be present inherently in some current sensors
     * output. (like 1.5V output at 0 current). Refer to datasheets to current sensors and voltage
     * sensors used.
     */
    /********************************************************************************************/

    Adca4       = Adca4 - CURR_OFFSET_ACS720;                 // GRD_I1_SNS_DSP
    Adca5       = Adca5 - CURR_OFFSET_ACS720;                 // INV_CURR_I2_SNS_DSP
    PLC_V_count = Adca7;                                      // PLC_Vin2Vsns_DSP
    Adca8       = Adca8 - AC_VOLT_OFFSET;                     // GRD_RY_SNS_DSP
    Adca10      = Adca10 - AC_VOLT_OFFSET;                    // GRD_YB_SNS_DSP
    Adca11      = Adca11 - CURR_OFFSET_ACS720;                // INV_CURR_I1_SNS_DSP
    PLC_I_count = Adca12;                                     // PLC_Iin2Vsns_DSP
    Adca14      = Adca14 - AC_VOLT_OFFSET;                    // INV_VW_SNS_DSP
    Adca15      = Adca15 - AC_VOLT_OFFSET;                    // INV_UV_SNS_DSP


    VDC_BUS     = Adca1 * VDC_GAIN;                           //VDC_BUS_SNS_DSP

    if(SPEED_FORWARD){
        I_INV_R = Adca11 * CURR_GAIN * -1;                    // INV_I1 INV_IU_SNS_DSP
        I_INV_Y = Adca5 * CURR_GAIN;                          // INV_I2 INV_IV_SNS_DSP
        I_INV_B = -I_INV_R - I_INV_Y;                         // - I_INV_R-I_INV_Y;

        VINV_RY = Adca15 * VAC_GAIN;                          // INV_UV_SNS_DSP
        VINV_YB = Adca14 * VAC_GAIN;                          // INV_VW_SNS_DSP
        VINV_BR = -VINV_RY - VINV_YB;
    }
    else if(!SPEED_FORWARD){
        I_INV_R = Adca5 * CURR_GAIN;                          // I_INV_R changed to I_INV_Y by changing Adca11 to Adca5
        I_INV_Y = Adca11 * CURR_GAIN * -1;                    // I_INV_Y changed to I_INV_R by changing ADCc3 to ADCc2
        I_INV_B = -I_INV_R - I_INV_Y;                         // - I_INV_R-I_INV_Y;

        VINV_RY = Adca15 * -VAC_GAIN;                         // V_INV_UV changed to - V_INV_UV
        VINV_BR = Adca14 * -VAC_GAIN;                         // V_INV_VW
        VINV_YB = - VINV_RY - VINV_BR;
    }
    else{
        //Nowork
    }


    VGRD_RY     = Adca8 * VAC_GAIN;                         // VGRD_RY will be used for the solar polarity detection
    VGRD_YB     = Adca10 * VAC_GAIN;                        // VGRD_YB will be used for the grid polarity detection
    VGRD_BR     = -VGRD_RY -VGRD_YB;
    I_GRID_R    = Adca4 * CURR_GAIN;

    MSC_I_U = I_INV_R;
    MSC_I_V = I_INV_Y;
    MSC_I_W = I_INV_B;

    VGRD_RY1[Avgi] = VGRD_RY;
    VGRD_RY_MAF = VGRD_RY1[0]+ VGRD_RY1[1]+VGRD_RY1[2]+ VGRD_RY1[3];
    VGRD_RY_MAF = VGRD_RY_MAF*0.25;

    VGRD_YB1[Avgi] = VGRD_YB;
    VGRD_YB_MAF = VGRD_YB1[0]+ VGRD_YB1[1]+VGRD_YB1[2]+ VGRD_YB1[3];
    VGRD_YB_MAF = VGRD_YB_MAF*0.25;

    VGRD_BR1[Avgi] = VGRD_BR;
    VGRD_BR_MAF = VGRD_BR1[0]+ VGRD_BR1[1]+VGRD_BR1[2]+ VGRD_BR1[3];
    VGRD_BR_MAF = VGRD_BR_MAF*0.25;
	
    VINV_UV1[Avgi] = VINV_RY;
    VINV_UV_MAF = VINV_UV1[0]+ VINV_UV1[1]+VINV_UV1[2]+ VINV_UV1[3];
    VINV_UV_MAF = VINV_UV_MAF*0.25;

    VINV_VW1[Avgi] = VINV_YB;
    VINV_VW_MAF = VINV_VW1[0]+ VINV_VW1[1]+VINV_VW1[2]+ VINV_VW1[3];
    VINV_VW_MAF = VINV_VW_MAF*0.25;

    VINV_WU1[Avgi] = VINV_BR;
    VINV_WU_MAF = VINV_WU1[0]+ VINV_WU1[1]+VINV_WU1[2]+ VINV_WU1[3];
    VINV_WU_MAF = VINV_WU_MAF*0.25;

    VDC_BUS1[Avgi] = VDC_BUS;
    VDC_BUS_MAF = VDC_BUS1[0]+ VDC_BUS1[1]+VDC_BUS1[2]+ VDC_BUS1[3];
    VDC_BUS_MAF = VDC_BUS_MAF*0.25;

    I_GRID_R1[Avgi] = I_GRID_R;
    I_GRID_MAF = I_GRID_R1[0]+ I_GRID_R1[1]+I_GRID_R1[2]+ I_GRID_R1[3];
    I_GRID_MAF = I_GRID_MAF*0.25;

    if( I_GRID_MAF < 0){
        I_GRID_MAF = -I_GRID_MAF;
    }

    I_INV_U1[Avgi] = I_INV_R;
    I_INV_U_MAF = I_INV_U1[0]+ I_INV_U1[1]+I_INV_U1[2]+ I_INV_U1[3];
    I_INV_U_MAF = I_INV_U_MAF*0.25;

    I_INV_V1[Avgi] = I_INV_Y;
    I_INV_V_MAF = I_INV_V1[0]+ I_INV_V1[1]+I_INV_V1[2]+ I_INV_V1[3];
    I_INV_V_MAF = I_INV_V_MAF*0.25;

    I_INV_B_MAF = - I_INV_U_MAF - I_INV_V_MAF;


    Avgi++;
    if(Avgi>3){
        Avgi=0;
    }

    MSC_I_U_SQR = MSC_I_U*MSC_I_U;
    MSC_I_V_SQR = MSC_I_V*MSC_I_V;
    MSC_I_W_SQR = MSC_I_W*MSC_I_W;


    VGRD_RY_RMS_Prev        = VGRD_RY_STRUCT.RMS  * LPF_CONST_C1_1 + VGRD_RY_RMS_Prev * LPF_CONST_C2_1;
    VGRD_RY_RMS_LPF         = VGRD_RY_RMS_Prev *  LPF_WC_1;

    VDC_BUS_LPF_1_Prev      = VDC_BUS * LPF_CONST_C1_1 + VDC_BUS_LPF_1_Prev * LPF_CONST_C2_1;
    VDC_BUS_LPF_1           = VDC_BUS_LPF_1_Prev * LPF_WC_1;

    VDC_BUS_LPF_50_Prev     = VDC_BUS_MAF * LPF_CONST_C1_50 + VDC_BUS_LPF_50_Prev * LPF_CONST_C2_50;
    VDC_BUS_LPF_50          = VDC_BUS_LPF_50_Prev * LPF_WC_50;

    I_GRID_R_LPF_50_Prev    = I_GRID_MAF * LPF_CONST_C1_50 +  I_GRID_R_LPF_50_Prev * LPF_CONST_C2_50;
    I_GRID_R_LPF_50         = I_GRID_R_LPF_50_Prev * LPF_WC_50;

    I_OUTPUT_AVG = 0.5*(IVFD_U_STRUCT.RMS + IVFD_V_STRUCT.RMS);

    /**********************************RYB_to_alphaBeta******************************************/
    I_Alpha_OTH = ThreebyTwo*I_INV_R_MAF;
    I_Beta_OTH  = RootThreebyTwo*(-2*I_INV_Y_MAF- I_INV_R_MAF);

    V_Alpha_OTH = VINV_UV_MAF - VINV_WU_MAF;
    V_Alpha_OTH = 0.5*V_Alpha_OTH ;
    V_Beta_OTH  = -RootThreebyTwo*VINV_VW_MAF;

    /**********************************ACTIVE POWER CALC******************************************/

    V_Peak      = sqrt((V_Alpha_OTH*V_Alpha_OTH)+(V_Beta_OTH*V_Beta_OTH));
    theta_corr  =  atan2(V_Alpha_OTH,V_Beta_OTH);

    if(theta_corr > (2*PI))  theta_corr = (theta_corr-(2*PI));
    if(theta_corr < (-2*PI))  theta_corr = (theta_corr+(2*PI));

    theta_lag_calc      = speed_info*(FILTER_RC);
    gain_comp           = sqrt(1 +theta_lag_calc*theta_lag_calc);
    V_Peak_corr         = V_Peak * gain_comp;
    theta_lag_comp      = atan2 (theta_lag_calc,1);//- speed_info*0.000312;
    theta_corr          = theta_corr + theta_lag_comp;
    theta_corr          = theta_corr/(2*PI);
    V_Alpha_OTH_Corr    = V_Peak_corr*__sinpuf32(theta_corr);
    V_Beta_OTH_Corr     = V_Peak_corr*__cospuf32(theta_corr);
    Active_Pow_corr     = (V_Alpha_OTH_Corr*I_Alpha_OTH)+(V_Beta_OTH_Corr*I_Beta_OTH);
    Active_Pow_corr     = 0.627*Active_Pow_corr;                      // 0.67*1.05 = 0.7

    Motor_Power_LPF_1_Prev       = Active_Pow_corr * LPF_CONST_C1_1 + Motor_Power_LPF_1_Prev * LPF_CONST_C2_1;
    Motor_Power_LPF_1            = Motor_Power_LPF_1_Prev * LPF_WC_1;

    if(GRID_DETECTED == 0){
        Active_Pow_corr = 0.96*P_PV_Avg;
    }
    if(GRID_DETECTED == 0){
        P_PV_Avg                = VDC_BUS_LPF_50 * I_GRID_R_LPF_50;
    }
    if(GRID_DETECTED == 1){
        P_PV_Avg =  Motor_Power_LPF_1;
    }

    P_Motor_Slowest = P_PV_Avg;
    /*******************************V_Peak_corr_Avg Calculation START****************************/

    V_Peak_corr1 = V_Peak_corr * 0.8165;    //0.6667 * sqrt(3/2) = 0.8165
    V_Peak_corr_Prev = V_Peak_corr1 * LPF_Const_Slowest7 + V_Peak_corr_Prev * LPF_Const_Slowest8;
    V_Peak_corr_Avg  = V_Peak_corr_Prev * LPF_Cutoff_Freq_Slowest3;

    //debug_V_Peak_corr = V_Peak_corr_Avg;

    /*******************************V_Peak_corr_Avg Calculation END****************************/


    if(ON_OFF_FLAG){
        Freq_PLL = Freq;
    }
    else{
        Freq_PLL = 50;
    }
    PLL_IndexCalc(Freq_PLL, &InvIndexPara);


    publishSample(VINV_UV_MAF, VOLT_VFD_UV, InvIndexPara.pllIndex);
    publishSample(VINV_VW_MAF, VOLT_VFD_VW, InvIndexPara.pllIndex);
    publishSample(VINV_WU_MAF, VOLT_VFD_WU, InvIndexPara.pllIndex);
    publishSample(I_INV_U_MAF, CURR_VFD_U, InvIndexPara.pllIndex);
    publishSample(I_INV_U_MAF, CURR_VFD_V, InvIndexPara.pllIndex);
    publishSample(I_INV_B_MAF, CURR_VFD_W, InvIndexPara.pllIndex);


    PLL_IndexCalc(50, &GrdIndexPara);
    publishSample(I_GRID_R, CURR_GRD_R, GrdIndexPara.pllIndex);
    publishSample(VGRD_RY_MAF, VOLT_GRD_RY, GrdIndexPara.pllIndex);
    publishSample(VGRD_YB_MAF, VOLT_GRD_YB, GrdIndexPara.pllIndex);
    publishSample(VGRD_BR_MAF, VOLT_GRD_BR, GrdIndexPara.pllIndex);

    switch(MUX_POS){
    case 0:
        if(MUX_Count>50){
            TEMPINV_COUNT = 0.049152706*Adca3-45.3;
            TEMPINV_COUNT1 = TEMPINV_COUNT;
            if(TEMPINV_COUNT1 > 149)TEMPINV_COUNT1= 149;
            TEMP_INV = TEMP_INV_TABLE[TEMPINV_COUNT1];       // TEMP_INV_SNS_DSP

        }
        break;
    case 1:
        if(MUX_Count>50){
            TEMPHS_COUNT = 0.049152706*Adca3-45.3;
            TEMPHS_COUNT1 = TEMPHS_COUNT;
            if(TEMPHS_COUNT1 >149)TEMPHS_COUNT1=149;
            TEMP_HS = TEMP_HS_TABLE[TEMPHS_COUNT1];        // TEMP_HS_SNS_DSP
        }
        break;
    case 2:
        break;
    case 3:
        break;
    case 4:
        break;
    case 5:
        break;
    case 6:
        break;
    case 7:
        break;
    default:
        break;
    }

    MUX_Count++;
    if(MUX_Count >= 100){
        MUX_POS++;
        MUX_Count = 0;
        if(MUX_POS > 7){
            MUX_POS = 0;
        }
    }
    switch(MUX_POS){
       case 0:
           S2 = 0; S1 = 0; S0 = 0;
           break;
       case 1:
           S2 = 0; S1 = 0; S0 = 1;
           break;
       case 2:
           S2 = 0; S1 = 1; S0 = 0;
           break;
       case 3:
           S2 = 0; S1 = 1; S0 = 1;
           break;
       case 4:
           S2 = 1; S1 = 0; S0 = 0;
           break;
       case 5:
           S2 = 1; S1 = 0; S0 = 1;
           break;
       case 6:
           S2 = 1; S1 = 1; S0 = 0;
           break;
       case 7:
           S2 = 1; S1 = 1; S0 = 1;
           break;
       default:
           S2 = 1; S1 = 1; S0 = 0;
           break;

       }

       GpioDataRegs.GPHSET.bit.GPIO224      = S0;           // MUX_CNTRL0
       GpioDataRegs.GPHCLEAR.bit.GPIO224    = (1-S0);       // MUX_CNTRL0
       GpioDataRegs.GPBSET.bit.GPIO33       = S1;           // MUX_CNTRL1
       GpioDataRegs.GPBCLEAR.bit.GPIO33     = (1-S1);       // MUX_CNTRL1
       GpioDataRegs.GPHSET.bit.GPIO227      = S2;           // MUX_CNTRL0
       GpioDataRegs.GPHCLEAR.bit.GPIO227    = (1-S2);       // MUX_CNTRL0

       loc_plc[MUX_POS] = (1 - GpioDataRegs.GPBDAT.bit.GPIO41);


       RPM_Display = Freq * 120 / RATED_POLE_IM;

       if(ON_OFF_FLAG == false){
           if (VGRD_RY_MAF > 50) {
               count_pos++;
           }
           else if (VGRD_RY_MAF < -50){
               count_neg++;
           }
           if(SysTime_Minute_Count_IntervalElapsed(grid_detect_minute,0.01)){
               grid_detect_minute=Minute_Count;
               if(count_pos>1500 && count_neg > 1500){
                   GRID_DETECTED = 1;
                   count_pos = 0;
                   count_neg = 0;
               }
               else{
                   GRID_DETECTED = 0;
                   count_pos = 0;
                   count_neg = 0;
               }
           }
       }
       else {
           count_pos = 0;
           count_neg = 0;
       }

       if(VGRD_RY_MAF > 150 && GRID_DETECTED == 0 ){
           POLARITY = true;
       }
       else if(VGRD_RY_MAF < -150 && GRID_DETECTED == 0 ){
           POLARITY = false;
       }


}


void PLL_IndexCalc(float Index_Freq, IndexPara *Index){
    //1/64 =  0.015625 --> corresponds to the number of indexes we want to generate in on cycle
    Index->indexScaler =  roundf((FS * MAX_INDEX)/Index_Freq);
    //Index generation for ADC based on PLL information
    if (Index->zcDetected && !Index->indexCount){
        Index->indexCount = 0;
        Index->index64 = 0;
        Index->zcDetected = false;
    }
    Index->indexCount++;
    if ( Index->indexCount >= Index->indexScaler){
        Index->indexCount = 0;
        Index->pllIndex = Index->index64;
        Index->index64++;
        if (Index->index64 >= 64){
            Index->index64 = 0;
        }
    }
}



void RMS_Average_Calc(){
    VGRD_RY_STRUCT.RMS     = rms_calculation(DaqMeasItems_VOLT_GRD_RY_buf, &VGRD_RY_STRUCT);
    VGRD_YB_STRUCT.RMS     = rms_calculation(DaqMeasItems_VOLT_GRD_YB_buf, &VGRD_YB_STRUCT);
    VGRD_BR_STRUCT.RMS     = rms_calculation(DaqMeasItems_VOLT_GRD_BR_buf, &VGRD_BR_STRUCT);
    IGRD_R_STRUCT.RMS      = rms_calculation(DaqMeasItems_CURR_GRD_R_buf,  &IGRD_R_STRUCT);
    VVFD_UV_STRUCT.RMS     = rms_calculation(DaqMeasItems_VOLT_VFD_UV_buf, &VVFD_UV_STRUCT);
    VVFD_VW_STRUCT.RMS     = rms_calculation(DaqMeasItems_VOLT_VFD_VW_buf, &VVFD_VW_STRUCT);
    VVFD_WU_STRUCT.RMS     = rms_calculation(DaqMeasItems_VOLT_VFD_WU_buf, &VVFD_WU_STRUCT);
    IVFD_U_STRUCT.RMS      = rms_calculation(DaqMeasItems_CURR_VFD_U_buf,  &IVFD_U_STRUCT);
    IVFD_V_STRUCT.RMS      = rms_calculation(DaqMeasItems_CURR_VFD_V_buf,  &IVFD_V_STRUCT);
    IVFD_W_STRUCT.RMS      = rms_calculation(DaqMeasItems_CURR_VFD_W_buf,  &IVFD_W_STRUCT);

    if (ON_OFF_FLAG == false){
        VVFD_UV_STRUCT.RMS     = 0;
        VVFD_VW_STRUCT.RMS     = 0;
        VVFD_WU_STRUCT.RMS     = 0;
        IVFD_U_STRUCT.RMS      = 0;
        IVFD_V_STRUCT.RMS      = 0;
    }
}

float rms_calculation(float *ADC, RMSData *RMSVar){
    float RMS = 0;
    int i = 0;

    for(i=0; i <= 63; i++){
        RMSVar->d_sumOfSquares = ((*(ADC+i)) * (*(ADC+i))) + RMSVar->d_sumOfSquares;
    }

    RMSVar->d_msq  = RMSVar->d_sumOfSquares*0.015625;
    RMS = sqrtf(RMSVar->d_msq);
    RMSVar->d_sumOfSquares = 0;

    return(RMS);
}
