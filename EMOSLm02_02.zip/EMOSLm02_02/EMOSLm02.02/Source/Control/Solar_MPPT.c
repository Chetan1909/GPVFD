/*
 * Solar_MPPT.c
 *
 *  Created on: 16-Oct-2023
 *      Author: manoj
 */
#include <Headers/Project_Header/Init.h>

float Vdc_Controller_TS_MPP(float VDC_VFD_ERROR){
    float pi_output =0, errorintoki =0, errorintokp = 0;

    if(VDC_VFD_ERROR > VDC_VFD_ERROR_Max) VDC_VFD_ERROR = VDC_VFD_ERROR_Max;
    if(VDC_VFD_ERROR < -VDC_VFD_ERROR_Max) VDC_VFD_ERROR = -VDC_VFD_ERROR_Max;


    errorintokp = VFD_VDC_KP * VDC_VFD_ERROR;
    errorintoki = VFD_VDC_KI  * VDC_VFD_ERROR;
    errorintoki = errorintoki * Ts;

    VDC_VFD_ERROR_Integ = errorintoki + Last_VDC_VFD_ERROR_Integ;

    if(VDC_VFD_ERROR_Integ > VDC_VFD_ERROR_Integ_Max) VDC_VFD_ERROR_Integ = VDC_VFD_ERROR_Integ_Max;
    if(VDC_VFD_ERROR_Integ < VDC_VFD_ERROR_Integ_Min) VDC_VFD_ERROR_Integ = VDC_VFD_ERROR_Integ_Min;

    Last_VDC_VFD_ERROR_Integ = VDC_VFD_ERROR_Integ;

    pi_output  = VDC_VFD_ERROR_Integ + errorintokp;

    if(pi_output > VDC_VFD_ERROR_PI_Output_Max) pi_output = VDC_VFD_ERROR_PI_Output_Max;
    if(pi_output < VDC_VFD_ERROR_PI_Output_Min) pi_output = VDC_VFD_ERROR_PI_Output_Min;

    return(pi_output);
}
float debug_Power, debug_P_Prev, debug_dV, debug_dP;
float V_DC_Step;

void VBased_MPPT(){
    float dP = 0, dV = 0;
    float Power = 0, P_Prev = 0;
    float V_PMAX_Step, V_IMAX_Step;

    V_DC_Step         = VFD_VDC_STEP;
    Power             = VDC_BUS_LPF_50 * I_GRID_R_LPF_50;
    P_Prev            = VPV_Avg_Prev * IPV_Avg_Prev;

    debug_Power = Power;
    debug_P_Prev = P_Prev;

    dP = Power - P_Prev;
    dV = VDC_BUS_LPF_50- VPV_Avg_Prev;

    debug_dV = dV;
    debug_dP = dP;

    if(dP<(tol_P_vfd) && dP>-(tol_P_vfd)){
        dP = 0;
    }
    else{
        VPV_Avg_Prev    = VDC_BUS_LPF_50;
        IPV_Avg_Prev    = I_GRID_R_LPF_50;
    }

    if(dV<(tol_V_vfd) && dV>-(tol_V_vfd)){
        dV = 0;
    }

    if(Power > MAX_SOLAR_POWER || I_GRID_R_LPF_50 > I_PV_MAX || I_OUTPUT_AVG > MAX_OUTPUT_CURRENT|| Freq >= Freq_Ref_VFD_Max /*|| FLAG_CORRES_SPEED_IM == 1*/
            || Speed_Ref_IM >= (6.28 * Freq_Ref_VFD_Max)){
        dP = 0;
        V_PMAX_Step = (Power-MAX_SOLAR_POWER)*0.01;
        V_IMAX_Step = (I_GRID_R_LPF_50-I_PV_MAX)*0.1;
        if (V_PMAX_Step > 0.75 * V_DC_Step) V_PMAX_Step = 0.75 * V_DC_Step;
        if (V_PMAX_Step < 0.05 * V_DC_Step) V_PMAX_Step = 0.05 * V_DC_Step;
        if (V_IMAX_Step > 1.25 * V_DC_Step) V_IMAX_Step = 1.25 * V_DC_Step;
        if (V_IMAX_Step < 0.05 * V_DC_Step) V_IMAX_Step = 0.05 * V_DC_Step;
    }

    if(SOFT_STOP_FLAG==true){
        if (CONTROL_MODE==1){
            Freq = Freq - MOTOR_FREQ_DECR;
            //freq = freq - (0.04*MOTOR_RATED_FREQ_IND);
            if(Freq < (RATED_FREQ_IM*0.04)){
                LOW_SPEED_OFF_FLAG = 1;
            }
        }
        else{
            if(MOTOR_TYPE == 0){
                Speed_Ref_IM = Speed_Ref_IM-(6.28*MOTOR_FREQ_DECR);
                if(Speed_Ref_IM < 33){
                    LOW_SPEED_OFF_FLAG = 1;
                }
            }
            if(MOTOR_TYPE == 1){
                Speed_Ref_PM = Speed_Ref_PM-(6.28*MOTOR_FREQ_DECR);
                if(Speed_Ref_PM < 125){
                    LOW_SPEED_OFF_FLAG = 1;
                }
            }
        }

    }
    else{
        if ((VDC_BUS_LPF_50 > VOC_START_VFD && flag_VFD_MPP_Initial == 1) || GRID_DETECTED == 1){
            if (CONTROL_MODE==0){
                if (Freq < Freq_Ref_VFD_Max && I_OUTPUT_AVG < MAX_OUTPUT_CURRENT && Motor_Power_LPF_1 < MAX_SOLAR_POWER){
                    Freq = Freq + MOTOR_FREQ_INCR;
                    //if (freq > (MAX_FREQ_SET_IM)) freq = MAX_FREQ_SET_IM;
                }
                if (Motor_Power_LPF_1 > MAX_PV_POWER_UPPER || I_OUTPUT_AVG > MAX_OUTPUT_CURRENT_UPPER || Freq > Freq_UPPER_LIMIT) {
                    Freq = Freq - MOTOR_FREQ_DECR;
                }
            }

            else{
                if(MOTOR_TYPE == 0){
                    if (Speed_Ref_IM < (Speed_Ref_VFD_Max) && I_OUTPUT_AVG < MAX_OUTPUT_CURRENT && Motor_Power_LPF_1 < MAX_SOLAR_POWER) {
                        Speed_Ref_IM = Speed_Ref_IM + 6.28 * MOTOR_FREQ_INCR;
                    }
                    //if (Speed_Ref > (6.28 * MAX_FREQ_SET_IM)) Speed_Ref = 6.28 * MAX_FREQ_SET_IM;
                    if (Motor_Power_LPF_1 > MAX_PV_POWER_UPPER || I_OUTPUT_AVG > MAX_OUTPUT_CURRENT_UPPER || Speed_Ref_IM > Speed_Ref_VFD_Max_UPPER) {
                        Speed_Ref_IM = Speed_Ref_IM - 6.28 * MOTOR_FREQ_DECR; // Need to add SPEED_STOP_INCREASE for vector control
                    }
                }
                if(MOTOR_TYPE == 1){
                    if (Speed_Ref_PM < (Speed_Ref_VFD_Max) && I_OUTPUT_AVG < MAX_OUTPUT_CURRENT_UPPER && Motor_Power_LPF_1 < MAX_SOLAR_POWER) {
                        Speed_Ref_PM = Speed_Ref_PM + 6.28 * MOTOR_FREQ_INCR;
                        ssfc11++;
                    }
                    //if (Speed_Ref > (6.28 * MAX_FREQ_SET_IM)) Speed_Ref = 6.28 * MAX_FREQ_SET_IM;
                    if (Motor_Power_LPF_1 > MAX_PV_POWER_UPPER || I_OUTPUT_AVG > (MAX_OUTPUT_CURRENT_UPPER)|| SPEED_STOP_INCREASE == true || Speed_Ref_PM > Speed_Ref_VFD_Max_UPPER) {
                        Speed_Ref_PM = Speed_Ref_PM - 6.28 * MOTOR_FREQ_DECR; // Need to add SPEED_STOP_INCREASE for vector control
                        ssfc12++;
                    }
                }
            }

            MPPT_VDC_REF = VDC_BUS_LPF_50;
            ssfc13++;
            flag_VFD_MPP_Initial = 1;
        }
        else{
            if(MPPT_START_FLAG == 1 && PM_flag_start == 0){
                flag_VFD_MPP_Initial = 0;
                if(dP>0){
                    if(dV>0){
                        MPPT_VDC_REF = MPPT_VDC_REF + V_DC_Step;
                        ssfc1++;
                    }
                    else{
                        MPPT_VDC_REF = MPPT_VDC_REF - V_DC_Step;
                        ssfc2++;
                    }
                }
                else if(dP<0){
                    if(dV>=0){
                        MPPT_VDC_REF = MPPT_VDC_REF - V_DC_Step;
                        ssfc3++;
                    }
                    else{
                        MPPT_VDC_REF = MPPT_VDC_REF + V_DC_Step;
                        ssfc4++;
                    }
                }
                else{
                    if(dV == 0 && MPPT_VDC_REF < VFD_VDC_REF_MIN){
                        MPPT_VDC_REF = MPPT_VDC_REF  + 0.4 * V_DC_Step;
                        ssfc5++;
                    }

                    if (Power > MAX_SOLAR_POWER || I_GRID_R_LPF_50 > I_PV_MAX || I_OUTPUT_AVG > MAX_OUTPUT_CURRENT || Freq >= Freq_Ref_VFD_Max
                    || FLAG_CORRES_SPEED_IM == 1 || Speed_Ref_PM >= (Speed_Ref_VFD_Max) || FLAG_CORRES_SPEED_PMSM == 1){
                        MPPT_VDC_REF = MPPT_VDC_REF; ssfc6++;
                       if (FLAG_CORRES_SPEED_IM ==1 || FLAG_CORRES_SPEED_PMSM == 1){
                                MPPT_VDC_REF = MPPT_VDC_REF +  0.1 * V_DC_Step;
                                ssfc9++;
                            }
                        if (I_OUTPUT_AVG > (MAX_OUTPUT_CURRENT_UPPER)){
                            MPPT_VDC_REF = MPPT_VDC_REF +  0.1 * V_DC_Step;
                            ssfc10++;
                        }
                        if(Power > (MAX_PV_POWER_UPPER)|| (I_OUTPUT_AVG > (MAX_OUTPUT_CURRENT_UPPER) && TEMP_INV > TEMP_DERATING_START) && TEMP_INV > TEMP_DERATING_START){
                            MPPT_VDC_REF = MPPT_VDC_REF +  V_PMAX_Step;
                            ssfc7++;
                        }
                        if(I_GRID_R_LPF_50 > (I_PV_MAX_UPPER)){
                            MPPT_VDC_REF = MPPT_VDC_REF +  V_IMAX_Step;
                            ssfc7++;
                        }
                    }
                    else{
                        MPPT_VDC_REF = MPPT_VDC_REF  - 0.1 * V_DC_Step;
                        ssfc8++;
                    }

                }
            }
        }
    }

    if(MPPT_VDC_REF < VFD_VDC_REF_MIN) MPPT_VDC_REF = VFD_VDC_REF_MIN;
    if(MPPT_VDC_REF > VFD_VDC_REF_MAX) MPPT_VDC_REF = VFD_VDC_REF_MAX;
}

void vfd_dcbus_cntrl_IM(){
    float VDC_VFD_error;

    if(SPEED_MODE_SELECT == 3){
        Setfreq_IM_MPPT = (SPEED_RPM_REF_UI)*RATED_POLE_IM * 0.0083333;
    }
    else{
        Setfreq_IM_MPPT = RATED_FREQ_IM;
    }

    Setfreq_IM_MPPT_Prev  = Setfreq_IM_MPPT * LPF_CONST_C1_1 + Setfreq_IM_MPPT_Prev * LPF_CONST_C2_1;
    Setfreq_IM_MPPT_LPF   = Setfreq_IM_MPPT_Prev * LPF_WC_1;

    Freq_Ref_Max_temp1           = fmaxf(Setfreq_IM_MPPT_LPF,Min_Threshhold_Freq);
    Freq_Ref_Max_temp2           = fminf(Freq_Ref_Max_temp1,RATED_FREQ_IM);      // Freq Saturation limit is set at SET FREQ, MAX FREQ
    Freq_Ref_VFD_Max             = fminf(Freq_Ref_Max_temp2,MAX_FREQ_SET_IM);     // or RATED FREQ, whichever is minimum
    VDC_VFD_ERROR_Integ_Max      = Freq_Ref_VFD_Max;
    VDC_VFD_ERROR_PI_Output_Max  = Freq_Ref_VFD_Max;
    Freq_UPPER_LIMIT             = Freq_Ref_VFD_Max * 1.02;
    if (MPPT_START_FLAG == 1 && SOFT_STOP_FLAG==false && flag_VFD_MPP_Initial == 0){
        VDC_VFD_error = VDC_BUS_MAF - MPPT_VDC_REF;
        Freq_Ref_MPPT = Vdc_Controller_TS_MPP(VDC_VFD_error);
        Freq = Freq_Ref_MPPT;

        if (Freq < Min_Threshhold_Freq) Freq = Min_Threshhold_Freq;
        if (Freq >= Freq_Ref_VFD_Max) Freq = Freq_Ref_VFD_Max;   //Freq limited to 110% of rated frequency
    }
    else{
        Last_VDC_VFD_ERROR_Integ = Freq;
    }
    if(ON_OFF_FLAG==0){
        VFD_VDC_KP1                 = 0.25 * VFD_VDC_KP;
        VDC_VFD_ERROR_Integ_Min     = Min_Threshhold_Freq;
        VDC_VFD_ERROR_PI_Output_Min = Min_Threshhold_Freq;
        Last_VDC_VFD_ERROR_Integ    = 0;
        VDC_VFD_ERROR_Integ         = 0;
        MPPT_VDC_REF                = VDC_BUS_LPF_50;
        VOC_START_VFD               = 0.95 *VDC_BUS_LPF_50;
        flag_VFD_MPP_Initial        = 1;
        Setfreq_IM_MPPT_Prev        = 0;

        MAX_PV_POWER_UPPER          = 1.05 * MAX_SOLAR_POWER;
        MAX_OUTPUT_CURRENT_UPPER    = 1.05 * MAX_OUTPUT_CURRENT;
        I_PV_MAX_UPPER                    = 1.05*I_PV_MAX;
    }

    // ssfc1=ssfc2=ssfc3=ssfc4=0;
    //ssfc5=ssfc6=ssfc7=ssfc8=0;
    // ssfc9=ssfc10=0;
}

void vfd_dcbus_cntrl_IMFOC(){ //DC Bus Voltage controller if motor is selected as IM and FOC is selected
    float VDC_VFD_error;


    if (SPEED_MODE_SELECT == 3) {
        Setfreq_IM_MPPT = (SPEED_RPM_REF_UI)*RATED_POLE_IM * 0.0083333;
    }
    else {
        Setfreq_IM_MPPT = RATED_FREQ_IM;
    }

    Setfreq_IM_MPPT_Prev  = Setfreq_IM_MPPT * LPF_CONST_C1_1 + Setfreq_IM_MPPT_Prev * LPF_CONST_C2_1;
    Setfreq_IM_MPPT_LPF   = Setfreq_IM_MPPT_Prev * LPF_WC_1;

    Freq_Ref_Max_temp1           = fmaxf(Setfreq_IM_MPPT_LPF,Min_Threshhold_Freq);
    Freq_Ref_Max_temp2           = fminf(Freq_Ref_Max_temp1,RATED_FREQ_IM);      // Freq Saturation limit is set at SET FREQ, MAX FREQ
    Freq_Ref_VFD_Max             = fminf(Freq_Ref_Max_temp2,MAX_FREQ_SET_IM);     // or RATED FREQ, whichever is minimum
    Speed_Ref_VFD_Max            = Freq_Ref_VFD_Max * 6.28;
    VDC_VFD_ERROR_Integ_Max      = Freq_Ref_VFD_Max;
    VDC_VFD_ERROR_PI_Output_Max  = Freq_Ref_VFD_Max;
    Speed_Ref_VFD_Max_UPPER      = Speed_Ref_VFD_Max*1.02;


    /*********Freq Saturation Limit ***************************/

    if (MPPT_START_FLAG == 1 && SOFT_STOP_FLAG == false && flag_VFD_MPP_Initial == 0 ){
        VDC_VFD_error  = VDC_BUS_LPF_50 - MPPT_VDC_REF;
        Freq_Ref_MPPT  = Vdc_Controller_TS_MPP(VDC_VFD_error);
        Speed_Ref_IM   = 6.28 * Freq_Ref_MPPT;

       // if (Speed_Ref_IM < Min_Threshhold_Freq) Speed_Ref_IM = Min_Threshhold_Freq;   // Need to correct the limits in terms of rad/sec
        if (Speed_Ref_IM >= Speed_Ref_VFD_Max) Speed_Ref_IM   = Speed_Ref_VFD_Max;      //Freq limited to 110% of rated frequency
    }
    else{
        Last_VDC_VFD_ERROR_Integ =  Speed_Ref_IM * 0.159155;
    }
    if(ON_OFF_FLAG == 0){
        Last_VDC_VFD_ERROR_Integ = 0;
        VDC_VFD_ERROR_Integ      = 0;
        VFD_VDC_KP1              = 0.25 * VFD_VDC_KP;
        MPPT_VDC_REF             = VDC_BUS_LPF_50;
        VOC_START_VFD            = 0.95 *VDC_BUS_LPF_50;
        flag_VFD_MPP_Initial     = 1;
        Setfreq_IM_MPPT_Prev     = 0;

        MAX_PV_POWER_UPPER                = 1.05 * MAX_SOLAR_POWER;
        MAX_OUTPUT_CURRENT_UPPER          = 1.05 * MAX_OUTPUT_CURRENT;
        I_PV_MAX_UPPER                    = 1.05*I_PV_MAX;
    }
    /*ssfc1=ssfc2=ssfc3=ssfc4=0;
        ssfc5=ssfc6=ssfc7=ssfc8=0;
        ssfc9=ssfc10=0;*/

}


void vfd_dcbus_cntrl_PMSM(){
   float VDC_VFD_error;
    if (SPEED_MODE_SELECT == 3){
        SetSpeed_PMSM_NewMPP = SPEED_RPM_REF_UI * No_of_Pole_Pair_PM * 0.0167;
/*
        if(FREQ_HZ_DISPLAY_PMSM > (SPEED_REF_INPUT_DISPLAY)*No_of_Pole_Pair*0.016366){                //0.0167*0.98 = 0.016366
            FLAG_SPEED_REF = true;
        }
        else if(FREQ_HZ_DISPLAY_PMSM < (SPEED_REF_INPUT_DISPLAY)*No_of_Pole_Pair*0.015531){           //0.0167*0.93 = 0.015531
            FLAG_SPEED_REF = false;
        }
        else{
            //NO WORK
        }*/
    }
    else{
        SetSpeed_PMSM_NewMPP = RATED_FREQ_PM;
    }

    SetSpeed_PMSM_NewMPP_Prev = SetSpeed_PMSM_NewMPP * LPF_Const_Slowest9 + SetSpeed_PMSM_NewMPP_Prev * LPF_Const_Slowest10;
    SetSpeed_PMSM_NewMPP_LPF  = SetSpeed_PMSM_NewMPP_Prev * LPF_Cutoff_Freq_Slowest4;

    Freq_Ref_Max_temp2          = fminf(SetSpeed_PMSM_NewMPP_LPF,RATED_FREQ_PM);
    Freq_Ref_VFD_Max            = fminf(Freq_Ref_Max_temp2,MAX_FREQ_SET_PM);
    Speed_Ref_VFD_Max           = Freq_Ref_VFD_Max * 6.28;
    //MAX_Freq_VFD_Ref_UPPER      = 1.02 * SPEED_REF_PMSM_TS_MAX;
    VDC_VFD_ERROR_Integ_Max     = Freq_Ref_VFD_Max;
    VDC_VFD_ERROR_PI_Output_Max = Freq_Ref_VFD_Max;
    Speed_Ref_VFD_Max_UPPER     = Speed_Ref_VFD_Max * 1.02;
    /*VDC_VFD_error  = VDC_BUS_LPF_50 - MPPT_VDC_REF;
    Freq_Ref_MPPT  = Vdc_Controller_TS_MPP(VDC_VFD_error);
    Speed_Ref_PM   = 6.28 * Freq_Ref_MPPT;*/

    if (MPPT_START_FLAG == 1 && SOFT_STOP_FLAG==false /*&& SPEED_MODE_SELECT!= 3*/ && flag_VFD_MPP_Initial == 0 /*&& SPEED_STOP_INCREASE == false*/){
        VDC_VFD_error = VDC_BUS_LPF_50 - MPPT_VDC_REF;
        Freq_Ref_MPPT = Vdc_Controller_TS_MPP(VDC_VFD_error);
       // F_REF_PMSM_TS = DEL_F_TS_MPP;
        Speed_Ref_PM = 6.28 * Freq_Ref_MPPT;
        if (Speed_Ref_PM >= Speed_Ref_VFD_Max) Speed_Ref_PM = Speed_Ref_VFD_Max;
    }
    else{
        Last_VDC_VFD_ERROR_Integ =  Speed_Ref_PM/6.28 ;
    }
    if (Speed_Ref_PM < Speed_Ref_PM_Min) Speed_Ref_PM = Speed_Ref_PM_Min;
    if(ON_OFF_FLAG==0){
        /*if(PUMP_TYPE == 2){
            temp_K_MPP_TS = frated_PMSM1 / Prated_PMSM;
            K_MPP_TS = MPP_LOAD_FACTOR * temp_K_MPP_TS;   //The feed-forward term is a having a factor of 0.9
        }
        else
        {
            temp_K_MPP_TS = frated_PMSM / Prated_PMSM;
            K_MPP_TS = MPP_LOAD_FACTOR * cbrt(temp_K_MPP_TS);   //The feed-forward term is a having a factor of 0.95
        }*/

        VFD_VDC_KP1 = VFD_VDC_KP;
        Last_VDC_VFD_ERROR_Integ = 0;
        VDC_VFD_ERROR_Integ = 0;
        VDC_VFD_ERROR_Integ_Min = Speed_Ref_PM_Min / 6.28;
        VDC_VFD_ERROR_PI_Output_Min = Speed_Ref_PM_Min / 6.28;
        SetSpeed_PMSM_NewMPP_Prev = 0;
        MPPT_VDC_REF  = VDC_BUS_LPF_50;
        VOC_START_VFD = 0.95 *VDC_BUS_LPF_50;
        flag_VFD_MPP_Initial = 1;
        Freq_Ref_MPPT = 0;
        V_DC_Step = VFD_VDC_STEP;
        ssfc1=ssfc2=ssfc3=ssfc4=0;
        ssfc5=ssfc6=ssfc7=ssfc8=0;
        ssfc9=ssfc10=0;
        SPEED_STOP_INCREASE = false;

        MAX_PV_POWER_UPPER                = 1.05 * MAX_SOLAR_POWER;
        MAX_OUTPUT_CURRENT_UPPER          = 1.05 * MAX_OUTPUT_CURRENT;
        I_PV_MAX_UPPER                    = 1.05*I_PV_MAX;
    }
}
