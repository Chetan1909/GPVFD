/*
 * ADC_ISR.c
 *
 *  Created on: 13-May-2023
 *      Author: Manoj Modi
 */
#include <Headers/Project_Header/Init.h>



__interrupt void adcA1ISR(void){
    /*if(MOTOR_POWER>7500){

        CURR_OFFSET_ACS720 = 2252;       //TI
        CURR_GAIN          = 0.019024;
    }else{
        CURR_OFFSET_ACS720 = 2048;       //Allegro
        CURR_GAIN          =0.035723;
    }*/
  //GpioDataRegs.GPBSET.bit.GPIO39 = 1;
    if(SysTime_mSec_IntervalElapsed(Blink_LED, 500)){
        Blink_LED = mSeconds;
       GpioDataRegs.GPBTOGGLE.bit.GPIO39 = 1;                  // HEART_BEAT

    }
    Update_Time();                                              // TIME UPDATION
    Read_ADC();                                                 // ADC SENSING
    Faults_and_Warnings_Manager();                              // FAULTS AND WARNINGS MANAGER
    if(MOTOR_TYPE == 0){
        if(CONTROL_MODE == 1){
            Scaler_Control_IM();
           /* Speed_Estimation_PMSM();
            Vector_Control_PMSM();*/
           // Speed_Estimation_IM(); // temp  for Debug purpose
            vfd_dcbus_cntrl_IM();
        }

        if(CONTROL_MODE == 2){
            Vector_Control_IM();
            vfd_dcbus_cntrl_IMFOC();
        }
    }

    if(MOTOR_TYPE == 1){  // for testing 20012025 display
        if(CONTROL_MODE == 2){
            Vector_Control_PMSM();
            vfd_dcbus_cntrl_PMSM();
        }
    }

    if(MOTOR_TYPE == 2){
        if(CONTROL_MODE == 2){
            Vector_Control_SynRM();
        }
    }

    if(MPPT_Counter>=MPPT_CALLING_FRQ){
        VBased_MPPT();
        MPPT_Counter = 0;
    }


    Cmpss1Regs.DACLVALS.all                     = DAC;
    /***************Reset the faults********/
    if(FLT_RST == 1){               //Fault reset-CS130525
        FAULT_CODE = 0;
        FLT_RST =0;
    }
    /***************Reset the faults********/

    /***************Set the Direction of motor********/
    if(DIR_ROTATION == 0){               //Direction-CS130525
        SPEED_FORWARD = 0;      //Motor Reverse
       }
    else if (DIR_ROTATION == 1){
        SPEED_FORWARD = 1;      //Motor FWD
    }
    /***********************************************/
    if(ON_OFF_FLAG == true){
        MPPT_Counter++;
        Energy_and_Flow_Meter();
        if(FAULT_CODE !=0){
            ON_OFF_FLAG                         = false;
            TZ_FRC_PWM_low();
            GpioDataRegs.GPHSET.bit.GPIO228     = 1;
        }

    }
    else{
        MPPT_Counter = 0;
        Low_Power_Test = Minute_Count;
    }


    if(VDC_BUS < 120.00){
        ON_OFF_FLAG = false;
        GpioDataRegs.GPASET.bit.GPIO1 = 1;  //LPS_CTRL// in case of rev 04-GPIO29
    }
    /*else{
        GpioDataRegs.GPACLEAR.bit.GPIO1 = 1;//LPS_CTRL
    }*/

    GpioDataRegs.GPASET.bit.GPIO20 = 1;     // Precharge Relay On

//    if(SysTime_Minute_Count_IntervalElapsed(Low_Power_Test, 1)){
//        Low_Power_Test = Minute_Count;
//        if (P_PV_Avg < 700 &&  ON_OFF_FLAG == true){
//            ON_OFF_FLAG = false;
//        }
//    }

/*    if (P_PV_Avg > 2100){
        VFD_VDC_STEP = 2.4;
    }
    else{
        VFD_VDC_STEP = 5;
    }*/
    if (TEMP_INV < 35){
        GpioDataRegs.GPASET.bit.GPIO23 = 1;     // Fan OFF
    }
    else if (TEMP_INV > 40){
        GpioDataRegs.GPACLEAR.bit.GPIO23 = 1;     // Fan ON
    }
    else{
        // No Work
    }

    // Clear the interrupt flag
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

    // Check if overflow has occurred
    if(1 == AdcaRegs.ADCINTOVF.bit.ADCINT1){
        AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
        AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag
    }

   // GpioDataRegs.GPBCLEAR.bit.GPIO39 = 1;
    // Acknowledge the interrupt
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

/***************************************TZ_ISR***********************************************/
/*
 * This interrupt is for detecting the event of short circuit immediately. As the name suggests
 * the trip zone interrupt comes whenever the GPIO configured as an input goes low. The GPIO
 * sets a flag based on which we declare the Short circuit fault.
 */
/********************************************************************************************/

__interrupt void epwmFlt_isr(void){

    // Put Fault conditions and other flags here
    if(ALL_PWM_LOW != 1){
        TZ_FRC_PWM_low();
    }

    GpioDataRegs.GPHSET.bit.GPIO228     = 1;                // To enable Gate Driver ICs
    DELAY_US(500);
    GpioDataRegs.GPHCLEAR.bit.GPIO228       = 1;

    EALLOW;
    EPwm4Regs.TZOSTCLR.bit.OST1 = 1;
    EPwm4Regs.TZCLR.bit.OST = 1;
    EPwm4Regs.TZCLR.bit.INT = 1;
    EALLOW;

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;
}

/*************************************FLOW CALCULATION****************************************/
void Flow_manager(void){
    if(ON_OFF_FLAG == true){

           if (MOTOR_TYPE == 2){
               Rated_Speed_info =  6.28*RATED_FREQ_PM;
           }
           else {
               Rated_Speed_info = 6.28*RATED_FREQ_IM;
           }

           if (Rated_Speed_info <1) Rated_Speed_info = 1;

           if (PUMP_TYPE ==2){
               flow_LPM = RATED_LPM*(speed_info/Rated_Speed_info);
           }
           else{
               if (P_Motor_Slowest < POW1){
                   flow_LPM = 0;
               }
               else if(P_Motor_Slowest >= POW1 && P_Motor_Slowest < POW2){
                   flow_LPM = D1+((D2-D1)*(P_Motor_Slowest -POW1)/(POW2-POW1));
                   if((POW2-POW1) <= 0){
                       flow_LPM =D2;
                   }
               }
               else if (P_Motor_Slowest > POW2 && P_Motor_Slowest < POW3){
                   flow_LPM = D2+((D3-D2)*(P_Motor_Slowest -POW2)/(POW3-POW2));
                   if((POW3-POW2) <= 0){
                       flow_LPM =D3;
                   }
               }
               else if (P_Motor_Slowest > POW3 && P_Motor_Slowest < POW4){
                   flow_LPM = D3+((D4-D3)*(P_Motor_Slowest -POW3)/(POW4-POW3));
                   if((POW4-POW3) <= 0){
                       flow_LPM =D4;
                   }

               }
               else if (P_Motor_Slowest > POW4 && P_Motor_Slowest < POW5){
                   flow_LPM = D4+((D5-D4)*(P_Motor_Slowest -POW4)/(POW5-POW4));
                   if((POW5-POW4) <= 0){
                       flow_LPM =D5;
                   }

               }
               else{
                   flow_LPM = D4+((D5-D4)*(P_Motor_Slowest -POW4)/(POW5-POW4));

                   if((POW5-POW4) <= 0){
                       flow_LPM =D5;
                   }
               }

           }
       }
       else{
           flow_LPM = 0;
       }
       if(flow_LPM > 6500){
           flow_LPM =6500;
       }
}




//float Power_Interval,Energy_Interval, Energy_Avg;
void Energy_and_Flow_Meter(void){
    if(ON_OFF_FLAG){
        if(SysTime_Minute_Count_IntervalElapsed(Power_Interval, 0.1)){
            Power_Interval  = Minute_Count;
            Energy_Avg       = Energy_Avg + P_PV_Avg*0.1;
            Flow_L_Avg        = Flow_L_Avg + flow_LPM*0.1;
            if(SysTime_Minute_Count_IntervalElapsed(Energy_Interval,1)){
                Energy_Interval = Minute_Count;
                Cumulative_Energy    = Cumulative_Energy + (Energy_Avg/60000); //KWH
                Cummulative_Water_Discharge      = Cummulative_Water_Discharge + (Flow_L_Avg/1000000);    //In Mega litre
                Cumulative_Run_Hrs      = Cumulative_Run_Hrs + 0.0167;                // it is in hours
                Energy_Avg       = 0;
                Flow_L_Avg        = 0;
            }
        }
    }
    else{
        Energy_Avg = 0;
        Flow_L_Avg  = 0;
    }
}
