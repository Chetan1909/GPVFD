/*
 * Scaler_Control_Induction_Motors.c
 *
 *  Created on: Jul 21, 2023
 *      Author: Dell
 */
#include <Headers/Project_Header/Init.h>

 Uint16 duty1=0, duty3=0, duty5=0, duty1_Max;
void Scaler_Control_IM(){
    //Uint16 duty1=0, duty3=0, duty5=0;
    if(ON_OFF_FLAG == true){

        if(ALL_PWM_LOW == true){
            //Re-Init
        }


        /*if(SPEED_MODE_SELECT == 3){
            Set_Freq = SPEED_RPM_REF_UI * RATED_POLE_IM * 0.0083333;  // This portion of the code should move it to forground task
        }
        else{
            Set_Freq = RATED_FREQ_IM;
        }*/


        VbyF_Ratio                 = RATED_VOLT_IM/RATED_FREQ_IM;
      /*if(Set_Freq > (RATED_FREQ_IM * 1.05)) Set_Freq = (RATED_FREQ_IM * 1.05);
      if(Set_Freq < (RATED_FREQ_IM * 0.02)) Set_Freq =  (RATED_FREQ_IM * 0.02);
*/
        if(Set_Freq > 800) Set_Freq = 800;
        if(Set_Freq < 2)   Set_Freq =  2;

        //*********************************LPF On Set_Freq*************************************************************//
//        Set_Freq_LPF_Prev        = Set_Freq * LPF_CONST_C1_1 + Set_Freq_LPF_Prev * LPF_CONST_C2_1;
//        Set_Freq_LPF             = Set_Freq_LPF_Prev *  LPF_WC_1;
        Set_Freq_LPF = Setfreq_IM_MPPT_LPF;
        //*********************************LPF On Set_Freq end ********************************************************//
        if(Set_Freq_LPF < 1) Set_Freq_LPF = 1;

        if(Count>=1){
            Count = 0;
            if (Freq > 0.5 && Freq < 15 ){
                FREQ_STEP = 0.25;//0.1;//1;
            }
            else  if (Freq > 15 && Freq < 30 ){
                FREQ_STEP = 0.1;//0.05;//0.5;
            }
            else{
                FREQ_STEP = 0.1;//25;//0.25;
            }
            if(SOFT_STOP_FLAG == true){
               // FREQ_STEP = 12.5/Freq;
                //if(FREQ_STEP > 0.25){
               //     FREQ_STEP = 0.25;
               // }
                //FREQ_STEP = 0.125;
                //Freq = Freq - FREQ_STEP;
                //if(Freq < 2){
                   // ON_OFF_FLAG    = 0;
                  //  SOFT_STOP_FLAG = 0;
                 //   MASTER_ON_OFF = 0;
                 //   EEPROM_WriteInt(2,12,0);   //  MASTER_ON_OFF
                ///}
            }
            else{
                if(Freq < Set_Freq_LPF){
                    //FREQ_STEP = 0.1;
                    Freq = Freq + FREQ_STEP;
                }
                else{
                    Freq = Set_Freq_LPF;
                }
            }

        }


        if((Set_Freq - Set_Freq_Past)>0){
            FREQ_UP_FLAG = 0;
            if(Freq >= Set_Freq){
                SET_FREQ_ACHIEVED = 1;
                Set_Freq_Past = Set_Freq;
            }
            else{
                SET_FREQ_ACHIEVED = 0;
            }
        }

        if((Set_Freq_Past - Set_Freq)>=0){
            FREQ_UP_FLAG = 1;
            if(Freq <= Set_Freq){
                SET_FREQ_ACHIEVED = 1;
                Set_Freq_Past = Freq;
            }
            else{
                SET_FREQ_ACHIEVED = 0;
            }
        }
        if (((Freq >=10) || (SysTime_Minute_Count_IntervalElapsed(Exit_Count_SS,0.2)))&& MPPT_START_FLAG == 0){
            Exit_Count_SS = Minute_Count;
            MPPT_START_FLAG = 1;
            PM_flag_start   = 0;

        }


        Theta1 = Theta1 + Theta_Increment;
        //***********************************************getVRMS*******************************************************************/
        VRMS = VbyF_Ratio*Freq; // here 8.30 is the ratio of motor rated line voltage to the rated freq.

        Init_Voltage_Perc = INITIAL_VOLTPERCENT_FACTOR - (Freq * INITIAL_VOLTPERCENT_FACTOR/RATED_FREQ_IM);

        if(Init_Voltage_Perc > INITIAL_VOLTPERCENT_FACTOR){
            Init_Voltage_Perc = INITIAL_VOLTPERCENT_FACTOR;
        }
        if(Init_Voltage_Perc < 0){
            Init_Voltage_Perc = 0;
        }

        Init_Voltage_Addition = Init_Voltage_Perc * RATED_VOLT_IM;

        VRMS = VRMS + Init_Voltage_Addition;

        if(VRMS > RATED_VOLT_IM){
            VRMS = RATED_VOLT_IM;
        }
        //************************************************Calc_modulation_index***************************************************/


        Max_RMS_Possible = 0.704*VDC_BUS_LPF_1; //sqrt(3)*0.99*VDC/2sqrt(2)
        Corres_Freq = Max_RMS_Possible / VbyF_Ratio;
        if (Freq > Corres_Freq){
            Freq = Corres_Freq;
            FLAG_CORRES_SPEED_IM = 1;
        }
        else{
            FLAG_CORRES_SPEED_IM = 0;
        }

        Speed_Ref_IM = Freq * 6.28;
        Mod_Index = VRMS/Max_RMS_Possible;

        if(Mod_Index > 1.148){// 1.1547*0.99
            Mod_Index = 1.148;
        }
        else if (Mod_Index < 0.02){
            Mod_Index = 0.02;
        }

        //***********************************************************************************************************************/


        if(Theta1 > 1){
            Count++;
            Theta1= Theta1-1; //This is to reset thetar1 to 0 degree
        }

        Theta2 = Theta1+0.66666; //Y-phase

        if(Theta2 > 1){
            Theta2= Theta2-1;
        }

        Theta_Increment = Ts*Freq;
        Sin1 = sinf(Theta1 * 6.2831); //R-phase assumption V=VmCos(Theta)
        Sin2 = sinf(Theta2 * 6.2831); //Y-phase assumption V=VmCos(Theta- 120)
        Sin3 = -Sin1-Sin2;          //B-phase assumption V=VmCos(Theta- 240)

        Max = fmaxf(Sin1, Sin2);
        Max = fmaxf(Max,Sin3);

        Min = fminf(Sin1, Sin2);
        Min = fminf(Min,Sin3);

        Mid = -(Max+Min)*0.5;

      // Dead band compensation
 /*       if(I_INV_R > 0){
            Dead_Band_Comp_R =  -Dead_Band_Comp;
        }
        else{
            Dead_Band_Comp_R =  Dead_Band_Comp;
        }

        if(I_INV_Y > 0){
            Dead_Band_Comp_Y =  -Dead_Band_Comp;
        }
        else{
            Dead_Band_Comp_Y =  Dead_Band_Comp;
        }

        if(I_INV_B > 0){
            Dead_Band_Comp_B =  -Dead_Band_Comp;
        }
        else{
            Dead_Band_Comp_B =  Dead_Band_Comp;
        }*/


        //CSVPWM implementation
        if(SPEED_FORWARD){
            Sin1_CSVPWM = 1.1547*(Sin1) + Mid + Dead_Band_Comp_R;
            Sin2_CSVPWM = 1.1547*(Sin2) + Mid + Dead_Band_Comp_Y;
            Sin3_CSVPWM = 1.1547*(Sin3) + Mid + Dead_Band_Comp_B;
        }
        else if(!SPEED_FORWARD){
            Sin1_CSVPWM = 1.1547*(Sin2) + Mid + Dead_Band_Comp_Y;
            Sin2_CSVPWM = 1.1547*(Sin1) + Mid + Dead_Band_Comp_R;
            Sin3_CSVPWM = 1.1547*(Sin3) + Mid + Dead_Band_Comp_B;
        }

        duty1 = floorf(INVERTER_PERIOD*((Mod_Index*0.5*Sin1_CSVPWM)+0.5));
        duty3 = floorf(INVERTER_PERIOD*((Mod_Index*0.5*Sin2_CSVPWM)+0.5));
        duty5 = floorf(INVERTER_PERIOD*((Mod_Index*0.5*Sin3_CSVPWM)+0.5));
        if (duty1_Max < duty1){
            duty1_Max = duty1;
        }

        EPwm5Regs.CMPA.bit.CMPA = duty1;   //R
        EPwm5Regs.CMPB.bit.CMPB = duty1;

        EPwm6Regs.CMPA.bit.CMPA = duty3;   //Y
        EPwm6Regs.CMPB.bit.CMPB = duty3;

        EPwm7Regs.CMPA.bit.CMPA = duty5;   //B
        EPwm7Regs.CMPB.bit.CMPB = duty5;

        if(ALL_PWM_LOW == true && PWM_Release_Flag == 10){
            //Relesase pluses
            TZ_CLR_PWM();
            GpioDataRegs.GPHCLEAR.bit.GPIO228     = 1;
        }

        PWM_Release_Flag++;
        if(PWM_Release_Flag > 10){
            PWM_Release_Flag = 10;
        }
    }
    else if(ON_OFF_FLAG == false){
        TZ_FRC_PWM_low();
        GpioDataRegs.GPHSET.bit.GPIO228     = 1;
        PWM_Release_Flag  = false;

        EPwm5Regs.CMPA.bit.CMPA = 0;   //R
        EPwm5Regs.CMPB.bit.CMPB = 0;

        EPwm6Regs.CMPA.bit.CMPA = 0;   //Y
        EPwm6Regs.CMPB.bit.CMPB = 0;

        EPwm7Regs.CMPA.bit.CMPA = 0;   //B
        EPwm7Regs.CMPB.bit.CMPB = 0;

        MPPT_START_FLAG    = 0;
        Theta1             = 0.25;
        Theta2             = 0;
        Count              = 2;
        Freq               = 1;
        Set_Freq_LPF_Prev  = 0;
        Sin1_CSVPWM        = 0;
        Sin2_CSVPWM        = 0;
        Sin3_CSVPWM        = 0;
        Sin1               = 0;
        Sin2               = 0;
        Sin3               = 0;
        Mod_Index          = 0;
        VRMS               = 0;
        Mid                = 0;
    }
    else{
        //No Work
    }







}
