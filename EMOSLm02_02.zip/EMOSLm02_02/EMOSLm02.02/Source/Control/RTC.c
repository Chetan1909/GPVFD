/*
 * RTC.c
 *
 *  Created on: Jul 12, 2023
 *      Author: Dell
 */



/*****************************************ABOUT**********************************************/
/*
 * This file has implemented an internal clock using the interrupt frequency of ADC ISR. This
 * clock and related functions are used in several places such as to check occurrence of
 * faults and to reset the fault after a certain time etc. The function value is dependent on
 * the interrupt frequency set as the value of Tick_Tick is updated at every interrupt.
 */
/********************************************************************************************/

#include <Headers/Project_Header/Init.h>

void Update_Time(void){
    Tick_Tick++;
    if(Tick_Tick > 19){
        mSeconds++;
        Tick_Tick1++;
        Tick_Tick = 0;
        if(mSeconds > 999){
            mSeconds =0;
        }
    }
    if(Tick_Tick1 > 9){
        Minute_Count = Minute_Count+0.000166667;
        Tick_Tick1 =0;
    }
    if(Minute_Count > Tick_Tick_Minute_Reset){
        Minute_Count = 0;
    }
}

//bool SysTime_mSec_IntervalElapsed(Uint32 startTime, Uint32 interval){
//    return ((Uint32)(mSeconds - startTime) >= interval)?true:false;
//}

bool SysTime_mSec_IntervalElapsed(Uint32 startTime, Uint32 interval){
    int32 Reset_Tick_Tick_mSec_Reset;

    Reset_Tick_Tick_mSec_Reset = mSeconds - startTime;

    if(Reset_Tick_Tick_mSec_Reset < 0){
        Reset_Tick_Tick_mSec_Reset = Reset_Tick_Tick_mSec_Reset + 1000;
    }

    return ((Uint32)(Reset_Tick_Tick_mSec_Reset) >= interval)?true:false;
}

//bool SysTime_Minute_Count_IntervalElapsed(float startTime, float interval){
//    return ((float)(Minute_Count - startTime) >= interval)?true:false;}

bool SysTime_Minute_Count_IntervalElapsed(float startTime, float interval){
    float Reset_Tick_Tick_Minute_Reset;

    Reset_Tick_Tick_Minute_Reset = Minute_Count - startTime;

    if(Reset_Tick_Tick_Minute_Reset < 0)
    {Reset_Tick_Tick_Minute_Reset = Reset_Tick_Tick_Minute_Reset + Tick_Tick_Minute_Reset;}

    return ((float)(Reset_Tick_Tick_Minute_Reset) >= interval)?true:false;}


