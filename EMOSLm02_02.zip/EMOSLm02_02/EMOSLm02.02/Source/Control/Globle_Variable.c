/*
 * Variable.c
 *
 *  Created on: 05-Aug-2023
 *      Author: manoj
 */
#include <Headers/Project_Header/Init.h>
/*
 * Admin Para
 */
#pragma LOCATION(FACTORY_MODE, 0x0000A000)                              //Factory mode
#pragma LOCATION(LANGUAGE_SELECTED, 0x0000A002)                         //LANGUAGE_SELECTED
//#pragma LOCATION(ACCESS_ENABLE, 0x0000A004 )                          //ACCESS_ENABLE
//#pragma LOCATION(ACCESS_PASSWORD, 0x0000A006)                         //ACCESS_PASSWORD
#pragma LOCATION(EEPROM_DATA_VALID_FLAG, 0x0000A008)                    //EEPROM_DATA_VALID_FLAG
#pragma LOCATION(Retry_time_Minutes_EEPROM,0x0000A00A)                  //Retry_time_Minutes_EEPROM
#pragma LOCATION(MASTER_ON_OFF, 0x0000A00C)                             //Master ON/OFF
#pragma LOCATION(Firmware_Version, 0x0000A00E)                          //Firmware Verison
#pragma LOCATION(Date_RTC,0x0000A010)                                   //Date RTC
#pragma LOCATION(Month_RTC,0x0000A012)                                  //Month RTC
#pragma LOCATION(Year_RTC,0x0000A014)                                   //Year RTC
#pragma LOCATION(Hour_RTC,0x0000A016)                                   //Hour RTC
#pragma LOCATION(Minute_RTC,0x0000A018)                                 //Minute RTC
#pragma LOCATION(Device_State_Type,0x0000A01A)                          //Device_State_Type
#pragma LOCATION(Device_Type,0x0000A01C)                                //Device_Type
#pragma LOCATION(Device_Sr_No,0x0000A01E)                               //Device_Sr_No
#pragma LOCATION(Date_Code,0x0000A020)                                  //Date_Code


// Application parameter
#pragma LOCATION(MOTOR_TYPE, 0x0000A100)                    //Motor Type
#pragma LOCATION(APPLICATION_MODE, 0x0000A102)              //Application Mode
#pragma LOCATION(CONTROL_MODE, 0x0000A104)                  //Motor Control Mode

/*
 *Motor Parameter IM
 */

#pragma LOCATION(RATED_VOLT_IM, 0x0000A200)                 // Induction Motor Nominal Voltage
#pragma LOCATION(RATED_CURR_IM, 0x0000A202)                 // Induction Motor Nominal Current
#pragma LOCATION(RATED_FREQ_IM, 0x0000A204)                 // Induction Motor Nominal Frequency
#pragma LOCATION(RATED_OMEGA_IM, 0x0000A206)                // Induction Motor Nominal Speed
#pragma LOCATION(MOTOR_POWER, 0x0000A208)                   // Induction Motor Nominal Power // Torque
#pragma LOCATION(RATED_COS_PHI_IM, 0x0000A20A)              // Induction Motor Nominal PF
#pragma LOCATION(W_Slip_Est, 0x0000A20C)                    // Induction Motor Nominal Slip
#pragma LOCATION(Rs, 0x0000A20E)                            // InductionMotor stator Resistance
#pragma LOCATION(Rr, 0x0000A210)                            // Induction Motor rotor Resistance
#pragma LOCATION(Llr, 0x0000A212)                           // Induction Motor Llr
#pragma LOCATION(Lls, 0x0000A214)                           // Induction Motor Lls
#pragma LOCATION(Lm, 0x0000A216)                            // Induction Motor Lm
#pragma LOCATION(RATED_POLE_IM, 0x0000A218)                 // Induction Motor poles
#pragma LOCATION(TORQUE_PERCENT_IM, 0x0000A21A)             // Induction Stall Torque perc limit


/*
 *Motor Parameter PMSM
 */

#pragma LOCATION(RATED_VOLT_PM, 0x0000A300)                 // PMSM Motor Nominal Voltage
#pragma LOCATION(RATED_CURR_PM, 0x0000A302)                 // PMSM Motor Nominal Current
#pragma LOCATION(RATED_FREQ_PM, 0x0000A304)                 // PMSM Motor Nominal Frequency
#pragma LOCATION(RATED_OMEGA_PM, 0x0000A306)                // PMSM Motor Nominal Speed
#pragma LOCATION(MOTOR_POWER_PM, 0x0000A308)                   // PMSM Motor Nominal Power // Torque
#pragma LOCATION(RATED_COS_PHI_PM, 0x0000A30A)              // PMSM Motor Nominal PF
#pragma LOCATION(Rs_PM, 0x0000A30C)                            // PMSM stator Resistance
#pragma LOCATION(Ld_PM, 0x0000A30E)                            // PMSM Motor rotor Resistance
#pragma LOCATION(Lq_PM, 0x0000A310)                           // PMSM Motor Llr
#pragma LOCATION(RATED_POLE_PM, 0x0000A312)                 // PMSM Motor poles
#pragma LOCATION(TORQUE_PERCENT_PM, 0x0000A314)             // PMSM Stall Torque perc limit
#pragma LOCATION(IMP_FACTOR, 0x0000A316)             // IMP_FACTOR

/*
 *Motor Parameter SynRM
 */

//#pragma LOCATION(RATED_VOLT_IM, 0x0000A400)                 // Induction Motor Nominal Voltage
//#pragma LOCATION(RATED_CURR_IM, 0x0000A402)                 // Induction Motor Nominal Current
//#pragma LOCATION(RATED_FREQ_IM, 0x0000A2404)                 // Induction Motor Nominal Frequency
//#pragma LOCATION(RATED_OMEGA_IM, 0x0000A406)                // Induction Motor Nominal Speed
//#pragma LOCATION(MOTOR_POWER, 0x0000A408)                   // Induction Motor Nominal Power // Torque
//#pragma LOCATION(RATED_COS_PHI_IM, 0x0000A40A)              // Induction Motor Nominal PF
//#pragma LOCATION(W_Slip_Est, 0x0000A40C)                    // Induction Motor Nominal Slip
//#pragma LOCATION(Rs, 0x0000A40E)                            // InductionMotor stator Resistance
//#pragma LOCATION(Rr, 0x0000A410)                            // Induction Motor rotor Resistance
//#pragma LOCATION(Llr, 0x0000A412)                           // Induction Motor Llr
//#pragma LOCATION(Lls, 0x0000A414)                           // Induction Motor Lls
//#pragma LOCATION(Lm, 0x0000A416)                            // Induction Motor Lm
//#pragma LOCATION(RATED_POLE_IM, 0x0000A418)                 // Induction Motor poles
////#pragma LOCATION(MOTOR_ID, 0x0000A420)                    //Induction Motor ID              0 - 1HP,1-2HP and so on
//#pragma LOCATION(TORQUE_PERCENT_IM, 0x0000A41A)             // Induction Stall Torque perc limit

/*
 *Speed Selection
 */
#pragma LOCATION(SPEED_MODE_SELECT, 0x0000A500)             //SPEED_MODE_SELECT
#pragma LOCATION(CONST_SPEED_REF_SOURCE, 0x0000A502)        // Constant speed select
#pragma LOCATION(CONST_SPEED_REF_1, 0x0000A504)             //Constant speed 1
#pragma LOCATION(CONST_SPEED_REF_2, 0x0000A506)             //Constant speed 2
#pragma LOCATION(CONST_SPEED_REF_3, 0x0000A508)             //Constant speed 3
#pragma LOCATION(CONST_SPEED_REF_4, 0x0000A50A)             //Constant speed 4
#pragma LOCATION(CONST_SPEED_REF_5, 0x0000A50C)             //Constant speed 5
#pragma LOCATION(CONST_SPEED_REF_6, 0x0000A50E)             //Constant speed 6
#pragma LOCATION(CONST_SPEED_REF_7, 0x0000A510)             //Constant speed 7
#pragma LOCATION(CONST_SPEED_REF_8, 0x0000A512)             //Constant speed 8
#pragma LOCATION(CONST_SPEED_REF_9, 0x0000A514)             //Constant speed 9
#pragma LOCATION(VARIABLE_SPEED_REF_SOURCE, 0x0000A516)        // Variable speed select
#pragma LOCATION(SPEED_RPM_REF_UI, 0x0000A518)              //RPM

/*
 * Protection Enable
 */
#pragma LOCATION(INPUT_UNBALANCE_LIMIT, 0x0000A600)             //I/P unbalance enable
#pragma LOCATION(UV_Enable, 0x0000A602)                         //UV enable
#pragma LOCATION(OV_Enable, 0x0000A604)                         //OV enable
#pragma LOCATION(OVER_TEMP_Enable, 0x0000A606)                  //Over temp enable
#pragma LOCATION(OC_Enable, 0x0000A608)                         //OC enable
#pragma LOCATION(Over_Load_enable, 0x0000A60A)                //Over torque enable
#pragma LOCATION(Over_Speed_Enable, 0x0000A60C)                 //Over speed enable
#pragma LOCATION(DRY_Run_Enable, 0x0000A60E)                    //Dry run enable


/*
 * Protection limits
 */
#pragma LOCATION(INPUT_VOLT_UNBALANCE_LIMIT, 0x0000A700)        //I/P volt unbalance limit
#pragma LOCATION(DC_BUS_OV_LIMIT, 0x0000A702)                   //DC bus overvoltage
#pragma LOCATION(DCBUS_UNDER_VOLT, 0x0000A704)                  //DC bus undervoltage
#pragma LOCATION(VFD_OVER_TEMP_LIMIT, 0x0000A706)               //Over temp limit.........................
#pragma LOCATION(VFD_OVER_TEMP_LIMIT_1, 0x0000A708)               //Over temp limit...........................
#pragma LOCATION(VFD_OVER_TEMP_LIMIT_2, 0x0000A70A)               //Over temp limit.........................
#pragma LOCATION(OVER_CURR_LIMIT, 0x0000A70C)                   //Over current limit
#pragma LOCATION(MAX_CURR_LIMIT, 0x0000A70E)                    //Max current limit
#pragma LOCATION(DRY_RUN_CURR_LIMIT, 0x0000A710)                //Dry run current limit
#pragma LOCATION(DRY_RUN_POWER_LIMIT, 0x0000A712)               //Dry run power limit
#pragma LOCATION(VFD_OVER_VOLT_LIMIT, 0x0000A714)               //VFD over volt limit
#pragma LOCATION(Torue_MIN, 0x0000A716)                         //Torque min
#pragma LOCATION(Torque_Max, 0x0000A718)                        //Torque max
#pragma LOCATION(Speed_Min, 0x0000A71A)                         //Speed Min
#pragma LOCATION(Speed_Max, 0x0000A71C)                         //Speed Max
#pragma LOCATION(Freq_Min, 0x0000A71E)                          //Freq Min
#pragma LOCATION(Freq_Max, 0x0000A720)                          //Freq max
#pragma LOCATION(MAX_SOLAR_POWER, 0x0000A722)                   //MAX_PV_POWER
#pragma LOCATION(I_PV_MAX, 0x0000A724)                          //MAX_PV_CURRENT
#pragma LOCATION(MAX_OUTPUT_CURRENT, 0x0000A726)                //MAX_OUTPUT_CURRENT


//#pragma LOCATION(DC_BUS_OV_RESET_HYS, 0x0000A33A)               //Hys DC Bus Over voltage
//#pragma LOCATION(PMSM_MIN_RPM, 0x0000A33C)                      //PMSM Minimum Power

/*
 * PID control parameters IM
 */
#pragma LOCATION(FluxErrorPI_Kp, 0x0000A800)
#pragma LOCATION(FluxErrorPI_Ki, 0x0000A802)
#pragma LOCATION(Flux_Error_Max_IM, 0x0000A804)
#pragma LOCATION(Flux_Error_PI_Max_IM, 0x0000A806)

/*
 * PID control parameters PM
 */
#pragma LOCATION(MAX_FREQ_SET_PM, 0x0000A900)
#pragma LOCATION(FLAG_PARK_EEPROM, 0x0000A902)
#pragma LOCATION(SPEED_KP_PM, 0x0000A904)
#pragma LOCATION(SPEED_KI_PM, 0x0000A906)
#pragma LOCATION(PMSM_THETA_FACTOR, 0x0000A908)
#pragma LOCATION(PMSM_MIN_RPM, 0x0000A90A)
#pragma LOCATION(INIT_RAMP_TIME_PMSM, 0x0000A90C)
#pragma LOCATION(INIT_VOLTPERCENT_FACTOR, 0x0000A90E)
#pragma LOCATION(TORQUE_LIMIT_PM, 0x0000A910)
#pragma LOCATION(ID_REF_PM, 0x0000A912)
#pragma LOCATION(CURRENT_KP_PM, 0x0000A914)
#pragma LOCATION(CURRENT_KI_PM, 0x0000A916)
#pragma LOCATION(CURR_ERROR_LIMIT_PM, 0x0000A918)
#pragma LOCATION(VOLT_OUTPUT_LIMIT_PM, 0x0000A91A)
#pragma LOCATION(ISTART_PM_LIMIT, 0x0000A91C)
#pragma LOCATION(ISTART_PM_FACTOR, 0x0000A91E)
#pragma LOCATION(VFD_VDC_STEP, 0x0000A920)
#pragma LOCATION(VFD_VDC_KP, 0x0000A922)
#pragma LOCATION(VFD_VDC_KI, 0x0000A924)

/*
 * PID control parameters SynRM
 */
#pragma LOCATION(FluxErrorPI_Kp_SynRM, 0x0000AA00)
#pragma LOCATION(FluxErrorPI_Ki_SynRM, 0x0000AA02)
#pragma LOCATION(Flux_Error_Max_SynRM, 0x0000AA04)
#pragma LOCATION(Flux_Error_PI_Max_SynRM, 0x0000AA06)

/*
 * Device Control Prameters
 */
//#pragma LOCATION(SPEED_MODE_SELECT, 0x0000A924)               //
#pragma LOCATION(RMT_LOC_CTRL, 0x0000AB00)
#pragma LOCATION(FAN_CTRL, 0x0000AB02)
#pragma LOCATION(PHASE_ORDER, 0x0000AB04)
#pragma LOCATION(FLT_RST, 0x0000AB06)
#pragma LOCATION(MEM_ER_FLG, 0x0000AB08)
#pragma LOCATION(MOTOR_ON_OFF, 0x0000AB0A)
#pragma LOCATION(DIR_ROTATION, 0x0000AB0C)
#pragma LOCATION(SWITCH_FREQ, 0x0000AB0E)
#pragma LOCATION(SWITCH_FREQ_MULT, 0x0000AB10)
#pragma LOCATION(UF_RATIO, 0x0000AB12)
#pragma LOCATION(FREQ_REF_IP_SEL, 0x0000AB14)
#pragma LOCATION(RUN_CMD_IP_SEL, 0x0000AB16)
#pragma LOCATION(STOP_METHOD_SEL, 0x0000AB18)
#pragma LOCATION(JOG_SEL, 0x0000AB1A)
#pragma LOCATION(DWELL_REF_START, 0x0000AB1C)
#pragma LOCATION(DWELL_TIME_START, 0x0000AB1E)
#pragma LOCATION(DWELL_FREQ_STOP, 0x0000AB20)
#pragma LOCATION(DWELL_TIME_STOP, 0x0000AB22)


/*
 * Solar Para
 */
#pragma LOCATION(MAX_FREQ_SET_IM, 0x0000AC00)               //Maximum Frequency set IM
#pragma LOCATION(DC_OC_VOLT, 0x0000AC02)
#pragma LOCATION(MAX_DC_VOLT, 0x0000AC04)
#pragma LOCATION(MAX_DC_CURR, 0x0000AC06)                  //Minimum PV power
#pragma LOCATION(MAX_OA_POWER, 0x0000AC08)                    //Max FLow Speed
#pragma LOCATION(MIN_PV_POWER, 0x0000AC0A)
#pragma LOCATION(Max_Flow_Speed, 0x0000AC0C)
/*
 * Pump Para
 */
#pragma LOCATION(POW1, 0x0000AD00)               //Maximum Frequency set IM
#pragma LOCATION(D1, 0x0000AD02)                  //Maximum Frequency
#pragma LOCATION(POW2, 0x0000AD04)
#pragma LOCATION(D2, 0x0000AD06)
#pragma LOCATION(POW3, 0x0000AD08)
#pragma LOCATION(D3, 0x0000AD0A)
#pragma LOCATION(POW4, 0x0000AD0C)                  //Minimum PV power
#pragma LOCATION(D4, 0x0000AD0E)                    //Max FLow Speed
#pragma LOCATION(POW5, 0x0000AD10)
#pragma LOCATION(D5, 0x0000AD12)                  //Minimum PV power
#pragma LOCATION(Head, 0x0000AD14)                    //Max FLow Speed

/*
 * Cumulative Flow Para
 */
#pragma LOCATION(Cumulative_Energy, 0x0000AE00)               //Cumulative energy
#pragma LOCATION(Cummulative_Water_Discharge, 0x0000AE02)     //Cumulative water discharge
#pragma LOCATION(Cumulative_Run_Hrs , 0x0000AE04)             //Cumulative energy


/*
 * Test_Para
 */
#pragma LOCATION(case_state,0x0000AF00)//case_state
#pragma LOCATION(Test_Var1,0x0000AF02)
#pragma LOCATION(Test_Var2,0x0000AF04)
/*
 * Real time Para
 */
#pragma LOCATION(ON_OFF_FLAG, 0x0000BF00)                   //Motor Type
#pragma LOCATION(FAULT_CODE, 0x0000BF02)                    //Motor Type
#pragma LOCATION(VDC_BUS, 0x0000BF04)                       //Motor Type
#pragma LOCATION(Input_Vol_RY, 0x0000BF06)                  //Motor Type
#pragma LOCATION(Input_Vol_YB, 0x0000BF08)                  //Motor Type
#pragma LOCATION(Input_Vol_BR, 0x0000BF0A)                  //Motor Type
#pragma LOCATION(Input_Curr_R, 0x0000BF0C)                  //Motor Type
#pragma LOCATION(Warning_LOW_POWER, 0x0000BF0E)             //Low Power Warning
//#pragma LOCATION(RATED_POLE_IM, 0x0000BF1C)               //Motor Type
#pragma LOCATION(P_PV_Avg, 0x0000BF10)                  //Motor Type
#pragma LOCATION(Output_Vol_UV, 0x0000BF1A)                 //Motor Type
#pragma LOCATION(Output_Vol_VW, 0x0000BF1C)                 //Motor Type
#pragma LOCATION(Output_Vol_WU, 0x0000BF1E)                 //Motor Type
#pragma LOCATION(Output_Curr_U, 0x0000BF20)                 //Motor Type
#pragma LOCATION(Output_Curr_V, 0x0000BF22)                 //Motor Type
#pragma LOCATION(Output_Curr_W, 0x0000BF24)                 //Motor Type
#pragma LOCATION(Freq, 0x0000BF26)                          //Motor Type
#pragma LOCATION(Live_Power, 0x0000BF28)                          //Motor Type
#pragma LOCATION(Live_RPM, 0x0000BF2C)                          //Motor Type
#pragma LOCATION(Live_Torque, 0x0000BF2E)                          //Motor Type
#pragma LOCATION(Live_Freq, 0x0000BF30)                          //Motor Type
#pragma LOCATION(TEMP_HS, 0x0000BF36)                       //Motor Type
#pragma LOCATION(TEMP_INV, 0x0000BF38)                      //Motor Type
#pragma LOCATION(Speed_Ref_VFD_Max, 0x0000BF44)             //Motor Type
#pragma LOCATION(Torque_Ref, 0x0000BF46)                    //Motor Type
#pragma LOCATION(Today_Energy, 0x0000BF50)
#pragma LOCATION(Daily_Water_Discharge, 0x0000BF52)         //Motor Type
#pragma LOCATION(Today_Hr, 0x0000BF54)
#pragma LOCATION(flow_LPM, 0x0000BF56)                    //Motor Type
#pragma LOCATION(SOFT_STOP_FLAG, 0x0000BF5E)              //Motor Type
#pragma LOCATION(Test_Var_PRD, 0x0000BF60)              //testing variable


#pragma LOCATION(PLC_Function, 0x0000A400)                  //PLC_Function
#pragma LOCATION(PLC_V_count, 0x0000A402)                  //PLC_V_Count
#pragma LOCATION(PLC_V_OR_I, 0x0000A404)                  //PLC_V_I
#pragma LOCATION(PLC_DI3, 0x0000A406)                       //DI3
#pragma LOCATION(PLC_DI4, 0x0000A408)                       //DI4



/*********************************User Interface*******************************************************/
uint16_t dummy_read, COUNT_DISPLAY;
bool RS485_TX_EN;
bool ON_OFF_FLAG, SOFT_STOP_FLAG, SOFT_START_FLAG, SPEED_FORWARD, FREQ_UP_FLAG, SET_FREQ_ACHIEVED, LPS_CTRL, DSAT_CLEAR_FLAG, DEBUG_ON_OFF_FLAG, DEBUG_SOFT_STOP_FLAG, MASTER_ON_OFF, POLARITY , GRID_DETECTED,MASTER_ON_OFF;
bool LOW_SPEED_OFF_FLAG, FLAG_FREQ_CORRES, Warning_LOW_POWER = false;
float Test_Float1, Test_Float2, grid_detect_minute,Firmware_Version;
uint16_t RPM_Display,  count_pos, count_neg, SPI_send_buff[7][15];
unsigned char Display_Reset_Flag;
float Live_Power, Live_Torque;
unsigned int Live_RPM;
float Live_Freq;
float Power_Interval,Energy_Interval, Energy_Avg, Flow_L_Avg;
float Rated_Speed_info, RATED_LPM, RATED_FREQ, POW1, POW2, POW3, POW4, POW5;
float P_Motor_Slowest, D1, D2, D3, D4, D5, Head, Low_Power_Test;
float DC_OC_VOLTAGE, Max_freq, Upper_limit_freq, Lower_limit_freq, Solar_pump_ctlr_ref_freq, Max_DC_Volt, Max_DC_Curr, Max_OP_Act_Pwr;
Uint16 PUMP_TYPE;
float Today_Hr,Today_Energy,Total_Time_Ref,Total_Energy_Ref,Total_Water_Discharge_Ref;
unsigned char Day_RTC,Date_RTC,Month_RTC,Year_RTC,Second_RTC,Minute_RTC,Hour_RTC;
float Test_Var_PRD;
float case_state,Motor_Power_Rating;
unsigned int Test_Var1,Test_Var2;
//unsigned int CURR_OFFSET_ACS720,CURR_GAIN;
unsigned int COUNT_DISPLAY_SPD_FREQ, FREQ_HZ_DISPLAY_PMSM, DRY_RUN_RPM_PMSM;

unsigned int Device_State_Type,Device_Type,Device_Sr_No,Date_Code;
/***************************************************************************************************/
//********************************* End of User Interface *************************************************************//

/*********************************User PLC*******************************************************/
Uint16 loc_plc[8];
Uint16 PLC_Function, flag, PLC_Test, PLC_DI3, PLC_DI4;
bool DI1_MOMENTARY_FLAG, DI3_MOMENTARY_FLAG;
char PLC_V_OR_I;

//********************************* End of User PLC *************************************************************//

//********************************* EEPROM Related *************************************************************//
unsigned char eeprom_slave_address;
Uint16 RATED_POLE_IM, RATED_POLE_PM;
Uint16 CONTROL_MODE, FACTORY_MODE, LANGUAGE_SELECTED, APPLICATION_MODE, EEPROM_DATA_VALID_FLAG, MOTOR_TYPE,MOTOR_ID,Factory_flag ;
Uint16 SPEED_MODE_SELECT, CONST_SPEED_REF_SOURCE, CONST_SPEED_REF_1, CONST_SPEED_REF_2, CONST_SPEED_REF_3, CONST_SPEED_REF_4, CONST_SPEED_REF_5, CONST_SPEED_REF_6, CONST_SPEED_REF_7, CONST_SPEED_REF_8, CONST_SPEED_REF_9, VARIABLE_SPEED_REF_SOURCE;// 12-02-2025
Uint32 SPEED_RPM_REF_UI, INVERTER_PERIOD_EEPROM;
float RATED_VOLT_IM, RATED_CURR_IM, RATED_FREQ_IM , RATED_OMEGA_IM, RATED_COS_PHI_IM, RATED_SIN_PHI_IM, TORQUE_PERCENT_IM, MOTOR_POWER, RATED_CURRENT_IM;
float RATED_VOLT_PM, RATED_FREQ_PM, No_of_Pole_Pair_PM, RATED_CURR_PM, RATED_OMEGA_PM, RATED_COS_PHI_PM, TORQUE_PERCENT_PM, MOTOR_POWER_PM, Rs_PM, Ld_PM, Lq_PM ; //12-02-2025
float MAX_FREQ_SET_IM = 60, TOTAL_ENERGY, TOTAL_TIME, MAX_FREQ_SET_PM;
float DC_OC_VOLT, MAX_DC_VOLT, MAX_DC_CURR, MAX_OA_POWER,Max_Flow_Speed;  //13-02-2025 // solar parameters
Uint16 RMT_LOC_CTRL, FAN_CTRL, PHASE_ORDER, FLT_RST,MEM_ER_FLG, MOTOR_ON_OFF, DIR_ROTATION, SWITCH_FREQ_MULT, UF_RATIO; // 13-02-2025    device control parameter
Uint16 STOP_METHOD_SEL, JOG_SEL, DWELL_REF_START, DWELL_TIME_START, DWELL_FREQ_STOP, DWELL_TIME_STOP, FREQ_REF_IP_SEL, RUN_CMD_IP_SEL;// 13-02-2025    device control parameter
Uint16 FluxErrorPI_Kp_PM, FluxErrorPI_Ki_PM,Flux_Error_Max_PM, Flux_Error_PI_Max_PM, FluxErrorPI_Kp_SynRM;// 13-02-2025  PID control parameters
Uint16 FluxErrorPI_Ki_SynRM, Flux_Error_Max_SynRM, Flux_Error_PI_Max_SynRM, Flux_Error_Max_IM, Flux_Error_PI_Max_IM;// 13-02-2025  PID control parameters

float Power1, Power2, Power3, Power4, Power5, Discharge1, Discharge2, Discharge3, Discharge4, Discharge5;  //04-04-2025


float SWITCH_FREQ;
float SPEED_KP_PM, SPEED_KI_PM, CURRENT_KP_PM, CURRENT_KI_PM, MAX_SOLAR_POWER, I_PV_MAX, MAX_OUTPUT_CURRENT;




//********************************* End of EEPROM Related *************************************************************//

//********************************* Scaler Control  Related *************************************************************//
Uint16 Count;
float INITIAL_VOLTPERCENT_FACTOR;  //30*7.5/100*100 = 0.0225///here we would like to add max 7.5% when someone will set 100 in the EEPROM ,
float Freq, Corres_Freq, Init_Voltage_Perc, Init_Voltage_Addition, Max_RMS_Possible, Set_Freq, Set_Freq_Past, Set_Freq_LPF, Set_Freq_LPF_Prev,  FREQ_STEP;
float VbyF_Ratio, Max, Min, Mid, VRMS;
float Sin1, Sin2, Sin3,Sin1_CSVPWM,Sin2_CSVPWM,Sin3_CSVPWM, Mod_Index, Theta1, Theta2, Theta_Increment;
float Dead_Band_Comp, Dead_Band_Comp_R, Dead_Band_Comp_Y, Dead_Band_Comp_B;
//*********************************  End of Scaler Control  Related *************************************************************//

//********************************* Vector Control IM  Related *************************************************************//

float  Rr, Rs, Llr, Lls, Lr, Ls, Lm, Tr, LrByLm, Sigma_const, LmByTr, LPF_Constx, LPF_Consty, NUM, DEN,VC_Factor, Torque_Ref_IM_Max, Id_Iq_Error_Max;
float Speed_Ref_IM, Speed_Ref_IM_MAX,  Set_Speed_Ref_IM_Prev, Speed_Ref_IM_LPF, Speed_Error_IM, Speed_FB_IM, W_Slip_Est, W_Stator;
float Id_Ref_IM, Iq_Ref_IM, Vd_Ref_IM,Vd_Ref_IM1, Vq_Ref_IM1, Vd_Ref_IM2, Vq_Ref_IM2, Vq_Ref_IM, Vd_IM_FF, Vq_IM_FF, SAI_r_IM, Torque_Ref_IM, Theta_IM, Theta_IM_Prev;
float Id_Sensed_IM, Iq_Sensed_IM, Id_IM_Error, Iq_IM_Error;
float Speed_Error_Integ, Speed_Error_Integ_Prev, Current_Error_Id_Integ, Current_Error_Id_Integ_Prev, Current_Error_Iq_Integ, Current_Error_Iq_Integ_Prev;
float SIN_THETA, COS_THETA, SIN_THETA_120, COS_THETA_120, SIN_THETA_240, COS_THETA_240;
float IR_Ref_IM, IY_Ref_IM, IB_Ref_IM, VR_Ref_IM, VY_Ref_IM, VB_Ref_IM;
float I_Alpha_IM, I_Beta_IM, V_Alpha_IM, V_Beta_IM, V_Peak_IM, Power_Q, Power_P, W_c,  LPF_Const1, LPF_Const2 , Motor_Power_LPF_1, Motor_Power_LPF_1_Prev ;
float SAI_Alpha_s_IM, SAI_Beta_s_IM, SAI_Alpha_r_IM, SAI_Beta_r_IM;
float SAI_Alpha_s_IM_45, SAI_Beta_s_IM_45, SAI_Alpha_s_IM_45_Prev, SAI_Beta_s_IM_45_Prev;
float SAI_Alpha_s_IM_90, SAI_Beta_s_IM_90, SAI_Alpha_s_IM_90_Prev, SAI_Beta_s_IM_90_Prev;
float SAI_Alpha_r1_IM, SAI_Beta_r1_IM, SAI_Alpha_r1_IM_Prev, SAI_Beta_r1_IM_Prev, Flux_IM, Flux_IM1,  Flux_Error_IM, W_Est, W_Est_Prev, W_Est_LPF, W_Est_LPF_debug, Flux_Error_Integ, Flux_Error_Integ_Prev;
float tempa, tempb, tempc, tempd, tempe, tempf, tempg, temph;
float Speed_Ref_STEP;
//*********************************  End of Vector Control IM Related *************************************************************//

//********************************* Vector Control PMSM  Related *************************************************************//
Uint16 trial=1;
float Rs_PM, Ld_PM, Lq_PM, Time_Blank_OC_Detection;
float I_Alpha_PM, I_Beta_PM, V_Alpha_PM, V_Beta_PM, V_Alpha_E_PM, V_Beta_E_PM;
float V_Alpha_PM_LPF_50_Prev, V_Alpha_PM_LPF_50, V_Beta_PM_LPF_50_Prev, V_Beta_PM_LPF_50;
float LPF_SAI_PM_C1, LPF_SAI_PM_C2, LPF_SAI_THETA_PM_C1, LPF_SAI_THETA_PM_C2,Wc_SAI_PM,Wc_SAI_THETA_PM=50;
float SAI_Alpha_s_Theta_PM, SAI_Alpha_s_Theta_Prev_PM, SAI_Alpha_s_PM, SAI_Alpha_s_Prev_PM, SAI_Beta_s_Theta_PM, SAI_Beta_s_Theta_Prev_PM, SAI_Beta_s_PM, SAI_Beta_s_Prev_PM;
float SAI_Mag_PM, flux_mag, W_est_PM;
float W_est_Prev_PM, W_est_PM_LPF, W_est_Prev_PM1, W_est_PM_LPF_SLOWEST;
float Speed_Ref_PM_Prev, SPEED_LPF_Cutoff=1, LPF_Const_SPDREF1, LPF_Const_SPDREF2;
float speed_info;
float Speed_Ref_PM_Corr_Prev;
float Speed_FB_PM, Speed_Error_PM, Speed_Ref_PM = 100, Speed_Ref_PM1, Speed_Ref_PM2=150, Speed_Ref_PM3 = 100, Torque_Ref_PM, I, ID_REF_PM, Iq_Ref_PM, Theta_PM,Speed_Ref_PM_debug =157;
float kx, ky, Q1, P1;
float INV_U_Ph, INV_V_Ph, INV_W_Ph;
float INV_U_Ph_DC_Prev, INV_V_Ph_DC_Prev, INV_W_Ph_DC_Prev, INV_U_Ph_DC, INV_V_Ph_DC, INV_W_Ph_DC, INV_U_Ph_Filt, INV_V_Ph_Filt, INV_W_Ph_Filt;
Uint32 Counter_PM, START_FAIL_PMSM_COUNT;
bool PM_flag_start = 1;
float W_start = 10, Timer_Flag_start, Theta_RESET_COUNT, Theta_RESET_COUNT1, Theta_RESET_COUNT2, exit_count_SS;
float KP_ICNTRL_Park, KI_ICNTRL_Park, Counter_PM_Freq_Inc, Ramp_Rate_PM = 0.00005, INIT_RAMP_TIME_PMSM;
float Speed_Error_Integ_PM, Speed_Ref_PM_Min, Speed_Error_Integ_sat,  Last_Speed_I_Output_PM;
float debug_Theta_PM, pi_out_merge, diff_Theta_PM, Istart_PM_Delta;
float Last_theta_PM, PFC_THETA_CORRECTION, PFC_THETA_CORRECTION1, PFC_CF;
float OCTest_IZero_Threshold=0, OCTest_IRZero, OCTest_IYZero, OCTest_IBZero, OC_Time_Window, OC_Total_Count;
bool SPEED_STOP_INCREASE, FLAG_OPEN_PM, FLAG_CORRES_SPEED_PMSM, FLAG_PARK, FLAG_PARK_EEPROM, START_FAIL_PMSM;
float FREQ_LIMIT_PM;
float threshold1, threshold2;
float Trial_W_start;//, Speed_Error_PM_PI_Ki =0.0051, Speed_Error_PM_PI_Kp =0.02;
float SIN_THETA_PM, COS_THETA_PM, SIN_THETA_120_PM, COS_THETA_120_PM;
float IR_Ref_PM, IY_Ref_PM, IB_Ref_PM, Iq_Sensed_PM, Id_Sensed_PM, PMSM_THETA_FACTOR, IMP_FACTOR = 0.50, PMSM_THETA_FACTOR1;
float Current_Error_Id_PM, Current_Error_Iq_PM, Vd_Ref_PM, Vq_Ref_PM, debug_Vd_Ref_PM, debug_Vq_Ref_PM;
float Back_EMF, Rotor_Flux, DC_link_PU;/*, Speed_Error_PM_Integ_Max =25 , Speed_PI_PM_Output_Max = 25, Current_Error_Id_PM_Max = 5, Current_Error_Iq_PM_Max = 5;*/
//float Current_Error_Id_PM_Kp,  Current_Error_Id_PM_Ki; /*TOL_V =60, TOL_I =5;*/
float pi_output1 =0;
float Current_Error_Id_PM_Integ, Last_Current_Id_PM_Output;
//float Current_Error_Iq_PM_Kp,  Current_Error_Iq_PM_Ki;
float Current_Error_Iq_PM_Integ, Last_Current_Iq_PM_Output;
float Total_Flux, D_Feed_FWD, Q_Feed_FWD, D_Flux_Linkage, Q_Flux_Linkage;
float INIT_RAMP_TIME_PMSM1, MOD_GAIN_PM,  INIT_VOLTPERCENT_FACTOR, TORQUE_LIMIT_PM, CURR_ERROR_LIMIT_PM, VOLT_OUTPUT_LIMIT_PM, ISTART_PM_LIMIT,VOLT_OUTPUT_LIMIT_debug = 650;
float VR_Ref_PM, VY_Ref_PM, VB_Ref_PM, VR_Ref_PM1, VY_Ref_PM1, VB_Ref_PM1, debug_Iq_Ref_PM = 6;
float Park_IR_ref, Park_IY_ref, Park_IB_ref;
float Park_IR_delta, Park_IY_delta, Park_IB_delta;
float VR_Ref_Park, VY_Ref_Park, VB_Ref_Park, mdqgain_Park = 0.0044, IRATED_Park, pi_out_merge, Istart_PM, ISTART_PM_FACTOR, Istop_PM, IRATED_Park_limit;
float Park_IR_KP, Park_IR_KI, Park_IR_KI_Prev, Park_IR_PI;
float Park_IY_KP, Park_IY_KI, Park_IY_KI_Prev, Park_IY_PI;
float Park_IB_KP, Park_IB_KI, Park_IB_KI_Prev, Park_IB_PI;
float Max_PM, Min_PM, Mid_PM;
float PMSM_MIN_RPM;
float DAC_Var = 200, V_res, y_out1, Theta_PM_temp;
float Speed_Error_PM_PI_Ki_1;

float I_Alpha_OTH,I_Beta_OTH, V_Alpha_OTH,V_Beta_OTH, I_Peak, I_RMS, V_Peak, Reactive_Pow, Active_Pow, Active_Pow1,V_a_OTH, V_b_OTH,V_c_OTH;
float theta_corr, theta_cor1, theta_lag_calc, theta_lag_comp, gain_comp, V_Peak_corr, V_Alpha_OTH_Corr,V_Beta_OTH_Corr, Active_Pow_corr;
float Lmid, SAI_Alpha_r_Theta_PM_corr, SAI_Alpha_s_Theta_PM_corr, SAI_Beta_s_Theta_PM_corr, SAI_Beta_r_Theta_PM_corr, SAI_s_Theta_PM_Mag_corr;

float V_Peak_corr_Avg, V_Peak_corr_Prev, V_Peak_corr1, Corres_Speed1, Corres_Speed2,Corres_Speed2_debug, Corres_Speed, V_Peak_corr_Avg1;
float  SPEED_LIMIT_MAX_FREQ_SET, SPEED_LIMIT_RATED_FREQ_SET, SPEED_REF_PM_LIMT;
float PARKING_COUNTER_THR, OPEN_LOOP_COUNTER_PM, OPEN_LOOP_MER_COUNTER_PM, HLD_ROTOR_COUNTER_PM, PMSM_START_FAIL_THR, PM_RAMP_STEP_COUNTER, PM_RAMP_STEP_COUNTER;
//*********************************  End of Vector Control PMSM Related *************************************************************//


//********************************* ADC/DAC Related *************************************************************//
Uint16 DAC, Avgi;
Uint16 MUX_POS=0, S2=0, S1=0, S0=0, MUX_Count=0;
float VDC_BUS, I_INV_R, I_INV_Y, I_INV_B , VINV_RY, VINV_YB, VINV_BR, VGRD_RY, VGRD_YB, VGRD_BR, I_GRID_R;
float MSC_I_U, MSC_I_V, MSC_I_W, MSC_I_U_SQR, MSC_I_V_SQR, MSC_I_W_SQR;
float I_INV_R_MAF, I_INV_Y_MAF, I_INV_B_MAF;
float TEMPHS_COUNT,TEMPINV_COUNT, TEMP_HS, TEMP_INV;
Uint16 TEMPHS_COUNT1, TEMPINV_COUNT1, PLC_V_count, PLC_I_count;
float VINV_UV_MAF, VINV_VW_MAF, VINV_WU_MAF, I_INV_U_MAF, I_INV_V_MAF, VGRD_RY_MAF, VGRD_YB_MAF, VGRD_BR_MAF, I_GRD_R_MAF, VDC_BUS_MAF, I_GRID_MAF, W_est_PM_MAF;
float VINV_UV1[4], VINV_VW1[4], VINV_WU1[4], I_INV_U1[4], I_INV_V1[4], VGRD_RY1[4], VGRD_YB1[4], VGRD_BR1[4], I_GRD_R1[4], VDC_BUS1[4], I_GRID_R1[4], W_est_PM_1[4];
IndexPara InvIndexPara, GrdIndexPara;
RMSData VGRD_RY_STRUCT, VGRD_YB_STRUCT, VGRD_BR_STRUCT, IGRD_R_STRUCT,  VVFD_UV_STRUCT, VVFD_VW_STRUCT, VVFD_WU_STRUCT,  IVFD_U_STRUCT, IVFD_V_STRUCT, IVFD_W_STRUCT;
float VGRD_RY_RMS_Prev , VGRD_RY_RMS_LPF, VDC_BUS_LPF_1_Prev, VDC_BUS_LPF_1, VDC_BUS_LPF_50_Prev, VDC_BUS_LPF_50, I_GRID_R_LPF_50, I_GRID_R_LPF_50_Prev , I_OUTPUT_AVG;
float P_PV_Avg, flow_LPM;
float DaqMeasItems_VOLT_GRD_RY_buf[64];
float DaqMeasItems_VOLT_GRD_YB_buf[64];
float DaqMeasItems_VOLT_GRD_BR_buf[64];
float DaqMeasItems_CURR_GRD_R_buf[64];
float DaqMeasItems_VOLT_VFD_UV_buf[64];
float DaqMeasItems_VOLT_VFD_VW_buf[64];
float DaqMeasItems_VOLT_VFD_WU_buf[64];
float DaqMeasItems_CURR_VFD_U_buf[64];
float DaqMeasItems_CURR_VFD_W_buf[64];
float DaqMeasItems_CURR_VFD_V_buf[64];

RMSData VGRD_BR_STRUCT, IGRD_Y_STRUCT,IGRD_B_STRUCT,  VVFD_WU_STRUCT, IVFD_W_STRUCT;
float Input_Vol_RY,Input_Vol_YB,Input_Vol_BR;
float Input_Curr_R,Input_Curr_Y,Input_Curr_B;
float Output_Vol_UV,Output_Vol_VW,Output_Vol_WU;
float Output_Curr_U,Output_Curr_V,Output_Curr_W;


float Freq_PLL;
/*
#define publishSample(sample, channel, index)   \
    do{\
        DaqMeasItems_##channel##_buf[index] = sample;\
    }while(0);
*/

//********************************************SOLAR MPPT****************************************************************//
bool MPPT_START_FLAG, flag_VFD_MPP_Initial, FLAG_CORRES_SPEED_IM;
Uint16 MPPT_Counter;
float Setfreq_IM_MPPT, Setfreq_IM_MPPT_Prev, Setfreq_IM_MPPT_LPF, Freq_Ref_Max_temp1, Freq_Ref_Max_temp2, Freq_Ref_VFD_Max, Speed_Ref_VFD_Max;
float SetSpeed_PMSM_NewMPP, SetSpeed_PMSM_NewMPP_LPF, SetSpeed_PMSM_NewMPP_Prev, F_REF_PMSM_TS_MAX_temp, F_REF_PMSM_TS_MAX, SPEED_REF_PMSM_TS_MAX;
float VDC_VFD_ERROR_Integ, Last_VDC_VFD_ERROR_Integ;
float VDC_VFD_ERROR_Integ_Max, VDC_VFD_ERROR_Integ_Min, VDC_VFD_ERROR_PI_Output_Max, Speed_Ref_VFD_Max_UPPER,  VDC_VFD_ERROR_PI_Output_Min;
float MPPT_VDC_REF, Freq_Ref_MPPT, VFD_VDC_KP1 , VOC_START_VFD;
float VPV_Avg_Prev = 600,  IPV_Avg_Prev = 0.1;
float tol_P_vfd = 2, tol_V_vfd = 0.5; //tol_P_vfd = 0.4, tol_V_vfd = 1.6;   //150325
Uint16 ssfc1=0, ssfc2=0, ssfc3=0, ssfc4=0, ssfc5=0, ssfc6=0, ssfc7=0,ssfc8=0,ssfc9=0,ssfc10=0, ssfc11=0, ssfc12=0, ssfc13;
float  VFD_VDC_STEP; //VFD_VDC_KP = 0.04, VFD_VDC_KI = 0.8,
float Cumulative_Energy,Cummulative_Water_Discharge,Cumulative_Run_Hrs,Flow_Speed;
float Daily_Water_Discharge,Daily_Pump_Run_Hrs,Torque_Ref;
Uint32 Control_Ref_Selection;
float MAX_PV_POWER_UPPER, MAX_OUTPUT_CURRENT_UPPER, Freq_UPPER_LIMIT, I_PV_MAX_UPPER;
float VFD_VDC_KP, VFD_VDC_KI, VDC_VFD_ERROR_Max = 100;
//**************************************END OF SOLAR MPPT**************************************************************//

//********************************* End of ADC/DAC Related *************************************************************//

//********************************* Software RTC *************************************************************//
Uint32 mSeconds, Tick_Tick , Tick_Tick1;
float Minute_Count, Reset_Tick_Tick_Minute_Reset, Tick_Tick_Minute_Reset;

//********************************* End of Software RTC *************************************************************//
//********************************* Menus and Stater MAchine  *************************************************************//
float Button_Pressed;
Uint16 ON_BUTTON_COUNT, OFF_BUTTON_COUNT;
float Exit_Count_SS, ON_OFF_DELAY_TIMER, P_PV_Avg_DELAY_TIMER, Retry_time_Minutes =0.5, Retry_time_Minutes_EEPROM;
Uint16 Delay_flag = 0;
//********************************* End of Menus and Stater MAchine  *************************************************************//

//********************************* Faults and Warning related Variables ********************************************************//
Uint32 FAULT_CODE;
float DC_BUS_OV_LIMIT, OVER_CURR_LIMIT, VFD_OVER_TEMP_LIMIT, VFD_OVER_VOLT_LIMIT, DC_BUS_OV_RESET_HYS, VFD_OVER_TEMP_LIMIT_1, VFD_OVER_TEMP_LIMIT_2;
float MIN_PV_POWER, MAX_CURR_LIMIT;
Uint16 SC_DETECTION_CTR, COUNT_SC_FAULT;
float Timer_DCBUS_OV_Reset, TimerDCUV_LPD, TimerDCUV_LPD_Reset, Time_DCUV_LPD_Reset,  Timer_SC_FLT_Reset, Timer_Overtemp, Timer_Overtemp_Reset, Timer_outputOV, Timer_outputOV_Reset;
float Powe_AT_ELP, Timer_Phaseloss, Timer_Phaseloss_Reset , Timer_OverLoad, Timer_OverLoad_Reset, Timer_OpenCircuit, Timer_OpenCircuit_Reset,INPUT_VOLT_UNBALANCE_LIMIT,INPUT_UNBALANCE_LIMIT;
float timerdryrun, timerdryrun_Reset;
bool EEPROM_Fault_Write_Enable,  DC_BUS_OV_FLT, DC_BUS_UV_FLT, OUTPUT_SC_FLT, VFD_OVERTEMP_FLT, VFD_OUT_OV_FLT, INPUT_UNBALANCE_FLT, VFD_OUT_OL_FLT, VFD_OUT_OPEN_FLT, FLAG_OPEN_CKT, LOAD_DRY_RUN_FLT;
float Torue_MIN,Torque_Max,DCBUS_UNDER_VOLT,Speed_Max,Speed_Min,Freq_Max,Freq_Min,DRY_RUN_CURR_LIMIT,DRY_RUN_POWER_LIMIT;
bool  UV_Enable,OV_Enable,OVER_TEMP_Enable,OC_Enable,Over_Load_enable,Over_Speed_Enable,DRY_Run_Enable;
bool OUTPUT_HIGH_INRUSH_FLT;
Uint16  Motor_Slow_Lmt_OC, Motor_Med_Lmt_OC, Motor_Fast_Lmt_OC, Motor_Short_Term_Over_Current_DSP_SLOW, Motor_Short_Term_Over_Current_DSP_MEDIUM, Motor_Short_Term_Over_Current_DSP_FAST, Motor_Slow_Lmt_OC_Reset;
float  Motor_Check_Occurance_OC,Motor_Check_RESET_OC;
float OUTPUT_OPEN_LOW_LIMIT, OUTPUT_OPEN_HIGH_LIMIT, MOTOR_PWR_MIN_LIMIT;
/*********************************  End of Faults and Warning related Variables ********************************************************/

float FluxErrorPI_Kp = 10, FluxErrorPI_Ki = 300;
float Id_Ref_IM_debug, Iq_Ref_IM_debug;
//********************************* ADC ISR*************************************************************//
Uint16 Blink_LED, UART_Test,Motor_Timer,EEPROM_READ,CUMMULATIVE_PARAMETER_TIMER;
unsigned char TZ_CLR, ALL_PWM_LOW, TZ_FRC_SW;
unsigned char PWM_Release_Flag;
//********************************* ADC ISR*************************************************************//
float TEMP_HS_TABLE[150] = {
                                  158.57,     152.16,     146.54,     141.54,     137.04,     132.96,     129.22,     125.78,
                                  122.59,     119.62,     116.84,     114.23,     111.77,     109.44,     107.23,     105.13,     103.13,     101.21,
                                  99.38,      97.62,      95.93,      94.3,       92.73,      91.22,      89.75,      88.33,      86.96,      85.62,
                                  84.32,      83.06,      81.83,      80.64,      79.47,      78.33,      77.22,      76.14,      75.07,      74.03,
                                  73.01,      72.02,      71.04,      70.07,      69.13,      68.2,       67.29,      66.4,       65.52,      64.65,
                                  63.8,       62.95,      62.13,      61.31,      60.5,       59.71,      58.92,      58.14,      57.38,      56.62,
                                  55.87,      55.13,      54.4,       53.67,      52.95,      52.24,      51.54,      50.84,      50.15,      49.46,
                                  48.78,      48.11,      47.44,      46.77,      46.11,      45.46,      44.81,      44.16,      43.51,      42.88,
                                  42.24,      41.61,      40.98,      40.35,      39.73,      39.11,      38.49,      37.87,      37.26,      36.65,
                                  36.04,      35.43,      34.82,      34.22,      33.61,      33.01,      32.41,      31.81,      31.21,      30.61,
                                  30.01,      29.41,      28.81,      28.21,      27.61,      27.01,      26.41,      25.81,      25.21,      24.61,
                                  24,         23.4,       22.79,      22.18,      21.57,      20.96,      20.34,      19.73,      19.11,      18.48,
                                  17.86,      17.23,      16.59,      15.96,      15.32,      14.67,      14.02,      13.37,      12.71,      12.04,
                                  11.37,      10.69,      10.01,      9.32,       8.62,       7.91,       7.2,        6.47,       5.74,       5,
                                  4.25,       3.48,       2.7,        1.92,       1.11,       0.3,        -0.53,      -1.38,      -2.25,      -3.13,
                                  -4.04,      -4.97
};

float TEMP_INV_TABLE[150] = {
                                   124.9,       119.41,     114.58,     110.28,     106.41,     102.88,     99.66,      96.68,
                                   93.92,      91.34,      88.93,      86.66,      84.52,      82.5,       80.58,      78.75,      77,     75.33,
                                   73.73,      72.19,      70.71,      69.29,      67.92,      66.59,      65.31,      64.06,      62.86,      61.69,
                                   60.55,      59.44,      58.36,      57.31,      56.29,      55.29,      54.31,      53.35,      52.42,      51.5,
                                   50.61,      49.73,      48.86,      48.02,      47.18,      46.37,      45.56,      44.77,      43.99,      43.23,
                                   42.47,      41.73,      41,         40.27,      39.56,      38.86,      38.16,      37.47,      36.8,       36.12,
                                   35.46,      34.8,       34.16,      33.51,      32.88,      32.24,      31.62,      31,         30.39,      29.78,
                                   29.17,      28.57,      27.98,      27.39,      26.8,       26.22,      25.64,      25.06,      24.49,      23.92,
                                   23.36,      22.79,      22.23,      21.68,      21.12,      20.57,      20.02,      19.47,      18.92,      18.37,
                                   17.83,      17.29,      16.75,      16.21,      15.67,      15.13,      14.59,      14.06,      13.52,      12.98,
                                   12.45,      11.91,      11.38,      10.84,      10.31,      9.77,       9.23,       8.69,       8.16,       7.62,
                                   7.07,       6.53,       5.99,       5.44,       4.9,        4.35,       3.79,       3.24,       2.69,       2.13,
                                   1.56,       1,          0.43,       -0.14,      -0.72,      -1.3,       -1.88,      -2.47,      -3.06,      -3.66,
                                   -4.26,      -4.87,      -5.49,      -6.11,      -6.74,      -7.38,      -8.02,      -8.67,      -9.33,      -10,
                                   -10.68,     -11.37,     -12.07,     -12.78,     -13.5,      -14.24,     -14.99,     -15.76,     -16.54,     -17.34,
                                   -18.16,     -19
};

void Variable_Init(void){
    Display_Reset_Flag             = 1;
    Tick_Tick_Minute_Reset         = 4000;
    INITIAL_VOLTPERCENT_FACTOR     = 0.03375;  //30*7.5/100*100 = 0.0225///here we would like to add max 7.5% when someone will set 100 in the EEPROM ,
    Factory_flag = 0;
    if(MOTOR_TYPE == 0){                //MOTOR_TYPE 0 is IM
        RATED_OMEGA_IM             = RATED_FREQ_IM *6.283185;
        Theta1                     = 0.25;
        Count                      = 2;
        Freq                       = 1;
        VbyF_Ratio                 = RATED_VOLT_IM/RATED_FREQ_IM;
        RATED_SIN_PHI_IM           = sqrt(1-(RATED_COS_PHI_IM*RATED_COS_PHI_IM));
        Id_Ref_IM                  = RATED_CURR_IM * RATED_SIN_PHI_IM * 1.414;
        SAI_r_IM                   = Id_Ref_IM * Lm;
        Llr                        = Lls;
        Lr                         = Llr+Lm;
        Ls                         = Lls+Lm;
        Tr                         = Lr/Rr;
        LrByLm                     = Lr/Lm;            // 1.08003
        Sigma_const                = (((Lr*Ls)/Lm) - Lm); // 0.012065        //Lr*LsByLm - Lm
        LmByTr                     = (Lm/Tr);          // need to be defined
        LPF_Constx                 = ((Tr*Ts)/(Tr+Ts));    // Ts/(1+(1/Tr)*Ts)
        LPF_Consty                 = (Tr/(Tr+Ts));      //  1/(1+(1/Tr)*Ts)
        NUM                        = 1.3334 * Lr; //4/3
        DEN                        = RATED_POLE_IM  * Lm * SAI_r_IM;             //RATED_POLE_PAIR_IM * 2 * Lm * SAI_r_IM;
        VC_Factor                  = __divf32(NUM,DEN);
        TORQUE_PERCENT_IM          = 1.00;
        Torque_Ref_IM_Max          =  RATED_CURR_IM* RATED_COS_PHI_IM * 1.414 * TORQUE_PERCENT_IM/VC_Factor;
        Id_Iq_Error_Max            = 0.75 * RATED_CURR_IM;
        //SPEED_RPM_REF_UI           = 300;
        SPEED_MODE_SELECT          = 3;
        VDC_VFD_ERROR_Integ_Max    = 120;
        VDC_VFD_ERROR_Integ_Min    = 5;
        VDC_VFD_ERROR_PI_Output_Max= 120;
        VDC_VFD_ERROR_PI_Output_Min= 5;
        Motor_Slow_Lmt_OC          = 900;
        Motor_Med_Lmt_OC           = 1225;
        Motor_Fast_Lmt_OC          = 1600;
        Motor_Slow_Lmt_OC_Reset    = 800;

        P_Motor_Slowest = P_PV_Avg;
    }
    if(MOTOR_TYPE == 1){                //MOTOR_TYPE 1 is PMSM 2-SynRM
        if(MOTOR_ID == 0){              //150HZ_PMSM_SURFACE_MOUNT_MOTOR
            RATED_VOLT_PM              = 280;               //280;
            RATED_FREQ_PM              = 150;                   //150;
            RATED_POLE_PM              = 6;
            Ld_PM                      = 0.006;   //0.0012;
            Lq_PM                      = 0.008;   //0.026;
            Rs_PM                      = 0.254;     //0.4; 0.5080 measured per phase_@290125
        }
    }

    if(MOTOR_TYPE == 2){                //MOTOR_TYPE 2 is SynRM
        if(MOTOR_ID == 0){              //100HZ_SynRM_MOTOR
            RATED_VOLT_PM              = 280;               //280;
            RATED_FREQ_PM              = 150;               //150;
            RATED_POLE_PM              = 6;
            Ld_PM                      = 0.006;   //0.0012;
            Lq_PM                      = 0.008;   //0.026;
            Rs_PM                      = 0.254;     //0.4; 0.5080 measured per phase_@290125
        }

    }
    if(MOTOR_TYPE == 3){                //MOTOR_TYPE 3 is PMSM 24000
        if(MOTOR_ID == 0){              //100HZ_PMSM 24000
            RATED_VOLT_PM              = 380;               //380;
            RATED_FREQ_PM              = 800;               //800;
            RATED_POLE_PM              = 4;
            Ld_PM                      = 0.0006045;         //0.0006045;
            Lq_PM                      = 0.00121;          //0.00121;
            Rs_PM                      = 0.1;             //0.4; 0.5080 measured per phase_@290125
        }
    }
    //PMSM_MIN_RPM               = 500;
    DC_BUS_OV_LIMIT            = 750;
    VFD_OVER_TEMP_LIMIT        = 85;
    VFD_OVER_VOLT_LIMIT        = 400;
    DC_BUS_OV_RESET_HYS        = 50;
//    MIN_PV_POWER               = 500;
    OVER_CURR_LIMIT            = 24;
    RS485_TX_EN                = 0;
    //Speed_Ref_IM_MAX           = 5024.00;
    SPEED_FORWARD               = 1;
    Dead_Band_Comp              = (float)BAND_INV * 2 / (float)INVERTER_PERIOD;
    TZ_CLR                     = 0;
    ALL_PWM_LOW                = 0;
    TZ_FRC_SW                  = 0;
    //CONTROL_MODE               = 2;
//    MOTOR_TYPE                 = 0; //MOTOR_TYPE: 0 - IM, 1-PMSM,
}
void Varible_Init_Revised(void) {
    if(MOTOR_TYPE == 0){                //MOTOR_TYPE 0 is IM
        if(MOTOR_ID == 0){
            RATED_VOLT_IM              = 415;
            RATED_FREQ_IM              = 100;
            RATED_POLE_IM              = 2;
            Lls                        = 0.020;
            Lm                         = 0.425;
            Rr                         = 4.3;
            Rs                         = 4.19;
        }
        if(MOTOR_ID == 1){//50
            RATED_VOLT_IM              = 415;
            RATED_FREQ_IM              = 800;
            RATED_POLE_IM              = 4;
            Lls                        = 0.0074;
            Lm                         = 0.11;
            Rr                         = 0.4;
            Rs                         = 0.6;
        }
        if(MOTOR_ID == 2){//200
            RATED_VOLT_IM              = 415;
            RATED_FREQ_IM              = 800;
            RATED_POLE_IM              = 4;
            Lls                        = 0.0025;//0.0012;
            Lm                         = 0.050;//0.026;
            Rr                         = 0.44;
            Rs                         = 0.6;
        }
        if(MOTOR_ID == 3){//400
            RATED_VOLT_IM              = 415;
            RATED_FREQ_IM              = 800;
            RATED_POLE_IM              = 4;
            Lls                        = 0.0017;//0.0012;
            Lm                         = 0.032;//0.026;
            Rr                         = 0.6;
            Rs                         = 0.6;
        }
        if(MOTOR_ID == 4){//800
            RATED_VOLT_IM              = 415;
            RATED_FREQ_IM              = 800;
            RATED_POLE_IM              = 4;
            Lls                        = 0.0004627;//0.0012;
            Lm                         = 0.0060488;//0.026;
            Rr                         = 0.85;
            Rs                         = 0.6;
        }
        if(MOTOR_ID == 5){//800
            RATED_VOLT_IM              = 415;
            RATED_FREQ_IM              = 800;
            RATED_POLE_IM              = 4;
            Lls                        = 0.0002627;//0.0012;
            Lm                         = 0.0020488;//0.026;
            Rr                         = 0.85;
            Rs                         = 0.6;
        }


        Lr                         = Lls+Lm;
        Ls                         = Lls+Lm;
        Tr                         = Lr/Rr;
        LrByLm                     = Lr/Lm;            // 1.08003
        Sigma_const                = (((Lr*Ls)/Lm) - Lm); // 0.012065        //Lr*LsByLm - Lm
        LmByTr                     = (Lm/Tr);          // need to be defined
        LPF_Constx                 = ((Tr*Ts)/(Tr+Ts));    // Ts/(1+(1/Tr)*Ts)
        LPF_Consty                 = (Tr/(Tr+Ts));      //  1/(1+(1/Tr)*Ts)

    }
    if(MOTOR_TYPE == 1){                //MOTOR_TYPE 1 is PMSM
        if(MOTOR_ID == 0){              //150HZ_PMSM
            RATED_VOLT_PM              = 280;
            RATED_FREQ_PM              = 150;
            RATED_POLE_PM              = 6;
            Lls                        = 0.0002627;//0.0012;
            Lm                         = 0.0020488;//0.026;
            Rr                         = 0.85;
            Rs_PM                      = 0.4;


        }
    }
}


