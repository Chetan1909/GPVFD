#include <Headers/Project_Header/Init.h>

#define SCL_H           GPIO_WritePin(18,1);
#define SCL_L           GPIO_WritePin(18,0);
#define SDA_in          GPIO_SetupPinOptions(19, GPIO_INPUT,GPIO_PUSHPULL);     // GpioCtrlRegs.GPCMUX2.bit.GPIO91=0; //SDA Connected to P0.7
#define SDA_out         GPIO_SetupPinOptions(19, GPIO_OUTPUT,GPIO_PUSHPULL);    // GpioCtrlRegs.GPCMUX2.bit.GPIO91=1;
#define SDA_read        GPIO_ReadPin(19);
#define SDA_H           GPIO_WritePin(19,1);                                    // SDA high in write mode
#define SDA_L           GPIO_WritePin(19,0);                                    // SDA low in write mode
#define Tx_rtc_slaveAddr        0x68//0xD0
#define Rx_rtc_slaveAddr        0x68//0xD1

void I2C_Clock(void){
    //GpioDataRegs.GPCSET.bit.GPIO91=1;
    DELAY_US(2);
    //GpioDataRegs.GPCSET.bit.GPIO91=1;
    SCL_H   ;       // Wait for Some time and Pull the SCL line High

    DELAY_US(2);         // Wait for Some time
    // GpioDataRegs.GPCCLEAR.bit.GPIO91=1;
    SCL_L   ;       // Pull back the SCL line low to Generate a clock pulse
}

/*---------------------------------------------------------------------------------*
                          void I2C_Start()
 ----------------------------------------------------------------------------------*/

void I2C_Start(){
    SCL_L;      // Pull SCL low
    SDA_H;      // Pull SDA High
    DELAY_US(2);
    SCL_H;      // Pull SCL high
    DELAY_US(2);
    SDA_L;      // Now Pull SDA LOW, to generate the Start Condition
    DELAY_US(2);
    SCL_L;      // Finally Clear the SCL to complete the cycle
}

/*-----------------------------------------------------------------------------------
                          void I2C_Stop()
 ------------------------------------------------------------------------------------*/

void I2C_Stop(void){
    SDA_out;            //set SDA in write mode
    SCL_L;          // Pull SCL low
    DELAY_US(2);
    SDA_L;          // Pull SDA  low
    DELAY_US(2);
    SCL_H;          // Pull SCL High
    DELAY_US(2);
    SDA_H;          // Now Pull SDA High, to generate the Stop Condition
}

/*---------------------------------------------------------------------------------*
                          void I2C_Write(unsigned char dat)
 ----------------------------------------------------------------------------------*/

void I2C_Write(unsigned char dat){
    unsigned char i;
    SDA_out;                            // set SDA in write mode

    for(i=0;i<8;i++){                   // loop 8 times to send 1-byte of data
        if((dat & 0B10000000) > 0){     // if bit is 1 then SDA line is high else low
            SDA_H;
        }
        else{
            SDA_L;
        }
        I2C_Clock();                    // Generate Clock at SCL
        dat = dat<<1;
    }
    SDA_H;                              // Set SDA at last
    return;
}

/*-----------------------------------------------------------------------------------*
                          unsigned char I2C_Read()
 ------------------------------------------------------------------------------------*/

unsigned char I2C_Read(void){
    unsigned char i, dat=0x00;
    // SDA=1;                   // Make SDA as I/P
    SDA_in;                     // Make SDA line in
    DELAY_US(2);
    for(i=0;i<8;i++){           // loop 8times read 1-byte of data
        DELAY_US(2);
        SCL_H;                  // Pull SCL High
        DELAY_US(2);
        dat = dat<<1;           // dat is Shifted each time and
        dat = dat | SDA_read;   // ORed with the received bit to pack into byte
        SCL_L;                  // Clear SCL to complete the Clock
    }
    return dat;                 // Finally return the received Byte*
}

/*---------------------------------------------------------------------------------*
                          void I2C_Ack()
 ----------------------------------------------------------------------------------*/

void I2C_Ack(){
    SDA_out;            // set SDA in write mode
    DELAY_US(2);
    SDA_L;              // Pull SDA low to indicate Positive ACK
    I2C_Clock();        // Generate the Clock
    SDA_H;              // Pull SDA back to High(IDLE state)
}

/*---------------------------------------------------------------------------------*
                          void I2C_NoAck()
 ----------------------------------------------------------------------------------*/

void I2C_NoAck(){
    SDA_out;            // set SDA in write mode
    DELAY_US(2);
    SDA_H;              // Pull SDA high to indicate Negative/NO ACK
    I2C_Clock();        // Generate the Clock
    SCL_L;              // Set SCL
}
void init_BQ32(void){

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x07,0x00);           DELAY_US(40);

    return;
}
/***************************************Set second, minute and hour***************************************************************/

void set_time_BQ32(unsigned char second,unsigned char minute, unsigned char hour){

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x00,second);         DELAY_US(40);

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x01,minute);         DELAY_US(40);
    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x02,hour);           DELAY_US(40);

    return;
}

/*************************************Set Day, Date, month, year on RTC**********************************************************/
/*
       Table for day in term of register value
       1 Sun------------7 Saturday
       Table for DATE in term of register value
       1 JAN--------12 DEC
 */

void set_date_BQ32(unsigned char day,unsigned char date, unsigned char month,unsigned char year){

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x03,day);        DELAY_US(40);

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x04,date);           DELAY_US(40);

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x05,month);          DELAY_US(40);

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x06,year);           DELAY_US(40);

    return;
}

/***************************************************Read second, minute,hour*********************************************************/

void read_time_BQ32(unsigned char *second, unsigned char *minute, unsigned char *hour){

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();

    *second = EEPROM_ReadByte_BQ32(0x00);      DELAY_US(40);
    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    *minute = EEPROM_ReadByte_BQ32(0x01);     DELAY_US(40);
    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    *hour   = EEPROM_ReadByte_BQ32(0x02);  DELAY_US(80);

    *second= (((*second & 0b01110000)>>4)*10) + (*second & 0b00001111);
    *minute= (((*minute & 0b01110000)>>4)*10) + (*minute & 0b00001111);
    *hour=   (((*hour   & 0b00110000)>>4)*10) + (*hour   & 0b00001111);           //Read hour in 24 hour mode
    return;
}

/***********************************************Read day,Date,Month and Year****************************************************/
/*
        Table for DAY in term of register value
        1 Sun------------7 Saturday
        Table for DATE in term of register value
        1 JAN--------12 DEC
        Table for month
        1---------12
        Table for year
        2001------------99
 */

void read_date_BQ32(unsigned char *day, unsigned char *date, unsigned char *month, unsigned char *year){

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    *day    =  EEPROM_ReadByte_BQ32(0x03);           DELAY_US(40);

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    *date   =  EEPROM_ReadByte_BQ32(0x04);         DELAY_US(40);

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    *month =   EEPROM_ReadByte_BQ32(0x05);          DELAY_US(40);

    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    *year   =  EEPROM_ReadByte_BQ32(0x06);

    *year=   (((*year   & 0b11110000)>>4)*10) + (*year & 0b00001111);        //Read year
    *month=  (((*month & 0b11110000) >>4)*10) + (*month & 0b00001111);       //Read month
    *date=   (((*date   & 0b01110000)>>4)*10) + (*date & 0b00001111);        //Read Date
    *day=    (*day & 0b00000111);                                            //Read day
    return;
}

void set_date_alone_BQ32(unsigned char date){
    date = dec2bcd(date);
    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x04,date);           DELAY_US(40);
    return;
}
void set_month_alone_BQ32(unsigned char month){

    month = dec2bcd(month);
    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x05,month);          DELAY_US(40);
    return;
}
void set_year_alone_BQ32(unsigned char year){

    year = dec2bcd(year);
    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x06,year);           DELAY_US(40);

    return;
}
void set_hour_time_BQ32(unsigned char hour){

    hour = dec2bcd(hour);
    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x02,hour);         DELAY_US(40);


    return;
}
void set_minute_time_BQ32(unsigned char minute){

    minute = dec2bcd(minute);
    wait_i2c_stpbit_clear();
    wait_i2c_busbusy_clear();
    EEPROM_WriteByte_BQ32(0x01,minute);         DELAY_US(40);

    return;
}

char dec2bcd(char num){
    return ((num/10 * 16) + (num % 10));
}

char bcd2dec(char num){
    return ((num/16 * 10) + (num % 16));
}
void EEPROM_WriteByte_BQ32( unsigned char address,unsigned char data){


    I2cbRegs.I2CSAR.all         = Tx_rtc_slaveAddr;            // Slave address
    I2cbRegs.I2CMDR.bit.MST     = 0x1;                  // Configure Master
    I2cbRegs.I2CMDR.bit.TRX     = 0x1;                  // Configure as a Transmitter
    I2cbRegs.I2CCNT             = 0x02;                 // Set data count
    I2cbRegs.I2CMDR.bit.STT     = 0x1;                  // send Start condition

    wait_i2c_xrdybit_set();                             // wait till transmission is ready

    I2cbRegs.I2CDXR.all         = address;           // send eeprom address higher byte
    wait_i2c_bytesent_set();                            // wait till byte is sent
    I2cbRegs.I2CSTR.bit.BYTESENT= 0x1;

    I2cbRegs.I2CDXR.all         = data;                 // send eeprom data 1 byte
    wait_i2c_bytesent_set();                            // wait till byte is sent
    I2cbRegs.I2CSTR.bit.BYTESENT= 0x1;

    I2cbRegs.I2CMDR.bit.STP     = 0x1;                  // send stop condition
    wait_i2c_stpbit_clear();
    I2cbRegs.I2CSTR.bit.BYTESENT= 0x1;
    DELAY_US(5000);
}
unsigned char EEPROM_ReadByte_BQ32(unsigned char address){

    I2cbRegs.I2CSAR.all         = Tx_rtc_slaveAddr;            // Slave address
    I2cbRegs.I2CMDR.bit.MST     = 0x1;                  // Configure Master
    I2cbRegs.I2CMDR.bit.TRX     = 0x1;                  // Configure as a Transmitter
    I2cbRegs.I2CCNT             = 0x01;                 // Set data count
    I2cbRegs.I2CMDR.bit.STT     = 0x1;                  // send Start condition

    wait_i2c_xrdybit_set();                             // wait till transmission is ready

    I2cbRegs.I2CDXR.all         =   address;         // send EEPROM address higher byte
    wait_i2c_bytesent_set();                            // wait till byte is sent
    I2cbRegs.I2CSTR.bit.BYTESENT= 0x1;

    I2cbRegs.I2CSAR.all         = Rx_rtc_slaveAddr;            // Slave address
    I2cbRegs.I2CMDR.bit.MST     = 0x1;                  // Configure Master
    I2cbRegs.I2CMDR.bit.TRX     = 0x0;                  // Configure as a Receiver
    I2cbRegs.I2CCNT             = 0x01;                 // Set data count
    I2cbRegs.I2CMDR.bit.STT     = 0x1;                  // send Start condition

    wait_i2c_rrdybit_set();                             // wait for byte receiving
    data = I2cbRegs.I2CDRR.all;                         // Read received data

    I2cbRegs.I2CMDR.bit.STP = 0x1;                      // send stop condition
    wait_i2c_stpbit_clear();
    I2cbRegs.I2CSTR.bit.BYTESENT = 0x1;
    DELAY_US(10000);

    return data;
}
