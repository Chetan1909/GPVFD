/*
 * Vector_CTRL_IM.c
 *
 *  Created on: 10-Aug-2023
 *      Author: manoj
 */


#include <Headers/Project_Header/Init.h>

void Motor_Parameter_Estimation_IM(void){

}

void Speed_Estimation_IM(void){
    float errorintoki =0, errorintokp = 0;
    if(ON_OFF_FLAG == true){
        I_Alpha_IM = ThreebyTwo*I_INV_R;
        I_Beta_IM  = RootThreebyTwo * (- 2 * I_INV_Y- I_INV_R);

        V_Alpha_IM = 0.5 * (VINV_RY - VINV_BR);
        V_Beta_IM  = -RootThreebyTwo*VINV_YB;

        V_Peak_IM  = sqrt((V_Alpha_IM*V_Alpha_IM)+(V_Beta_IM*V_Beta_IM)); //peak
        /*Power_Q    = (V_Alpha_IM*I_Beta_IM)-(V_Beta_IM*I_Alpha_IM);  // Reactive Power
        Power_P    = (V_Alpha_IM*I_Alpha_IM)+(V_Beta_IM*I_Beta_IM);  // Active Power
        Power_P    = 0.627*Power_P; // 2/3 plus some correction factor

        Motor_Power_LPF_1_Prev      = Power_P * LPF_CONST_C1_1 + Motor_Power_LPF_1_Prev * LPF_CONST_C2_1;
        Motor_Power_LPF_1           = Motor_Power_LPF_1_Prev * LPF_WC_1;*/

        W_c  = Speed_Ref_IM;

        if(W_c > 12000)  W_c = 12000;
        if(W_c < 1)   W_c = 1;

        LPF_Const1 =     Ts/(1+(W_c*Ts)); //  0.0000995025    //Ts/(1+Wc*Ts)
        LPF_Const2 =     1/(1+(W_c*Ts));        //1/(1+Wc*Ts)


        SAI_Alpha_s_IM_45 = (V_Alpha_IM - I_Alpha_IM * Rs) * LPF_Const1 + SAI_Alpha_s_IM_45_Prev * LPF_Const2;
        SAI_Beta_s_IM_45  = (V_Beta_IM - I_Beta_IM * Rs)   * LPF_Const1 + SAI_Beta_s_IM_45_Prev  * LPF_Const2;

        SAI_Alpha_s_IM_45_Prev  = SAI_Alpha_s_IM_45;
        SAI_Beta_s_IM_45_Prev   = SAI_Beta_s_IM_45;

        SAI_Alpha_s_IM_90 = SAI_Alpha_s_IM_45 * LPF_Const1 + SAI_Alpha_s_IM_90_Prev * LPF_Const2;
        SAI_Beta_s_IM_90  = SAI_Beta_s_IM_45   * LPF_Const1 + SAI_Beta_s_IM_90_Prev  * LPF_Const2;

        SAI_Alpha_s_IM_90_Prev = SAI_Alpha_s_IM_90;
        SAI_Beta_s_IM_90_Prev  = SAI_Beta_s_IM_90;

        SAI_Alpha_s_IM = SAI_Alpha_s_IM_90 *(2* W_c);
        SAI_Beta_s_IM = SAI_Beta_s_IM_90 *(2*W_c);

        Flux_IM = sqrt((SAI_Alpha_s_IM*SAI_Alpha_s_IM) + (SAI_Beta_s_IM* SAI_Beta_s_IM));

        SAI_Alpha_r_IM = SAI_Alpha_s_IM * LrByLm - Sigma_const*I_Alpha_IM;
        SAI_Beta_r_IM  = SAI_Beta_s_IM * LrByLm  - Sigma_const*I_Beta_IM;

        Flux_IM1 = sqrt((SAI_Alpha_r_IM*SAI_Alpha_r_IM) + (SAI_Beta_r_IM* SAI_Beta_r_IM));

        tempa = (LmByTr * I_Alpha_IM  * LPF_Constx);
        tempe = (LmByTr * I_Beta_IM* LPF_Constx);

        tempb  =  SAI_Beta_r1_IM_Prev * W_Est *LPF_Constx;
        tempf = SAI_Alpha_r1_IM_Prev * W_Est *LPF_Constx;


        tempc = SAI_Alpha_r1_IM_Prev*LPF_Consty;
        tempg = SAI_Beta_r1_IM_Prev*LPF_Consty;

        tempd = tempa+ tempb + tempc;
        temph = tempe -tempf + tempg;
        //=  (LmByTr * I_Beta_IM - SAI_Alpha_r1_IM_Prev * W_Est);

        SAI_Alpha_r1_IM = tempd;
        SAI_Beta_r1_IM  = temph;
        //SAI_Alpha_r1_IM = (LmByTr * I_Alpha_IM + SAI_Beta_r1_IM_Prev * W_Est)*LPF_Constx +  SAI_Alpha_r1_IM_Prev*LPF_Consty;

        //SAI_Beta_r1_IM =  (LmByTr * I_Beta_IM - SAI_Alpha_r1_IM_Prev * W_Est)*LPF_Constx + SAI_Beta_r1_IM_Prev*LPF_Consty;


        SAI_Alpha_r1_IM_Prev = SAI_Alpha_r1_IM;
        SAI_Beta_r1_IM_Prev  = SAI_Beta_r1_IM;

        if(SAI_Alpha_r1_IM_Prev > Flux_Error_Max) SAI_Alpha_r1_IM_Prev = Flux_Error_Max;
        if(SAI_Alpha_r1_IM_Prev < -Flux_Error_Max) SAI_Alpha_r1_IM_Prev = -Flux_Error_Max;

        if(SAI_Beta_r1_IM_Prev > Flux_Error_Max) SAI_Beta_r1_IM_Prev = Flux_Error_Max;
        if(SAI_Beta_r1_IM_Prev < -Flux_Error_Max) SAI_Beta_r1_IM_Prev = -Flux_Error_Max;

        Flux_Error_IM = SAI_Alpha_r_IM * SAI_Beta_r1_IM - SAI_Beta_r_IM * SAI_Alpha_r1_IM;

        if(Flux_Error_IM > Flux_Error_Max) Flux_Error_IM = Flux_Error_Max;
        if(Flux_Error_IM < -Flux_Error_Max) Flux_Error_IM = -Flux_Error_Max;

        errorintokp = FluxErrorPI_Kp * Flux_Error_IM;
        errorintoki = FluxErrorPI_Ki * Flux_Error_IM;
        errorintoki = errorintoki * Ts;
        Flux_Error_Integ = errorintoki + Flux_Error_Integ_Prev;

        if(Flux_Error_Integ > Flux_Error_PI_Max) Flux_Error_Integ = Flux_Error_PI_Max;
        if(Flux_Error_Integ < -Flux_Error_PI_Max) Flux_Error_Integ = -Flux_Error_PI_Max;

        Flux_Error_Integ_Prev = Flux_Error_Integ;

        W_Est  = Flux_Error_Integ + errorintokp;

        if(W_Est < 0){
            W_Est = W_Est*-1;
        }

        if(W_Est > Flux_Error_PI_Max) W_Est = Flux_Error_PI_Max;
        if(W_Est < -Flux_Error_PI_Max) W_Est = -Flux_Error_PI_Max;

        //*********************************LPF On Set_Freq*************************************************************//
        W_Est_Prev              = W_Est * LPF_CONST_C1_50 + W_Est_Prev * LPF_CONST_C2_50;
        W_Est_LPF               = W_Est_Prev *  LPF_WC_50;
        //*********************************LPF On Set_Freq end ********************************************************//

    }
    else{
        SAI_Alpha_s_IM_45_Prev  = 0;
        SAI_Beta_s_IM_45_Prev   = 0;
        SAI_Alpha_s_IM_90_Prev  = 0;
        SAI_Beta_s_IM_90_Prev   = 0;
        SAI_Alpha_r1_IM_Prev    = 0;
        SAI_Beta_r1_IM_Prev     = 0;
        Flux_Error_Integ        = 0;
        Flux_Error_Integ_Prev   = 0;
        W_Est                   = 0;
        W_Est_Prev              = 0;
        Motor_Power_LPF_1_Prev  = 0;
        Motor_Power_LPF_1       = 0;
        W_Est_LPF               = 0;
        Flux_Error_IM           = 0;
    }


}

void Vector_Control_IM(void){
    Uint16 duty1=0, duty3=0, duty5=0;
    float errorintoki =0, errorintokp = 0, Num =0, Den =0;

    Motor_Parameter_Estimation_IM();

    if(ON_OFF_FLAG == true){
        if(SPEED_MODE_SELECT == 3 && SOFT_STOP_FLAG==0){
            Speed_Ref_IM = SPEED_RPM_REF_UI *0.10472; // RPM*PI/30*pole_pair
        }
        else if (SOFT_STOP_FLAG==0){
            Speed_Ref_IM = RATED_OMEGA_IM;
        }
        else{
            if(SOFT_STOP_FLAG == true){
                /*Speed_Ref_STEP = 78.5/W_Est;
                            if(Speed_Ref_STEP > 1.57){
                                Speed_Ref_STEP = 1.57;
                            }*/
                Speed_Ref_STEP = 0.785;
                Speed_Ref_IM = Speed_Ref_IM - Speed_Ref_STEP;
                if(Speed_Ref_IM < 12){
                    ON_OFF_FLAG    = 0;
                    SOFT_STOP_FLAG = 0;
                //    MASTER_ON_OFF = 0;
                  //  EEPROM_WriteInt(2,12,0);   //  MASTER_ON_OFF
                }
            }
        }
        //*********************************LPF On Speed_Ref_IM*************************************************************//
        Set_Speed_Ref_IM_Prev        = Speed_Ref_IM * LPF_CONST_C1_1 + Set_Speed_Ref_IM_Prev * LPF_CONST_C2_1;
        Speed_Ref_IM_LPF             = Set_Speed_Ref_IM_Prev *  LPF_WC_1;
             //*********************************LPF On Speed_Ref_IM end ********************************************************//
        Speed_Estimation_IM();

        /*if(Speed_Ref_IM < 30){
            Speed_Ref_IM = 30;
        }*/
        if(W_Est < 10){
            Speed_FB_IM = W_Est;      // Estimated speed for IM from MRAS
        }
        else{
            Speed_FB_IM = W_Est_LPF;// Estimated speed for IM from MRAS with LPF
        }

        Speed_Ref_IM_MAX = 4.44 * VDC_BUS_LPF_1/VbyF_Ratio; //2PI()/sqrt(2) // Need to re-think on this

        if(Speed_Ref_IM_LPF > Speed_Ref_IM_MAX){
            Speed_Ref_IM_LPF = Speed_Ref_IM_MAX;
        }

       // Id_Ref_IM // Calculation done in Variable_Init function
       // SAI_r_IM  // Calculation done in Variable_Init function

        Speed_Error_IM = Speed_Ref_IM_LPF - Speed_FB_IM;

        //*********************************PI On Speed_Error_IM*************************************************************//

        if(Speed_Error_IM > Speed_Error_IM_Max)  Speed_Error_IM = Speed_Error_IM_Max;
        if(Speed_Error_IM < -Speed_Error_IM_Max) Speed_Error_IM = -Speed_Error_IM_Max;

        errorintokp = Speed_Error_IM_PI_Kp * Speed_Error_IM;
        errorintoki = Speed_Error_IM_PI_Ki * Speed_Error_IM * Ts;

        Speed_Error_Integ = errorintoki + Speed_Error_Integ_Prev;
        // Adding saturation on Integration
        if(Speed_Error_Integ > Torque_Ref_IM_Max) Speed_Error_Integ = Torque_Ref_IM_Max;
        if(Speed_Error_Integ < -Torque_Ref_IM_Max) Speed_Error_Integ = -Torque_Ref_IM_Max;

        Speed_Error_Integ_Prev = Speed_Error_Integ;

        Torque_Ref_IM  = Speed_Error_Integ + errorintokp;

        if(Torque_Ref_IM > Torque_Ref_IM_Max) Torque_Ref_IM = Torque_Ref_IM_Max;
        if(Torque_Ref_IM < -Torque_Ref_IM_Max) Torque_Ref_IM = -Torque_Ref_IM_Max;

        //*********************************End of PI On Speed_Error_IM*************************************************************//

        Iq_Ref_IM  = Torque_Ref_IM * VC_Factor;

        Num  = Iq_Ref_IM * Rr;
        Den  = Id_Ref_IM * Lr;

        W_Slip_Est = __divf32(Num,Den);
        W_Stator   = W_Slip_Est + (Speed_FB_IM * RATED_POLE_IM * 0.5);
       // W_Stator   = 314;
        Theta_IM   = W_Stator * Ts +  Theta_IM_Prev;

        if(Theta_IM > PIinto2){
            Theta_IM = Theta_IM - PIinto2;
        }
        if(Theta_IM < -PIinto2){
            Theta_IM = Theta_IM + PIinto2;
        }
        Theta_IM_Prev = Theta_IM;

        //Theta_IM_PU = Theta_IM_Prev;

        SIN_THETA     = sinf(Theta_IM_Prev);  // this is done to save some computation time
        COS_THETA     = cosf(Theta_IM_Prev);
        SIN_THETA_120 = sinf(Theta_IM_Prev - 2.094395);
        COS_THETA_120 = cosf(Theta_IM_Prev - 2.094395);
        SIN_THETA_240 = - SIN_THETA - SIN_THETA_120;
        COS_THETA_240 = - COS_THETA - COS_THETA_120;

       // Id_Ref_IM = Id_Ref_IM_debug;
       // Iq_Ref_IM = Iq_Ref_IM_debug;
        IR_Ref_IM = Id_Ref_IM * SIN_THETA + Iq_Ref_IM * COS_THETA;
        IY_Ref_IM = Id_Ref_IM * SIN_THETA_120 + Iq_Ref_IM * COS_THETA_120;
        IB_Ref_IM = -IR_Ref_IM - IY_Ref_IM;

        Id_Sensed_IM =  0.667*(I_INV_R * SIN_THETA + I_INV_Y * SIN_THETA_120 + I_INV_B * SIN_THETA_240);
        Iq_Sensed_IM =  0.667*(I_INV_R * COS_THETA + I_INV_Y * COS_THETA_120 + I_INV_B * COS_THETA_240);

        Id_IM_Error = Id_Ref_IM - Id_Sensed_IM;
        Iq_IM_Error = Iq_Ref_IM - Iq_Sensed_IM;


        //*********************************PI On Id_IM_Error *****************************************************************//

        if(Id_IM_Error > Id_Iq_Error_Max)  Id_IM_Error = Id_Iq_Error_Max;
        if(Id_IM_Error < -Id_Iq_Error_Max) Id_IM_Error = -Id_Iq_Error_Max;

        errorintokp = Current_Error_Id_Kp * Id_IM_Error;
        errorintoki = Current_Error_Id_Ki * Id_IM_Error * Ts;
        Current_Error_Id_Integ = errorintoki + Current_Error_Id_Integ_Prev;

        // Adding saturation on Integration
        if(Current_Error_Id_Integ > Current_Error_Integ_Max) Current_Error_Id_Integ = Current_Error_Integ_Max;
        if(Current_Error_Id_Integ < -Current_Error_Integ_Max) Current_Error_Id_Integ = -Current_Error_Integ_Max;

        Current_Error_Id_Integ_Prev = Current_Error_Id_Integ;

        Vd_Ref_IM  = Current_Error_Id_Integ + errorintokp;

        if(Vd_Ref_IM > Current_Error_Integ_Max) Vd_Ref_IM = Current_Error_Integ_Max;
        if(Vd_Ref_IM < -Current_Error_Integ_Max) Vd_Ref_IM = -Current_Error_Integ_Max;

        //*********************************End of PI On Id_IM_Error *************************************************************//


        //*********************************PI On Iq_IM_Error*********************************************************************//

        if(Iq_IM_Error > Id_Iq_Error_Max)  Iq_IM_Error = Id_Iq_Error_Max;
        if(Iq_IM_Error < -Id_Iq_Error_Max) Iq_IM_Error = -Id_Iq_Error_Max;

        errorintokp = Current_Error_Iq_Kp * Iq_IM_Error;
        errorintoki = Current_Error_Iq_Ki * Iq_IM_Error * Ts;
        Current_Error_Iq_Integ = errorintoki + Current_Error_Iq_Integ_Prev;

        // Adding saturation on Integration
        if(Current_Error_Iq_Integ > Current_Error_Integ_Max) Current_Error_Iq_Integ = Current_Error_Integ_Max;
        if(Current_Error_Iq_Integ < -Current_Error_Integ_Max) Current_Error_Iq_Integ = -Current_Error_Integ_Max;

        Current_Error_Iq_Integ_Prev = Current_Error_Iq_Integ;

        Vq_Ref_IM  = Current_Error_Iq_Integ + errorintokp;

        if(Vq_Ref_IM > Current_Error_Integ_Max) Vq_Ref_IM = Current_Error_Integ_Max;
        if(Vq_Ref_IM < -Current_Error_Integ_Max) Vd_Ref_IM = -Current_Error_Integ_Max;

        //*********************************End of PI On Iq_IM_Error*************************************************************//
        Vd_IM_FF  = 0.667 * SAI_r_IM/Tr;
        Vq_IM_FF  = 1.5 * Speed_FB_IM * SAI_r_IM /RATED_POLE_IM;

        //Vd_Ref_IM = Id_Ref_IM_debug;
        //Vq_Ref_IM = Iq_Ref_IM_debug;

        Vd_Ref_IM1 = Vd_Ref_IM - Vd_IM_FF;
        Vq_Ref_IM1 = Vq_Ref_IM + Vq_IM_FF;

        Vd_Ref_IM2 = (Vd_Ref_IM1 * -0.0044);  // Here Perunitisation for m is done by multiplying  2/VDC i.e 600
        Vq_Ref_IM2 = (Vq_Ref_IM1 * -0.0044);


        VR_Ref_IM = Vd_Ref_IM2 * SIN_THETA + Vq_Ref_IM2 * COS_THETA;
        VY_Ref_IM = Vd_Ref_IM2 * SIN_THETA_120 + Vq_Ref_IM2 * COS_THETA_120;
        VB_Ref_IM = -VR_Ref_IM - VY_Ref_IM;


        Max = fmaxf(VR_Ref_IM, VY_Ref_IM);
        Max = fmaxf(Max,VB_Ref_IM);

        Min = fminf(VR_Ref_IM, VY_Ref_IM);
        Min = fminf(Min,VB_Ref_IM);

        Mid = -(Max+Min)*0.5;

        //CSVPWM implementation
        if(SPEED_FORWARD){
            Sin1_CSVPWM = 1.1547*(VR_Ref_IM)+Mid;
            Sin2_CSVPWM = 1.1547*(VY_Ref_IM)+Mid;
            Sin3_CSVPWM = 1.1547*(VB_Ref_IM)+Mid;
        }
        else if(!SPEED_FORWARD){
            Sin1_CSVPWM = 1.1547*(VY_Ref_IM)+Mid;
            Sin2_CSVPWM = 1.1547*(VR_Ref_IM)+Mid;
            Sin3_CSVPWM = 1.1547*(VB_Ref_IM)+Mid;
        }

        duty1 = floorf(INVERTER_PERIOD*(0.5*Sin1_CSVPWM+0.5));
        duty3 = floorf(INVERTER_PERIOD*(0.5*Sin2_CSVPWM+0.5));
        duty5 = floorf(INVERTER_PERIOD*(0.5*Sin3_CSVPWM+0.5));

        EPwm5Regs.CMPA.bit.CMPA = duty1;   //R
        EPwm5Regs.CMPB.bit.CMPB = duty1;

        EPwm6Regs.CMPA.bit.CMPA = duty3;   //Y
        EPwm6Regs.CMPB.bit.CMPB = duty3;

        EPwm7Regs.CMPA.bit.CMPA = duty5;   //B
        EPwm7Regs.CMPB.bit.CMPB = duty5;

     if(ALL_PWM_LOW == true && PWM_Release_Flag == 10){
            //Relesase pluses
            TZ_CLR_PWM();
            GpioDataRegs.GPHCLEAR.bit.GPIO228     = 1;
        }

        PWM_Release_Flag++;
        if(PWM_Release_Flag > 10){
            PWM_Release_Flag = 10;
        }

    }
    else{

        TZ_FRC_PWM_low();
        GpioDataRegs.GPHSET.bit.GPIO228     = 1;
        PWM_Release_Flag  = false;

        EPwm5Regs.CMPA.bit.CMPA = 0;   //R
        EPwm5Regs.CMPB.bit.CMPB = 0;

        EPwm6Regs.CMPA.bit.CMPA = 0;   //Y
        EPwm6Regs.CMPB.bit.CMPB = 0;

        EPwm7Regs.CMPA.bit.CMPA = 0;   //B
        EPwm7Regs.CMPB.bit.CMPB = 0;

        Set_Speed_Ref_IM_Prev       = 0;
        Speed_Ref_IM                = 0;
        Speed_FB_IM                 = 0;
        Theta_IM_Prev               = 0;
        Speed_Error_Integ           = 0;
        Speed_Error_Integ_Prev      = 0;
        Current_Error_Id_Integ      = 0;
        Current_Error_Iq_Integ      = 0;
        Current_Error_Id_Integ_Prev = 0;
        Current_Error_Iq_Integ_Prev = 0;

    }



}
