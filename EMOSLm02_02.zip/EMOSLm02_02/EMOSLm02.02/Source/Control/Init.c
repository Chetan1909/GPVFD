/*
 * Init.c
 *
 *  Created on: 13-May-2023
 *      Author: Manoj Modi
 */
/*****************************************ABOUT**********************************************/
/*
 * This file deals with various initializations (control) required for DSP
 * ex. GPIOs, PWMs, ADC, DAC etc.
 */
/********************************************************************************************/

#include <Headers/Project_Header/Init.h>


// initADC - Function to configure and power up ADCA.
//
void ConfigureADC(void){
    //
    // Setup VREF as internal
    //
    SetVREF(ADC_ADCA, ADC_EXTERNAL, ADC_VREF3P3);

    EALLOW;

    //
    // Set ADCCLK divider to /4
    //
    AdcaRegs.ADCCTL2.bit.PRESCALE = 6;

    //
    // Set pulse positions to late
    //
    AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    //
    // Power up the ADC and then delay for 1 ms
    //
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;

    EDIS;

    DELAY_US(1000);
}


/**************************************DAC INIT**********************************************/
/*
 * This functions initialize DAC pins in order to observe any parameter outside.
 */

/********************************************************************************************/

void ConfigureDAC(void){
    EALLOW;
    Cmpss1Regs.COMPLOCK.bit.COMPCTL             = 0;
    Cmpss1Regs.COMPCTL.bit.COMPDACE             = 1;
    AnalogSubsysRegs.CMPSSCTL.bit.CMPSSCTLEN    = 1;
    AnalogSubsysRegs.CMPSSCTL.bit.CMP1LDACOUTEN = 1;
    Cmpss1Regs.COMPDACHCTL.bit.SWLOADSEL        = 0;
    Cmpss1Regs.DACLVALS.all                     = 0;
    EDIS;
}

//
// Configure all EPWM modules as per the application requirement
//
void ConfigureEPWM(void){

    InitEPwm1Example();
    InitEPwm2Example(); //GATE_CLK
    InitEPwm5Example(); //R
    InitEPwm6Example(); //Y
    InitEPwm7Example(); //B
}

//
// initEPWM - Function to configure ePWM1 to generate the SOC.
//
void InitEPwm1Example(void){
    EALLOW;
    EPwm1Regs.TBPRD                     = INTERRUPT_PERIOD;           // Set period to 300 counts;
    EPwm1Regs.TBPHS.bit.TBPHS           = 0x0001;
    EPwm1Regs.TBCTR                     = 0x0000;
    // Set Compare values
    EPwm1Regs.CMPA.bit.CMPA             = INTERRUPT_PERIOD/2;  // Set compare A value to 150 counts
    EPwm1Regs.CMPB.bit.CMPB             = INTERRUPT_PERIOD/2;   //INTERRUPT_PERIOD/2;
    // Setup counter mode
    EPwm1Regs.TBCTL.bit.CTRMODE         = TB_COUNT_UPDOWN;
    EPwm1Regs.TBCTL.bit.PHSEN           = TB_DISABLE;
    EPwm1Regs.TBCTL.bit.HSPCLKDIV       = TB_DIV1;
    EPwm1Regs.TBCTL.bit.CLKDIV          = TB_DIV1;
    // Setup shadowing
    EPwm1Regs.CMPCTL.bit.SHDWAMODE      = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.SHDWBMODE      = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.LOADAMODE      = CC_CTR_ZERO;
    EPwm1Regs.CMPCTL.bit.LOADBMODE      = CC_CTR_ZERO;
    // Set actions
    EPwm1Regs.AQCTLA.bit.CAU            = AQ_CLEAR;
    EPwm1Regs.AQCTLA.bit.CAD            = AQ_SET;
    EPwm1Regs.DBCTL.bit.OUT_MODE        = DB_FULL_ENABLE;
    EPwm1Regs.DBCTL.bit.POLSEL          = DB_ACTV_HIC;
    EPwm1Regs.DBFED.bit.DBFED           = BAND;
    EPwm1Regs.DBRED.bit.DBRED           = BAND;


    EPwm1Regs.ETSEL.bit.SOCAEN  = 1;     // Disable SOC on A group
    EPwm1Regs.ETSEL.bit.SOCASEL = 1;    // Select SOC on up-count
    EPwm1Regs.ETPS.bit.SOCAPRD  = 1;     // Generate pulse on 1st event

    EDIS;
}

void InitEPwm2Example(void){
        EALLOW;
        EPwm2Regs.TBPRD                     = GATE_CLK_PERIOD;         // Set period to 300 counts;
        EPwm2Regs.TBPHS.bit.TBPHS           = 0x0000;
        EPwm2Regs.TBCTR                     = 0x0000;
        // Set Compare values
        EPwm2Regs.CMPA.bit.CMPA             = GATE_CLK_PERIOD/2;   // Set compare A value to 150 counts
        EPwm2Regs.CMPB.bit.CMPB             = GATE_CLK_PERIOD/2;   //INTERRUPT_PERIOD/2;
        // Setup counter mode
        EPwm2Regs.TBCTL.bit.CTRMODE         = TB_COUNT_UPDOWN;
        EPwm2Regs.TBCTL.bit.PHSEN           = TB_DISABLE;
        EPwm2Regs.TBCTL.bit.HSPCLKDIV       = TB_DIV1;
        EPwm2Regs.TBCTL.bit.CLKDIV          = TB_DIV1;
        // Setup shadowing
        EPwm2Regs.CMPCTL.bit.SHDWAMODE      = CC_SHADOW;
        EPwm2Regs.CMPCTL.bit.SHDWBMODE      = CC_SHADOW;
        EPwm2Regs.CMPCTL.bit.LOADAMODE      = CC_CTR_ZERO;
        EPwm2Regs.CMPCTL.bit.LOADBMODE      = CC_CTR_ZERO;
        // Set actions
        EPwm2Regs.AQCTLA.bit.CAU            = AQ_CLEAR;
        EPwm2Regs.AQCTLA.bit.CAD            = AQ_SET;
        EPwm2Regs.DBCTL.bit.OUT_MODE        = DB_DISABLE;
        EPwm2Regs.DBCTL.bit.POLSEL          = DB_ACTV_HIC;
        EPwm2Regs.DBFED.bit.DBFED           = BAND;
        EPwm2Regs.DBRED.bit.DBRED           = BAND;

        EDIS;
}

    // Setup TBCLK
void InitEPwm5Example(){
    EALLOW;
    EPwm5Regs.TBPRD                     = INVERTER_PERIOD;
    EPwm5Regs.TBPHS.bit.TBPHS           = 0x0000;
    EPwm5Regs.TBCTR                     = 0x0000;
    // Set Compare values
    EPwm5Regs.CMPA.bit.CMPA             = INVERTER_PERIOD/2;
    EPwm5Regs.CMPB.bit.CMPB             = INVERTER_PERIOD/2;
    // Setup counter mode
    EPwm5Regs.TBCTL.bit.CTRMODE         = TB_COUNT_UPDOWN;
    EPwm5Regs.TBCTL.bit.PHSEN           = TB_DISABLE;
    EPwm5Regs.TBCTL.bit.HSPCLKDIV       = TB_DIV1;
    EPwm5Regs.TBCTL.bit.CLKDIV          = TB_DIV1;
    // Setup shadowing
    EPwm5Regs.CMPCTL.bit.SHDWAMODE      = CC_SHADOW;
    EPwm5Regs.CMPCTL.bit.SHDWBMODE      = CC_SHADOW;
    EPwm5Regs.CMPCTL.bit.LOADAMODE      = CC_CTR_ZERO;
    EPwm5Regs.CMPCTL.bit.LOADBMODE      = CC_CTR_ZERO;
    // Set actions
    EPwm5Regs.AQCTLA.bit.CAU            = AQ_SET;
    EPwm5Regs.AQCTLA.bit.CAD            = AQ_CLEAR;
    EPwm5Regs.DBCTL.bit.OUT_MODE        = DB_FULL_ENABLE;
    EPwm5Regs.DBCTL.bit.POLSEL          = DB_ACTV_HIC;
    EPwm5Regs.DBFED.bit.DBFED           = BAND_INV;
    EPwm5Regs.DBRED.bit.DBRED           = BAND_INV;

    EPwm5Regs.TZSEL.bit.OSHT1           = 1;
    EPwm5Regs.TZCTL.bit.TZA             = 2;
    EPwm5Regs.TZCTL.bit.TZB             = 2;

    EPwm5Regs.TZFRC.bit.OST             = 1;

    EDIS;
}

void InitEPwm6Example(){
    // Setup TBCLK
    EALLOW;
    EPwm6Regs.TBPRD                     = INVERTER_PERIOD;
    EPwm6Regs.TBPHS.bit.TBPHS           = 0x0000;
    EPwm6Regs.TBCTR                     = 0x0000;
    // Set Compare values
    EPwm6Regs.CMPA.bit.CMPA             = INVERTER_PERIOD/2;
    EPwm6Regs.CMPB.bit.CMPB             = INVERTER_PERIOD/2;
    // Setup counter mode
    EPwm6Regs.TBCTL.bit.CTRMODE         = TB_COUNT_UPDOWN;
    EPwm6Regs.TBCTL.bit.PHSEN           = TB_DISABLE;
    EPwm6Regs.TBCTL.bit.HSPCLKDIV       = TB_DIV1;
    EPwm6Regs.TBCTL.bit.CLKDIV          = TB_DIV1;
    // Setup shadowing
    EPwm6Regs.CMPCTL.bit.SHDWAMODE      = CC_SHADOW;
    EPwm6Regs.CMPCTL.bit.SHDWBMODE      = CC_SHADOW;
    EPwm6Regs.CMPCTL.bit.LOADAMODE      = CC_CTR_ZERO;
    EPwm6Regs.CMPCTL.bit.LOADBMODE      = CC_CTR_ZERO;
    // Set actions
    EPwm6Regs.AQCTLA.bit.CAU            = AQ_SET;
    EPwm6Regs.AQCTLA.bit.CBD            = AQ_CLEAR;
    EPwm6Regs.DBCTL.bit.OUT_MODE        = DB_FULL_ENABLE;
    EPwm6Regs.DBCTL.bit.POLSEL          = DB_ACTV_HIC;
    EPwm6Regs.DBFED.bit.DBFED           = BAND_INV;
    EPwm6Regs.DBRED.bit.DBRED           = BAND_INV;

    EPwm6Regs.TZSEL.bit.OSHT1           = 1;
    EPwm6Regs.TZCTL.bit.TZA             = 2;
    EPwm6Regs.TZCTL.bit.TZB             = 2;

    EPwm6Regs.TZFRC.bit.OST = 1;

    EDIS;
}

void InitEPwm7Example(){
    // Setup TBCLK
    EALLOW;
    EPwm7Regs.TBPRD                     = INVERTER_PERIOD;
    EPwm7Regs.TBPHS.bit.TBPHS           = 0x0000;
    EPwm7Regs.TBCTR                     = 0x0000;
    // Set Compare values
    EPwm7Regs.CMPA.bit.CMPA             = INVERTER_PERIOD/2;
    EPwm7Regs.CMPB.bit.CMPB             = INVERTER_PERIOD/2;
    // Setup counter mode
    EPwm7Regs.TBCTL.bit.CTRMODE         = TB_COUNT_UPDOWN;
    EPwm7Regs.TBCTL.bit.PHSEN           = TB_DISABLE;
    EPwm7Regs.TBCTL.bit.HSPCLKDIV       = TB_DIV1;
    EPwm7Regs.TBCTL.bit.CLKDIV          = TB_DIV1;
    // Setup shadowing
    EPwm7Regs.CMPCTL.bit.SHDWAMODE      = CC_SHADOW;
    EPwm7Regs.CMPCTL.bit.SHDWBMODE      = CC_SHADOW;
    EPwm7Regs.CMPCTL.bit.LOADAMODE      = CC_CTR_ZERO;
    EPwm7Regs.CMPCTL.bit.LOADBMODE      = CC_CTR_ZERO;
    // Set actions
    EPwm7Regs.AQCTLA.bit.CAU            = AQ_SET;
    EPwm7Regs.AQCTLA.bit.CBD            = AQ_CLEAR;
    EPwm7Regs.DBCTL.bit.OUT_MODE        = DB_FULL_ENABLE;
    EPwm7Regs.DBCTL.bit.POLSEL          = DB_ACTV_HIC;
    EPwm7Regs.DBFED.bit.DBFED           = BAND_INV;
    EPwm7Regs.DBRED.bit.DBRED           = BAND_INV;

    EPwm7Regs.TZSEL.bit.OSHT1           = 1;
    EPwm7Regs.TZCTL.bit.TZA             = 2;
    EPwm7Regs.TZCTL.bit.TZB             = 2;

    EPwm7Regs.TZFRC.bit.OST = 1;
    EDIS;
}

void TZ_init(){
    EALLOW;

    InputXbarRegs.INPUT1SELECT          = 226;             // GPIO226 is mapped to TZ1
    EPwm4Regs.TZSEL.bit.OSHT1           = 1;
    EPwm4Regs.TZEINT.bit.OST            = 1;
    EPwm4Regs.TZOSTCLR.bit.OST1         = 1;
    EPwm4Regs.TZCLR.bit.INT             = 1;

    EDIS;
}

void TZ_FRC_PWM_low(){
    EALLOW;
    EPwm5Regs.TZFRC.bit.OST = 1;
    EPwm6Regs.TZFRC.bit.OST = 1;
    EPwm7Regs.TZFRC.bit.OST = 1;
    EDIS;
    ALL_PWM_LOW = true;
}

void TZ_CLR_PWM(){
    EALLOW;
    EPwm5Regs.TZCLR.bit.OST  = 1;
    EPwm6Regs.TZCLR.bit.OST  = 1;
    EPwm7Regs.TZCLR.bit.OST  = 1;
    EDIS;
    ALL_PWM_LOW = false;
}
void Power_flow_Manager(){

    if(GPIO_ReadPin(7)!=High){
        Button_Pressed = Minute_Count;
        while(GPIO_ReadPin(7)==Low){
            ON_BUTTON_COUNT++;
            if(ON_BUTTON_COUNT>100){
                ON_BUTTON_COUNT = 100;
                break;
            }
        }
        if(!ON_OFF_FLAG && ON_BUTTON_COUNT> 50){
            Button_Pressed = Minute_Count;
            MASTER_ON_OFF = 1;
            EEPROM_WriteInt(2,12,1);   //  MASTER_ON_OFF
            P_PV_Avg_DELAY_TIMER = Minute_Count;
            ON_OFF_FLAG    = 1;
            Exit_Count_SS = Minute_Count;
            ON_BUTTON_COUNT = 0;
        }
    }

   /* if(MASTER_ON_OFF == 0){
        SOFT_STOP_FLAG   = 1;
    }*/

    if(GPIO_ReadPin(5)!=High){
        Button_Pressed = Minute_Count;
        while(GPIO_ReadPin(5)==Low){
            OFF_BUTTON_COUNT++;
            if(OFF_BUTTON_COUNT>100){
                OFF_BUTTON_COUNT = 100;
                break;
            }
        }
        if(ON_OFF_FLAG && OFF_BUTTON_COUNT> 50){
            Button_Pressed = Minute_Count;
            OFF_BUTTON_COUNT = 0;
            SOFT_STOP_FLAG   = 1;
            MASTER_ON_OFF = 0;
            EEPROM_WriteInt(2,12,0);   //  MASTER_ON_OFF
        }
    }
    if(LOW_SPEED_OFF_FLAG ==true /*|| RECORD_DATA == true*/){
          // MASTER_ON_OFF       = false;  //This is required to manage SPEED_MODE_SELECT == 1 to re-attempt
           ON_OFF_FLAG         = false;
           SOFT_STOP_FLAG      = false;
           LOW_SPEED_OFF_FLAG  = false;
    }

    if(SPEED_MODE_SELECT == 1){
        if(VDC_BUS_LPF_50>200){
            if(SysTime_Minute_Count_IntervalElapsed(ON_OFF_DELAY_TIMER, Retry_time_Minutes)){
                ON_OFF_DELAY_TIMER = Minute_Count;
                Delay_flag = true;
                FAULT_CODE              &= LOW_POWER_FLT_BIT_CLR_BIT;
            }
        }

        if(!ON_OFF_FLAG){
            if(VDC_BUS_LPF_50>200 && Delay_flag == true && FAULT_CODE ==0 && MASTER_ON_OFF==1){
                ON_OFF_FLAG = true;
                SOFT_START_FLAG  = true;
                Exit_Count_SS = Minute_Count;
                P_PV_Avg_DELAY_TIMER = Minute_Count;
            }
        }

        if(Warning_LOW_POWER== true && ON_OFF_FLAG && SOFT_STOP_FLAG == false){
            Warning_LOW_POWER= false;
        }

//        else if(MASTER_ON_OFF==1){
//            ON_OFF_FLAG         = 1;
//        }
        if(ON_OFF_FLAG){
            if(SysTime_Minute_Count_IntervalElapsed(P_PV_Avg_DELAY_TIMER, 1)){
                if(P_PV_Avg<MIN_PV_POWER) {
                    SOFT_STOP_FLAG = true;
                    Warning_LOW_POWER   = true;
                    Delay_flag = false;
                    ON_OFF_DELAY_TIMER = Minute_Count;
                    Retry_time_Minutes  = ((0.0457*MIN_PV_POWER) - 0.05*P_PV_Avg);
                    if(Retry_time_Minutes > Retry_time_Minutes_EEPROM){
                        Retry_time_Minutes = Retry_time_Minutes_EEPROM;
                    }
                    else if (Retry_time_Minutes < 0.5){
                        Retry_time_Minutes = 0.5;
                    }

                }
                else if(P_PV_Avg > MIN_PV_POWER){               // MNM_PWR_TON
                    Warning_LOW_POWER   = false;
                }
            }
        }
    }

}
//
// initADCSOC - Function to configure ADCA's SOC0 to be triggered by ePWM1.
//
void SetupADCEpwm(void)
{
    //
    // Select the channels to convert and the end of conversion flag
    //
    EALLOW;
    AdcaRegs.ADCSOC1CTL.bit.CHSEL   = 1;   // SOC0 will convert pin A0   // VDC_BUS_SNS_DSP
                                           // 0:A0  1:A1  2:A2  3:A3
                                           // 4:A4   5:A5   6:A6   7:A7
                                           // 8:A8   9:A9   A:A10  B:A11
                                           // C:A12  D:A13  E:A14  F:A15
    AdcaRegs.ADCSOC1CTL.bit.ACQPS   = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC1CTL.bit.TRIGSEL = 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC3CTL.bit.CHSEL   = 3;   // ANA_MUX_DSP
    AdcaRegs.ADCSOC3CTL.bit.ACQPS   = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC3CTL.bit.TRIGSEL = 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC4CTL.bit.CHSEL   = 4;   // GRD_I1_SNS_DSP
    AdcaRegs.ADCSOC4CTL.bit.ACQPS   = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC4CTL.bit.TRIGSEL = 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC5CTL.bit.CHSEL   = 5;   // INV_CURR_I2_SNS_DSP
    AdcaRegs.ADCSOC5CTL.bit.ACQPS   = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC5CTL.bit.TRIGSEL = 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC7CTL.bit.CHSEL   = 7;   // PLC_Vin2Vsns_DSP
    AdcaRegs.ADCSOC7CTL.bit.ACQPS   = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC7CTL.bit.TRIGSEL = 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC8CTL.bit.CHSEL   = 8;   // RY_VOLT_SNS_DSP
    AdcaRegs.ADCSOC8CTL.bit.ACQPS   = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC8CTL.bit.TRIGSEL = 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC10CTL.bit.CHSEL  = 10;  // YB_VOLT_SNS_DSP
    AdcaRegs.ADCSOC10CTL.bit.ACQPS  = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC10CTL.bit.TRIGSEL= 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC11CTL.bit.CHSEL  = 11;  // INV_CURR_I1_SNS_DSP
    AdcaRegs.ADCSOC11CTL.bit.ACQPS  = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC11CTL.bit.TRIGSEL= 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC12CTL.bit.CHSEL  = 12;  // PLC_Iin2Vsns_DSP
    AdcaRegs.ADCSOC12CTL.bit.ACQPS  = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC12CTL.bit.TRIGSEL= 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC14CTL.bit.CHSEL  = 14;  // VW_VOLT_SNS_DSP
    AdcaRegs.ADCSOC14CTL.bit.ACQPS  = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC14CTL.bit.TRIGSEL= 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC15CTL.bit.CHSEL  = 15;  // UV_VOLT_SNS_DSP
    AdcaRegs.ADCSOC15CTL.bit.ACQPS  = 9;   // Sample window is 10 SYSCLK cycles
    AdcaRegs.ADCSOC15CTL.bit.TRIGSEL= 5;   // Trigger on ePWM1 SOCA

    AdcaRegs.ADCINTSEL1N2.bit.INT1SEL = 15; // End of SOC0 will set INT1 flag
    AdcaRegs.ADCINTSEL1N2.bit.INT1E   = 1; // Enable INT1 flag
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; // Make sure INT1 flag is cleared

    EDIS;
}


//
// UserInitAGPIO - Function to configure various AGPIOs.
//
void AGPIO_Select(void){
    EALLOW;


    GpioCtrlRegs.GPAAMSEL.bit.GPIO12        =  0;               //EPWM7A
    AnalogSubsysRegs.AGPIOCTRLA.bit.GPIO12  =  0;               //EPWM7A
    GpioCtrlRegs.GPAAMSEL.bit.GPIO13        =  0;               //EPWM7B
    AnalogSubsysRegs.AGPIOCTRLA.bit.GPIO13  =  0;               //EPWM7B
    GpioCtrlRegs.GPAAMSEL.bit.GPIO20        =  0;               //DSC_PRE_CRG
    AnalogSubsysRegs.AGPIOCTRLA.bit.GPIO20  =  0;               //DSC_PRE_CRG
    GpioCtrlRegs.GPAAMSEL.bit.GPIO21        =  0;               //EXT_DRY1_DSP
    AnalogSubsysRegs.AGPIOCTRLA.bit.GPIO21  =  0;               //EXT_DRY1_DSP
    GpioCtrlRegs.GPAAMSEL.bit.GPIO28        =  0;               //SCIA_RX
    AnalogSubsysRegs.AGPIOCTRLA.bit.GPIO28  =  0;               //SCIA_RX

    GpioCtrlRegs.GPHAMSEL.bit.GPIO224       =  0;               //MUX_CNTRL0
    AnalogSubsysRegs.AGPIOCTRLH.bit.GPIO224 =  0;               //MUX_CNTRL0
    GpioCtrlRegs.GPHAMSEL.bit.GPIO226       =  0;               //INV_DSAT_FLT
    AnalogSubsysRegs.AGPIOCTRLH.bit.GPIO226 =  0;               //INV_DSAT_FLT
    GpioCtrlRegs.GPHAMSEL.bit.GPIO227       =  0;               //MUX_CNTRL2
    AnalogSubsysRegs.AGPIOCTRLH.bit.GPIO227 =  0;               //MUX_CNTRL2
    GpioCtrlRegs.GPHAMSEL.bit.GPIO228       =  0;               //INV_RST_DSP
    AnalogSubsysRegs.AGPIOCTRLH.bit.GPIO228 =  0;               //INV_RST_DSP
    GpioCtrlRegs.GPHAMSEL.bit.GPIO230       =  1;               // ADC A10
    AnalogSubsysRegs.AGPIOCTRLH.bit.GPIO230 =  1;               // ADC A10
    GpioCtrlRegs.GPHAMSEL.bit.GPIO242       =  1;               // ADC A3
    AnalogSubsysRegs.AGPIOCTRLH.bit.GPIO242 =  1;               // ADC A3


    EDIS;
}
//
// UserInitGPIO - Function to configure various GPIOs.
//
void GPIO_Select(void){
    EALLOW;

    // Pin 52 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO0     = (0>>2) & 0x3UL;       //  INV_SC_DET as GPIO, Mux 0 = 0000, 00
    GpioCtrlRegs.GPAMUX1.bit.GPIO0      = 0 & 0x3UL;            //  INV_SC_DET as GPIO , Mux 0 = 0000, 00
    GpioCtrlRegs.GPADIR.bit.GPIO0       = 0;                    //  INV_SC_DET as I/P
    GpioCtrlRegs.GPAPUD.bit.GPIO0       = 0;                    //  INV_SC_DET enable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO0       = 0;                    //  INV_SC_DET as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO0       = 0;                    //  INV_SC_DET non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO0     = 0;                    //  INV_SC_DET Sync-input

    // Pin 51 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO1     = (0>>2) & 0x3UL;       //  LPS_CTRL_DSP as GPIO, Mux 0 = 0000, 00
    GpioCtrlRegs.GPAMUX1.bit.GPIO1      = 0 & 0x3UL;            //  LPS_CTRL_DSP as GPIO, Mux 0 = 0000, 00
    GpioCtrlRegs.GPADIR.bit.GPIO1       = 1;                    //  LPS_CTRL_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO1       = 1;                    //  LPS_CTRL_DSP disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO1       = 0;                    //  LPS_CTRL_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO1       = 0;                    //  LPS_CTRL_DSP non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO1     = 3;                    //  LPS_CTRL_DSP Async-output

    // Pin 50 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO2     = (11>>2) & 0x3UL;       //  I2CB_SDA as I2CB SDA, Mux 11 = 1011, 11
    GpioCtrlRegs.GPAMUX1.bit.GPIO2      = 11 & 0x3UL;            //  I2CB_SDA as I2CB SDA, Mux 11 = 1011, 11
    GpioCtrlRegs.GPADIR.bit.GPIO2       = 1;                    //  I2CB_SDA as I/P
    GpioCtrlRegs.GPAPUD.bit.GPIO2       = 0;                    //  I2CB_SDA enable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO2       = 0;                    //  I2CB_SDA as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO2       = 0;                    //  I2CB_SDA non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO2     = 3;                    //  I2CB_SDA Sync-input

    // Pin 49 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO3     = (11>>2) & 0x3UL;       //  I2CB_SCL as I2CB_SCL, Mux 11 = 1011, 11
    GpioCtrlRegs.GPAMUX1.bit.GPIO3      = 11 & 0x3UL;            //  I2CB_SCL as I2CB_SCL, Mux 11 = 1011, 11
    GpioCtrlRegs.GPADIR.bit.GPIO3       = 1;                    //  I2CB_SCL as I/P
    GpioCtrlRegs.GPAPUD.bit.GPIO3       = 0;                    //  I2CB_SCL enable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO3       = 0;                    //  I2CB_SCL as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO3       = 0;                    //  I2CB_SCL non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO3     = 3;                    //  I2CB_SCL Sync-input

    // Pin 48 GPVFD // Doubt - Check
    GpioCtrlRegs.GPAGMUX1.bit.GPIO4     = (15>>2) & 0x3UL;      //  BRK_PWM_G1_DSP as EPWM1A, Mux 15 = 1111, 11
    GpioCtrlRegs.GPAMUX1.bit.GPIO4      = 15 & 0x3UL;           //  BRK_PWM_G1_DSP as EPWM1A, Mux 15 = 1111, 11
    GpioCtrlRegs.GPADIR.bit.GPIO4       = 1;                    //  BRK_PWM_G1_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO4       = 1;                    //  BRK_PWM_G1_DSP disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO4       = 0;                    //  BRK_PWM_G1_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO4       = 0;                    //  BRK_PWM_G1_DSP non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO4     = 3;                    //  BRK_PWM_G1_DSP Async-output

    // Pin 61 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO5     = (0>>2) & 0x3UL;       //  INVERTER_OFF_SW as GPIO, Mux 0 = 0000, 00
    GpioCtrlRegs.GPAMUX1.bit.GPIO5      = 0 & 0x3UL;            //  INVERTER_OFF_SW as GPIO, Mux 0 = 0000, 00
    GpioCtrlRegs.GPADIR.bit.GPIO5       = 0;                    //  INVERTER_OFF_SW as I/P
    GpioCtrlRegs.GPAPUD.bit.GPIO5       = 0;                    //  INVERTER_OFF_SW enable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO5       = 0;                    //  INVERTER_OFF_SW as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO5       = 0;                    //  INVERTER_OFF_SW non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO5     = 0;                    //  INVERTER_OFF_SW Sync-input

    // Pin 64 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO6     = (15>>2) & 0x3UL;      //  PS_PWM_500K as EPWM2A, Mux 15 = 1111, 11
    GpioCtrlRegs.GPAMUX1.bit.GPIO6      = 15 & 0x3UL;           //  PS_PWM_500K as EPWM2A, Mux 15 = 1111, 11
    GpioCtrlRegs.GPADIR.bit.GPIO6       = 1;                    //  PS_PWM_500K as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO6       = 1;                    //  PS_PWM_500K disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO6       = 0;                    //  PS_PWM_500K as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO6       = 0;                    //  PS_PWM_500K non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO6     = 3;                    //  PS_PWM_500K Async-output

    // Pin 57 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO7     = (0>>2) & 0x3UL;       //  INVERTER_ON_SW as GPIO, Mux 0 = 0000, 00
    GpioCtrlRegs.GPAMUX1.bit.GPIO7      = 0 & 0x3UL;            //  INVERTER_ON_SW as GPIO, Mux 0 = 0000, 00
    GpioCtrlRegs.GPADIR.bit.GPIO7       = 0;                    //  INVERTER_ON_SW as I/P
    GpioCtrlRegs.GPAPUD.bit.GPIO7       = 0;                    //  INVERTER_ON_SW enable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO7       = 0;                    //  INVERTER_ON_SW as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO7       = 0;                    //  INVERTER_ON_SW non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO7     = 0;                    //  INVERTER_ON_SW Sync-input

    // Pin 47 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO8     = (1>>2) & 0x3UL;       //  INV_PWM_G1_DSP as EPWM5A, Mux 1 = 0001, 00
    GpioCtrlRegs.GPAMUX1.bit.GPIO8      = 1 & 0x3UL;            //  INV_PWM_G1_DSP as EPWM5A, Mux 1 = 0001, 01
    GpioCtrlRegs.GPADIR.bit.GPIO8       = 1;                    //  INV_PWM_G1_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO8       = 1;                    //  INV_PWM_G1_DSP disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO8       = 0;                    //  INV_PWM_G1_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO8       = 0;                    //  INV_PWM_G1_DSP non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO8     = 3;                    //  INV_PWM_G1_DSP Async-output

    // Pin 62 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO9     = (1>>2) & 0x3UL;       //  INV_PWM_G2_DSP as EPWM5B, Mux 1 = 0001, 00
    GpioCtrlRegs.GPAMUX1.bit.GPIO9      = 1 & 0x3UL;            //  INV_PWM_G2_DSP as EPWM5B, Mux 1 = 0001, 01
    GpioCtrlRegs.GPADIR.bit.GPIO9       = 1;                    //  INV_PWM_G2_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO9       = 1;                    //  INV_PWM_G2_DSP disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO9       = 0;                    //  INV_PWM_G2_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO9       = 0;                    //  INV_PWM_G2_DSP non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO9     = 3;                    //  INV_PWM_G2_DSP Async-output

    // Pin 63 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO10    = (1>>2) & 0x3UL;       //  INV_PWM_G3_DSP as EPWM6A, Mux 1 = 0001, 00
    GpioCtrlRegs.GPAMUX1.bit.GPIO10     = 1 & 0x3UL;            //  INV_PWM_G3_DSP as EPWM6A, Mux 1 = 0001, 01
    GpioCtrlRegs.GPADIR.bit.GPIO10      = 1;                    //  INV_PWM_G3_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO10      = 1;                    //  INV_PWM_G3_DSP disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO10      = 0;                    //  INV_PWM_G3_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO10      = 0;                    //  INV_PWM_G3_DSP non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO10    = 3;                    //  INV_PWM_G3_DSP Async-output

    // Pin 31 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO11    = (1>>2) & 0x3UL;       //  INV_PWM_G4_DSP as EPWM6B, Mux 1 = 0001, 00
    GpioCtrlRegs.GPAMUX1.bit.GPIO11     = 1 & 0x3UL;            //  INV_PWM_G4_DSP as EPWM6B, Mux 1 = 0001, 01
    GpioCtrlRegs.GPADIR.bit.GPIO11      = 1;                    //  INV_PWM_G4_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO11      = 1;                    //  INV_PWM_G4_DSP disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO11      = 0;                    //  INV_PWM_G4_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO11      = 0;                    //  INV_PWM_G4_DSP non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO11    = 3;                    //  INV_PWM_G4_DSP Async-output

    // Pin 30 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO12    = (1>>2) & 0x3UL;       //  INV_PWM_G5_DSP as EPWM7A, Mux 1 = 0001, 00
    GpioCtrlRegs.GPAMUX1.bit.GPIO12     = 1 & 0x3UL;            //  INV_PWM_G5_DSP as EPWM7A, Mux 1 = 0001, 01
    GpioCtrlRegs.GPADIR.bit.GPIO12      = 1;                    //  INV_PWM_G5_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO12      = 1;                    //  INV_PWM_G5_DSP disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO12      = 0;                    //  INV_PWM_G5_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO12      = 0;                    //  INV_PWM_G5_DSP non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO12    = 3;                    //  INV_PWM_G5_DSP Async-output

    // Pin 29 GPVFD
    GpioCtrlRegs.GPAGMUX1.bit.GPIO13    = (1>>2) & 0x3UL;       //  INV_PWM_G6_DSP as EPWM7B, Mux 1 = 0001, 00
    GpioCtrlRegs.GPAMUX1.bit.GPIO13     = 1 & 0x3UL;            //  INV_PWM_G6_DSP as EPWM7B, Mux 1 = 0001, 01
    GpioCtrlRegs.GPADIR.bit.GPIO13      = 1;                    //  INV_PWM_G6_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO13      = 1;                    //  INV_PWM_G6_DSP disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO13      = 0;                    //  INV_PWM_G6_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO13      = 0;                    //  INV_PWM_G6_DSP non-inverting
    GpioCtrlRegs.GPAQSEL1.bit.GPIO13    = 3;                    //  INV_PWM_G6_DSP Async-output

//    //Pin 41 GPVFD
    GpioCtrlRegs.GPAGMUX2.bit.GPIO18    = (2>>2) & 0x3UL;       //  MB_TX_RS485 as SCIA_TX Mux 6 = 0110, 01
    GpioCtrlRegs.GPAMUX2.bit.GPIO18     = 2 & 0x3UL;            //  MB_TX_RS485 as SCIA_TX Mux 6 = 0110, 10
    GpioCtrlRegs.GPADIR.bit.GPIO18      = 1;                    //  MB_TX_RS485 as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO18      = 1;                    //  MB_TX_RS485 disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO18      = 0;                    //  MB_TX_RS485 as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO18      = 0;                    //  MB_TX_RS485 non-inverting
    GpioCtrlRegs.GPAQSEL2.bit.GPIO18    = 3;                    //  MB_TX_RS485 Async-output

    // Pin 42 GPVFD
    GpioCtrlRegs.GPAGMUX2.bit.GPIO19    = (2>>2) & 0x3UL;       //  MB_RX_RS485 as SCI_RX Mux 6 = 0110, 01
    GpioCtrlRegs.GPAMUX2.bit.GPIO19     = 2 & 0x3UL;            //  MB_RX_RS485 as SCI_RX Mux 6 = 0110, 10
    GpioCtrlRegs.GPADIR.bit.GPIO19      = 0;                    //  MB_RX_RS485 as I/P
    GpioCtrlRegs.GPAPUD.bit.GPIO19      = 0;                    //  MB_RX_RS485 disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO19      = 0;                    //  MB_RX_RS485 as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO19      = 0;                    //  MB_RX_RS485 non-inverting
    GpioCtrlRegs.GPAQSEL2.bit.GPIO19    = 0;                    //  MB_RX_RS485 Sync-input

//    // Pin 41 GPVFD
//    GpioCtrlRegs.GPAGMUX2.bit.GPIO18    = (2>>2) & 0x3UL;       //  I2C_SCL as I2CA_SCL Mux 6 = 0110, 01
//    GpioCtrlRegs.GPAMUX2.bit.GPIO18     = 2 & 0x3UL;            //  I2C_SCL as I2CA_SCL Mux 6 = 0110, 10
//    GpioCtrlRegs.GPADIR.bit.GPIO18      = 1;                    //  I2C_SCL as O/P
//    GpioCtrlRegs.GPAPUD.bit.GPIO18      = 0;                    //  I2C_SCL enable pullup
//    GpioCtrlRegs.GPAODR.bit.GPIO18      = 0;                    //  I2C_SCL as normal , no open drain
//    GpioCtrlRegs.GPAINV.bit.GPIO18      = 0;                    //  I2C_SCL non-inverting
//    GpioCtrlRegs.GPAQSEL2.bit.GPIO18    = 3;                    //  I2C_SCL Async-output
//
//    // Pin 42 GPVFD
//    GpioCtrlRegs.GPAGMUX2.bit.GPIO19    = (2>>2) & 0x3UL;       //  I2C_SDA as I2CA_SDA Mux 6 = 0110, 01
//    GpioCtrlRegs.GPAMUX2.bit.GPIO19     = 2 & 0x3UL;            //  I2C_SDA as I2CA_SDA Mux 6 = 0110, 10
//    GpioCtrlRegs.GPADIR.bit.GPIO19      = 1;                    //  I2C_SDA as O/P
//    GpioCtrlRegs.GPAPUD.bit.GPIO19      = 0;                    //  I2C_SDA enable pullup
//    GpioCtrlRegs.GPAODR.bit.GPIO19      = 0;                    //  I2C_SDA as normal , no open drain
//    GpioCtrlRegs.GPAINV.bit.GPIO19      = 0;                    //  I2C_SDA non-inverting
//    GpioCtrlRegs.GPAQSEL2.bit.GPIO19    = 3;                    //  I2C_SDA Async-output

    // Pin 27 GPVFD
    GpioCtrlRegs.GPAGMUX2.bit.GPIO20    = (0>>2) & 0x3UL;       //  DSP_PRE_CHG as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPAMUX2.bit.GPIO20     = 0 & 0x3UL;            //  DSP_PRE_CHG as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPADIR.bit.GPIO20      = 1;                    //  DSP_PRE_CHG as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO20      = 1;                    //  DSP_PRE_CHG disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO20      = 0;                    //  DSP_PRE_CHG as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO20      = 0;                    //  DSP_PRE_CHG non-inverting
    GpioCtrlRegs.GPAQSEL2.bit.GPIO20    = 3;                    //  DSP_PRE_CHG Async-output

    // Pin 28 GPVFD
    GpioCtrlRegs.GPAGMUX2.bit.GPIO21    = (0>>2) & 0x3UL;       //  EXT_DRY1_DSP as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPAMUX2.bit.GPIO21     = 0 & 0x3UL;            //  EXT_DRY1_DSP as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPADIR.bit.GPIO21      = 1;                    //  EXT_DRY1_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO21      = 1;                    //  EXT_DRY1_DSP disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO21      = 0;                    //  EXT_DRY1_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO21      = 0;                    //  EXT_DRY1_DSP non-inverting
    GpioCtrlRegs.GPAQSEL2.bit.GPIO21    = 3;                    //  EXT_DRY1_DSP Async-output

 // Pin 55 GPVFD //
//    GpioCtrlRegs.GPBGMUX1.bit.GPIO41    = (9>>2) & 0x3UL;       //   RS485 RX-exeliq as GPIO Mux 0 = 0000, 00
//    GpioCtrlRegs.GPBMUX1.bit.GPIO41     = 9 & 0x3UL;            //   as GPIO Mux 0 = 0000, 00
//    GpioCtrlRegs.GPBDIR.bit.GPIO41      = 0;                    //   as I/P
//    GpioCtrlRegs.GPBPUD.bit.GPIO41      = 0;                    //   enable pullup
//    GpioCtrlRegs.GPBODR.bit.GPIO41      = 0;                    //   as normal , no open drain
//    GpioCtrlRegs.GPBINV.bit.GPIO41      = 0;                    //   non-inverting
//    GpioCtrlRegs.GPBQSEL1.bit.GPIO41    = 0;                    //   sync-input

    // Pin 56 GPVFD
  //  GpioCtrlRegs.GPAGMUX2.bit.GPIO22    = (3>>2) & 0x3UL;       //  RS485 TX-exeliq as GPIO Mux 0 = 0000, 00
  //  GpioCtrlRegs.GPAMUX2.bit.GPIO22     = 3 & 0x3UL;            //   as GPIO Mux 0 = 0000, 00
  //  GpioCtrlRegs.GPADIR.bit.GPIO22      = 1;                    //   as O/P
  //  GpioCtrlRegs.GPAPUD.bit.GPIO22      = 1;                    //   disable pullup
  //  GpioCtrlRegs.GPAODR.bit.GPIO22      = 0;                    //   as normal , no open drain
   // GpioCtrlRegs.GPAINV.bit.GPIO22      = 0;                    //   non-inverting
   // GpioCtrlRegs.GPAQSEL2.bit.GPIO22    = 3;                    //   Async-output
 GpioCtrlRegs.GPAGMUX2.bit.GPIO22    = (0>>2) & 0x3UL;       //  EXT_DRY2_DSP  as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPAMUX2.bit.GPIO22     = 0 & 0x3UL;            //   EXT_DRY2_DSPas GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPADIR.bit.GPIO22      = 1;                    //  EXT_DRY2_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO22      = 1;                    //   EXT_DRY2_DSPdisable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO22      = 0;                    //  EXT_DRY2_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO22      = 0;                    //  EXT_DRY2_DSP non-inverting
    GpioCtrlRegs.GPAQSEL2.bit.GPIO22    = 3;                    //  EXT_DRY2_DSP Async-output

    // Pin 54 GPVFD
    GpioCtrlRegs.GPAGMUX2.bit.GPIO23    = (0>>2) & 0x3UL;       //  FAN_CTRL_DSP as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPAMUX2.bit.GPIO23     = 0 & 0x3UL;            //  FAN_CTRL_DSP as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPADIR.bit.GPIO23      = 1;                    //  FAN_CTRL_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO23      = 1;                    //  FAN_CTRL_DSP disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO23      = 0;                    //  FAN_CTRL_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO23      = 0;                    //  FAN_CTRL_DSP non-inverting
    GpioCtrlRegs.GPAQSEL2.bit.GPIO23    = 3;                    //  FAN_CTRL_DSP Async-output

    // Pin 35 GPVFD
    GpioCtrlRegs.GPAGMUX2.bit.GPIO24    = (0>>2) & 0x3UL;       //  DAC_EN_DSP as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPAMUX2.bit.GPIO24     = 0 & 0x3UL;            //  DAC_EN_DSP as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPADIR.bit.GPIO24      = 1;                    //  DAC_EN_DSP as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO24      = 0;                    //  DAC_EN_DSP enable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO24      = 0;                    //  DAC_EN_DSP as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO24      = 0;                    //  DAC_EN_DSP non-inverting
    GpioCtrlRegs.GPAQSEL2.bit.GPIO24    = 3;                    //  DAC_EN_DSP Async-output

    // Pin 2 GPVFD
    GpioCtrlRegs.GPAGMUX2.bit.GPIO28    = (1>>2) & 0x3UL;       //  SCIA_RX as TXD_TI_RX Mux 0 = 0001, 01
    GpioCtrlRegs.GPAMUX2.bit.GPIO28     = 1 & 0x3UL;            //  SCIA_RX as TXD_TI_RX Mux 0 = 0001, 01
    GpioCtrlRegs.GPADIR.bit.GPIO28      = 0;                    //  SCIA_RX as I/P
    GpioCtrlRegs.GPAPUD.bit.GPIO28      = 0;                    //  SCIA_RX enable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO28      = 0;                    //  SCIA_RX as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO28      = 0;                    //  SCIA_RX non-inverting
    GpioCtrlRegs.GPAQSEL2.bit.GPIO28    = 0;                    //  SCIA_RX sync-input

    // Pin 1 GPVFD
    GpioCtrlRegs.GPAGMUX2.bit.GPIO29    = (1>>2) & 0x3UL;       //  SCIA_TX as TXD_TI_TX Mux 0 = 0001, 01
    GpioCtrlRegs.GPAMUX2.bit.GPIO29     = 1 & 0x3UL;            //  SCIA_TX as TXD_TI_TX Mux 0 = 0001, 01
    GpioCtrlRegs.GPADIR.bit.GPIO29      = 1;                    //  SCIA_TX as O/P
    GpioCtrlRegs.GPAPUD.bit.GPIO29      = 1;                    //  SCIA_TX disable pullup
    GpioCtrlRegs.GPAODR.bit.GPIO29      = 0;                    //  SCIA_TX as normal , no open drain
    GpioCtrlRegs.GPAINV.bit.GPIO29      = 0;                    //  SCIA_TX non-inverting
    GpioCtrlRegs.GPAQSEL2.bit.GPIO29    = 3;                    //  SCIA_TX Async-output

    // Pin 40 GPVFD
    GpioCtrlRegs.GPBGMUX1.bit.GPIO32    = (0>>2) & 0x3UL;       //  MB_RS485_EN as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPBMUX1.bit.GPIO32     = 0 & 0x3UL;            //  MB_RS485_EN as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPBDIR.bit.GPIO32      = 1;                    //  MB_RS485_EN as O/P
    GpioCtrlRegs.GPBPUD.bit.GPIO32      = 0;                    //  MB_RS485_EN enable pullup
    GpioCtrlRegs.GPBODR.bit.GPIO32      = 0;                    //  MB_RS485_EN as normal , no open drain
    GpioCtrlRegs.GPBINV.bit.GPIO32      = 0;                    //  MB_RS485_EN non-inverting
    GpioCtrlRegs.GPBQSEL1.bit.GPIO32    = 3;                    //  MB_RS485_EN Async-output

    // Pin 32 GPVFD
    GpioCtrlRegs.GPBGMUX1.bit.GPIO33    = (0>>2) & 0x3UL;       //  MUX_CNTRL1 as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPBMUX1.bit.GPIO33     = 0 & 0x3UL;            //  MUX_CNTRL1 as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPBDIR.bit.GPIO33      = 1;                    //  MUX_CNTRL1 as O/P
    GpioCtrlRegs.GPBPUD.bit.GPIO33      = 1;                    //  MUX_CNTRL1 disable pullup
    GpioCtrlRegs.GPBODR.bit.GPIO33      = 0;                    //  MUX_CNTRL1 as normal , no open drain
    GpioCtrlRegs.GPBINV.bit.GPIO33      = 0;                    //  MUX_CNTRL1 non-inverting
    GpioCtrlRegs.GPBQSEL1.bit.GPIO33    = 3;                    //  MUX_CNTRL1 Async-output

    // Pin 39 GPVFD
    // GPIO35 not used

    // Pin 37 GPVFD
    // GPIO37 not used

    // Pin 46 GPVFD
    GpioCtrlRegs.GPBGMUX1.bit.GPIO39    = (0>>2) & 0x3UL;       //  BRK_RST_DSP and HeartBit as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPBMUX1.bit.GPIO39     = 0 & 0x3UL;            //  BRK_RST_DSP and HeartBit as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPBDIR.bit.GPIO39      = 1;                    //  BRK_RST_DSP and HeartBit as O/P
    GpioCtrlRegs.GPBPUD.bit.GPIO39      = 1;                    //  BRK_RST_DSP and HeartBit disable pullup
    GpioCtrlRegs.GPBODR.bit.GPIO39      = 0;                    //  BRK_RST_DSP and HeartBit as normal , no open drain
    GpioCtrlRegs.GPBINV.bit.GPIO39      = 0;                    //  BRK_RST_DSP and HeartBit non-inverting
    GpioCtrlRegs.GPBQSEL1.bit.GPIO39    = 3;                    //  BRK_RST_DSP and HeartBit Async-output

    // Pin 53 GPVFD // Doubt-Check
    GpioCtrlRegs.GPBGMUX1.bit.GPIO40    = (0>>2) & 0x3UL;       //  RDY_INV as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPBMUX1.bit.GPIO40     = 0 & 0x3UL;            //  RDY_INV as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPBDIR.bit.GPIO40      = 0;                    //  RDY_INV as I/P
    GpioCtrlRegs.GPBPUD.bit.GPIO40      = 0;                    //  RDY_INV enable pullup
    GpioCtrlRegs.GPBODR.bit.GPIO40      = 0;                    //  RDY_INV as normal , no open drain
    GpioCtrlRegs.GPBINV.bit.GPIO40      = 0;                    //  RDY_INV non-inverting
    GpioCtrlRegs.GPBQSEL1.bit.GPIO40    = 0;                    //  RDY_INV sync-input

//    // Pin 55 GPVFD // Doubt-Check
    GpioCtrlRegs.GPBGMUX1.bit.GPIO41    = (0>>2) & 0x3UL;       //  PLC_GPIO_MUX_DSP as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPBMUX1.bit.GPIO41     = 0 & 0x3UL;            //  PLC_GPIO_MUX_DSP as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPBDIR.bit.GPIO41      = 0;                    //  PLC_GPIO_MUX_DSP as I/P
    GpioCtrlRegs.GPBPUD.bit.GPIO41      = 0;                    //  PLC_GPIO_MUX_DSP enable pullup
    GpioCtrlRegs.GPBODR.bit.GPIO41      = 0;                    //  PLC_GPIO_MUX_DSP as normal , no open drain
    GpioCtrlRegs.GPBINV.bit.GPIO41      = 0;                    //  PLC_GPIO_MUX_DSP non-inverting
   GpioCtrlRegs.GPBQSEL1.bit.GPIO41    = 0;                    //  PLC_GPIO_MUX_DSP sync-input

    // Pin 9 GPVFD
    GpioCtrlRegs.GPHGMUX1.bit.GPIO224   = (0>>2) & 0x3UL;       //  MUX_CNTRL0 as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPHMUX1.bit.GPIO224    = 0 & 0x3UL;            //  MUX_CNTRL0 as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPHDIR.bit.GPIO224     = 1;                    //  MUX_CNTRL0 as O/P
    GpioCtrlRegs.GPHPUD.bit.GPIO224     = 1;                    //  MUX_CNTRL0 disable pullup
    GpioCtrlRegs.GPHODR.bit.GPIO224     = 0;                    //  MUX_CNTRL0 as normal , no open drain
    GpioCtrlRegs.GPHINV.bit.GPIO224     = 0;                    //  MUX_CNTRL0 non-inverting
    GpioCtrlRegs.GPHQSEL1.bit.GPIO224   = 3;                    //  MUX_CNTRL0 Async-output

    // Pin 7 GPVFD
    GpioCtrlRegs.GPHGMUX1.bit.GPIO226   = (0>>2) & 0x3UL;       //  INV_DSAT_FLT as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPHMUX1.bit.GPIO226    = 0 & 0x3UL;            //  INV_DSAT_FLT as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPHDIR.bit.GPIO226     = 0;                    //  INV_DSAT_FLT as I/P
    GpioCtrlRegs.GPHPUD.bit.GPIO226     = 0;                    //  INV_DSAT_FLT enable pullup
    GpioCtrlRegs.GPHODR.bit.GPIO226     = 0;                    //  INV_DSAT_FLT as normal , no open drain
    GpioCtrlRegs.GPHINV.bit.GPIO226     = 0;                    //  INV_DSAT_FLT non-inverting
    GpioCtrlRegs.GPHQSEL1.bit.GPIO226   = 2;                    //  INV_DSAT_FLT sync-input
    GpioCtrlRegs.GPHCTRL.bit.QUALPRD0   = 100;

    // Pin 24 GPVFD
    GpioCtrlRegs.GPHGMUX1.bit.GPIO227   = (0>>2) & 0x3UL;       //  MUX_CNTRL2 as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPHMUX1.bit.GPIO227    = 0 & 0x3UL;            //  MUX_CNTRL2 as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPHDIR.bit.GPIO227     = 1;                    //  MUX_CNTRL2 as O/P
    GpioCtrlRegs.GPHPUD.bit.GPIO227     = 1;                    //  MUX_CNTRL2 disable pullup
    GpioCtrlRegs.GPHODR.bit.GPIO227     = 0;                    //  MUX_CNTRL2 as normal , no open drain
    GpioCtrlRegs.GPHINV.bit.GPIO227     = 0;                    //  MUX_CNTRL2 non-inverting
    GpioCtrlRegs.GPHQSEL1.bit.GPIO227   = 3;                    //  MUX_CNTRL2 Async-output

    // Pin 6 GPVFD
    GpioCtrlRegs.GPHGMUX1.bit.GPIO228   = (0>>2) & 0x3UL;       //  INV_RST_DSP as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPHMUX1.bit.GPIO228    = 0 & 0x3UL;            //  INV_RST_DSP as GPIO Mux 0 = 0000, 00
    GpioCtrlRegs.GPHDIR.bit.GPIO228     = 1;                    //  INV_RST_DSP as O/P
    GpioCtrlRegs.GPHPUD.bit.GPIO228     = 1;                    //  INV_RST_DSP disable pullup
    GpioCtrlRegs.GPHODR.bit.GPIO228     = 0;                    //  INV_RST_DSP as normal , no open drain
    GpioCtrlRegs.GPHINV.bit.GPIO228     = 0;                    //  INV_RST_DSP non-inverting
    GpioCtrlRegs.GPHQSEL1.bit.GPIO228   = 3;                    //  INV_RST_DSP Async-output

    EDIS;
}
