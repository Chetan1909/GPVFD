/*
 * Vector_CTRL_SynRM.C
 *
 *  Created on: 20-Jan-2025
 *      Author: manoj
 */
#include <Headers/Project_Header/Init.h>
void Motor_Parameter_Estimation_SynRM(void){

}
void Speed_Estimation_SynRM(void){

}
void Vector_Control_SynRM(void){

}
