/*
 * Vector_CTRL_PMSM.c
 *
 *  Created on: 20-Jan-2025
 *      Author: manoj
 */
#include <Headers/Project_Header/Init.h>

void Motor_Parameter_Estimation_PMSM(void){

}
void Speed_Estimation_PMSM(void){
    float errorintoki =0, errorintokp = 0;

    /*if(ON_OFF_FLAG == true){
        if(SPEED_MODE_SELECT == 3 && SOFT_STOP_FLAG==0 && SPEED_STOP_INCREASE==false){
            Speed_Ref_PM = SPEED_RPM_REF_UI *0.10472* No_of_Pole_Pair_PM; // RPM*PI/30*pole_pair     (0.10472 = PIinto2/60)
        }*/

    V_Peak_corr_Avg1 = V_Peak_corr_Avg;

    if (V_Peak_corr_Avg1 < 3)
        V_Peak_corr_Avg1 = 3;

    /*if (flag_VFD_MPP_Initial == 0) {
                   Speed_Ref_PM_fcorr = Speed_Ref_PM3;
               }
               else {
                   Speed_Ref_PM_fcorr = Speed_Ref_PM;
               }*/

    Corres_Speed1 = 0.92 * 4.44 * VDC_BUS_LPF_50 * RATED_FREQ_PM/RATED_VOLT_PM; // 2PI()/sqrt(2) // 4.4 *0.92=4.05
    Corres_Speed2 = (Speed_Ref_PM3*0.707 * VDC_BUS_LPF_50)/(V_Peak_corr_Avg1); // 2PI()/sqrt(2) // 4.4 *0.92=4.05

    if (Corres_Speed2 > SPEED_LIMIT_MAX_FREQ_SET) Corres_Speed2 = SPEED_LIMIT_MAX_FREQ_SET;
    if (Corres_Speed2 < SPEED_LIMIT_RATED_FREQ_SET) Corres_Speed2 = SPEED_LIMIT_RATED_FREQ_SET;   //To avoid corresponding speed being hit during initial or grid-case


    Corres_Speed = fminf(Corres_Speed1,Corres_Speed2);

    if(Speed_Ref_PM > 0.98*Corres_Speed){
        FLAG_FREQ_CORRES = true;
    }
    else if(Speed_Ref_PM < 0.93*Corres_Speed){
        FLAG_FREQ_CORRES = false;
    }
    else{
        //NO WORK
    }

    if(APP_MODE == 0){
        Corres_Speed = Corres_Speed; //Removed *1.05 to limit reference speed to a lower value than 0.95 of the one
    }                                //allowed by DC BUS this allows stable operation at MPPT in bound. cond.

    if (Speed_Ref_PM >= Corres_Speed){
        Speed_Ref_PM = Corres_Speed;
        FLAG_CORRES_SPEED_PMSM = 1;
    }
    else
        FLAG_CORRES_SPEED_PMSM = 0;

    //***********************************************************************************************************

    if (Speed_Ref_PM > SPEED_REF_PM_LIMT){ // 2PI()*rated_freq
        Speed_Ref_PM = SPEED_REF_PM_LIMT;
    }


    //*************************I_UVW_to_alphaBeta****************************************
    I_Alpha_PM = ThreebyTwo * I_INV_U_MAF; //*(p2)
    I_Beta_PM  = RootThreebyTwo * (- (2*I_INV_V_MAF) - I_INV_U_MAF); //*(p2+1)
    //*********************************************************************************
    //    kx = sqrt((I_Alpha_PM*I_Alpha_PM)+(I_Beta_PM*I_Beta_PM));  //peak debug purpose
    //Calculating V_Alpha and V_Beta from VINV_RY and VINV_YB by following standard
    // three to two phase transformation
    //*************************V_UVW_to_alphaBeta****************************************
    V_Alpha_PM = VINV_UV_MAF - VINV_WU_MAF;
    V_Alpha_PM = 0.5 * V_Alpha_PM;
    V_Beta_PM  = -RootThreebyTwo * VINV_VW_MAF;
    //*********************************************************************************
    //    ky = sqrt((V_Alpha_PM*V_Alpha_PM)+(V_Beta_PM*V_Beta_PM)); //peak
    // Q1 = (V_Alpha_PM*I_Beta_PM)-(V_Beta_PM*I_Alpha_PM); // Reactive Power
    //P1 = (V_Alpha_PM*I_Alpha_PM)+(V_Beta_PM*I_Beta_PM);  // Active Power
    //Theta_xx = Get_Theta_PM();
    //p2 = Calculate_Sinusoid(Theta_xx);
    //SIN_THETA_PM_1       = *(p2);

    //    DAC = ((0.0015*V_Alpha_PM)+0.5) * DAC_Var;

    //*******************************************Calculate_SAI_Alpha_s_n_SAI_Beta_s_PM***********************************
    // No_of_Pole_Pair_PM = RATED_POLE_PM  * 0.5;
    if(Speed_Ref_PM1 < (120.0)){
        Wc_SAI_PM = 20;                                                 //flux estimation cutoff freq
    }
    else{
        //Speed_Ref_PM1 = Trial_W_start;
        Wc_SAI_PM  = Speed_Ref_PM1;
    }
    if(Speed_Ref_PM1 > (450 * No_of_Pole_Pair_PM)){
        Wc_SAI_PM = (450 * No_of_Pole_Pair_PM);
    }

    LPF_SAI_PM_C1       = Ts/(1+(Wc_SAI_PM*Ts)); //  0.0000995025    //Ts/(1+Wc*Ts)
    LPF_SAI_PM_C2       = 1/(1+(Wc_SAI_PM*Ts));    //1/(1+Wc*Ts)
    LPF_SAI_THETA_PM_C1 = Ts/(1+(Wc_SAI_PM*Ts)); //  0.0000995025    //Ts/(1+Wc*Ts)
    LPF_SAI_THETA_PM_C2 = 1/(1+(Wc_SAI_PM*Ts));    //1/(1+Wc*Ts)


    V_Alpha_E_PM              = V_Alpha_PM - I_Alpha_PM * Rs_PM;

    SAI_Alpha_s_Theta_PM      = V_Alpha_E_PM * LPF_SAI_THETA_PM_C1 + SAI_Alpha_s_Theta_Prev_PM * LPF_SAI_THETA_PM_C2;// *(p2+2);
    SAI_Alpha_s_Theta_Prev_PM = SAI_Alpha_s_Theta_PM;

    SAI_Alpha_s_PM            = V_Alpha_E_PM * LPF_SAI_PM_C1 + SAI_Alpha_s_Prev_PM * LPF_SAI_PM_C2; // *(p2);
    SAI_Alpha_s_Prev_PM       = SAI_Alpha_s_PM;

    V_Beta_E_PM               = V_Beta_PM - I_Beta_PM * Rs_PM;




    SAI_Beta_s_Theta_PM       = V_Beta_E_PM * LPF_SAI_THETA_PM_C1 + SAI_Beta_s_Theta_Prev_PM * LPF_SAI_THETA_PM_C2;// *(p2+3);
    SAI_Beta_s_Theta_Prev_PM  = SAI_Beta_s_Theta_PM;

    SAI_Beta_s_PM             = V_Beta_E_PM * LPF_SAI_PM_C1 + SAI_Beta_s_Prev_PM * LPF_SAI_PM_C2; // *(p2+1);
    SAI_Beta_s_Prev_PM        = SAI_Beta_s_PM;

    // V_res =sqrtf(SAI_Alpha_s_PM * SAI_Alpha_s_PM + SAI_Beta_s_Theta_PM * SAI_Beta_s_Theta_PM);

    /*SAI_Alpha_r_PM = SAI_Alpha_s_PM - Lq*I_Alpha_PM;
                                   SAI_Beta_r_PM = SAI_Beta_s_PM - Lq*I_Beta_PM;
                                   SAI_Alpha_r_Theta_PM = SAI_Alpha_s_Theta_PM-Lq*I_Alpha_PM;
                                   SAI_Beta_r_Theta_PM = SAI_Beta_s_Theta_PM - Lq*I_Beta_PM;*/

    //************************************************************************************************************

    SAI_Mag_PM = (SAI_Alpha_s_PM*SAI_Alpha_s_PM)+(SAI_Beta_s_PM*SAI_Beta_s_PM); //debug purpose
    flux_mag = sqrt(SAI_Mag_PM);

    if(SAI_Mag_PM > SAI_Mag_PM_Max) SAI_Mag_PM = SAI_Mag_PM_Max;
    if(SAI_Mag_PM < SAI_Mag_PM_Min) SAI_Mag_PM = SAI_Mag_PM_Min;

    W_est_PM = (SAI_Alpha_s_PM * V_Beta_E_PM - SAI_Beta_s_PM * V_Alpha_E_PM);
    W_est_PM = W_est_PM / (SAI_Mag_PM * No_of_Pole_Pair_PM);

    //W_est_PM = W_est_PM*2;
    //W_est_PM_LPF =  Estimated_Speed_LPF_PM1(W_est_PM);

    //************************************************************************************************************************************

    W_est_PM_1[Avgi] = W_est_PM;
    W_est_PM_MAF  = W_est_PM_1[0]+W_est_PM_1[1]+W_est_PM_1[2]+W_est_PM_1[3]; //+W_est_PM_1[4];
    W_est_PM_MAF  = W_est_PM_MAF * 0.25;
    //********************************************************Estimated_Speed_LPF_PM1*******************************************************

    W_est_Prev_PM = W_est_PM_MAF * LPF_SPD_PM_C1 + W_est_Prev_PM * LPF_SPD_PM_C2;
    W_est_PM_LPF  = W_est_Prev_PM * Wc_SPD_PM;
    //W_est_PM_LPF  = W_est_Prev_PM;
    //************************************************************************************************************************************/

    W_est_Prev_PM1       = W_est_PM_LPF * LPF_SPD_PM_SLOWEST_C1 + W_est_Prev_PM1 * LPF_SPD_PM_SLOWEST_C2;
    W_est_PM_LPF_SLOWEST = W_est_Prev_PM1 * Wc_SPD_PM_SLOWEST;
    //W_est_PM_LPF_SLOWEST =  W_est_Prev_PM1;
    //*****************************************************Estimated_Speed_LPF_PM2*******************************************************

    if((W_est_PM_LPF > (47*No_of_Pole_Pair_PM) ||(SysTime_Minute_Count_IntervalElapsed(exit_count_SS, 0.2))) && SysTime_Minute_Count_IntervalElapsed(Timer_Flag_start, 0.06) && MPPT_START_FLAG == 0){
        // This 47*No_of_Pole_Pair is written due to speed ref being set to Speed_Ref_PM =  50*No_of_Pole_Pair in start sequence
        exit_count_SS = Minute_Count;
        MPPT_START_FLAG =1;
        if (flag_VFD_MPP_Initial == true) {
            MPPT_VDC_REF = VDC_BUS_LPF_50;
        }
        else {
            MPPT_VDC_REF = fminf(VDC_BUS_LPF_50,  VOC_START_VFD) ;
        }
        P_PV_Avg_DELAY_TIMER = Minute_Count;
        SOFT_START_FLAG = 0;
        //CLEAR_SCREEN_FLAG = true;
    }

    //******************************************************************//
    // Below code is only for displaying the speed and freq at slower rate
    COUNT_DISPLAY_SPD_FREQ++;
    if(COUNT_DISPLAY_SPD_FREQ > 30000){
        COUNT_DISPLAY_SPD_FREQ =0;
        //        SPEED_RPM_DISPLAY_PMSM = W_est_PM_LPF_SLOWEST * 9.54; // 30/PI
        DRY_RUN_RPM_PMSM = W_est_PM_LPF * 9.54; //30/pi
        FREQ_HZ_DISPLAY_PMSM = W_est_PM_LPF_SLOWEST * 9.54*0.01667*No_of_Pole_Pair_PM; // 120f/P
    }

    //***********************************************************************************************************

    Speed_FB_PM = No_of_Pole_Pair_PM * W_est_PM_LPF;

    //**********************************************LPF_Speed_Ref_PM*********************************************

    //Speed_Ref_PM1 = LPF_Speed_Ref_PM(Speed_Ref_PM);
    //float LPF_Speed_Ref_PM(float Speed_Ref){

    SPEED_LPF_Cutoff =  1.00;                           // cut off frequency
    if(Speed_Ref_PM > (37.5*No_of_Pole_Pair_PM)){//190
        SPEED_LPF_Cutoff = 200.00;
    }
    LPF_Const_SPDREF1 = Ts/(1+(SPEED_LPF_Cutoff*Ts)); //  0.0000995025    //Ts/(1+Wc*Ts)
    LPF_Const_SPDREF2 = 1/(1+(SPEED_LPF_Cutoff*Ts));    //1/(1+Wc*Ts)

    /*temp1 = P_PV_Avg*LPF_Const_Slowest1;
                                       temp2 = P_PV_Slowest_Prev*LPF_Const_Slowest2;
                                       temp = temp1+temp2;
                                       P_PV_Slowest_Prev = temp;
                                       temp = temp * LPF_Cutoff_Freq_Slowest;
     */
    Speed_Ref_PM_Prev = Speed_Ref_PM * LPF_Const_SPDREF1 + Speed_Ref_PM_Prev * LPF_Const_SPDREF2;
    Speed_Ref_PM1     = Speed_Ref_PM_Prev * SPEED_LPF_Cutoff;
    //Speed_Ref_PM1 = Speed_Ref_PM_Prev;

    //***********************************************************************************************************
    speed_info = Speed_Ref_PM;
    //Speed_Error_PM = Speed_Ref_PM2 - Speed_FB_PM;

    //********************************LPF_Speed_Ref_PM_Corr (Speed_Ref_PM3)***************************************//

    Speed_Ref_PM_Corr_Prev = Speed_Ref_PM * LPF_Const_Slowest7 + Speed_Ref_PM_Corr_Prev * LPF_Const_Slowest8;
    Speed_Ref_PM3          = Speed_Ref_PM_Corr_Prev * LPF_Cutoff_Freq_Slowest3;

    //*******************************************SpeedErrorPI_PM**************************************************//
    //Speed_Ref_PM = Speed_Ref_PM_debug;
    Speed_Error_PM = Speed_Ref_PM3 - Speed_FB_PM;  // SPEED ERROR ESTIMATION

    DAC = (Speed_FB_PM) * DAC_Var;

    /*if(Speed_Error_PM > Speed_Error_PM_Max)  Speed_Error_PM =  Speed_Error_PM_Max;   // Adding satuartion on speed error
               if(Speed_Error_PM < -Speed_Error_PM_Max) Speed_Error_PM = -Speed_Error_PM_Max;*/

    if(PM_flag_start == 1){  // This is to take care of of starting saturation of I_q while start sequence is running
        /*if(Counter_PM < 30000)
                               Speed_ErrorPI_PM_Ki_1 = 0.015;  //0.003
                           else
                               Speed_ErrorPI_PM_Ki_1 = Speed_ErrorPI_PM_Ki*5;
                           pi_output1 = 2;*/
        if(FLAG_PARK == false && Counter_PM>=(Counter_PM_Freq_Inc+100000)){
            pi_out_merge = pi_out_merge;  //No merge
        }
        Speed_Ref_PM_Corr_Prev = W_start*0.01;
    }
    else{
        Speed_Error_PM_PI_Ki_1 =  SPEED_KI_PM*5;
    }

    errorintokp = SPEED_KP_PM  * Speed_Error_PM;
    errorintoki = Speed_Error_PM_PI_Ki_1 * Speed_Error_PM * Ts;

    Speed_Error_Integ_PM = errorintoki + Last_Speed_I_Output_PM;

    // Adding saturation on Integration
    if(Speed_Error_Integ_PM > TORQUE_LIMIT_PM)  Speed_Error_Integ_PM =  TORQUE_LIMIT_PM;
    if(Speed_Error_Integ_PM < -TORQUE_LIMIT_PM) Speed_Error_Integ_PM = -TORQUE_LIMIT_PM;

    Last_Speed_I_Output_PM = Speed_Error_Integ_PM;

    if (PM_flag_start == 1){
        Torque_Ref_PM  = pi_out_merge;
        Last_Speed_I_Output_PM = Istop_PM;
    }
    else
        Torque_Ref_PM = Speed_Error_Integ_PM + errorintokp + pi_output1;


    // Adding saturation on Torque_Ref_PM
    if(Torque_Ref_PM > TORQUE_LIMIT_PM)  Torque_Ref_PM =  TORQUE_LIMIT_PM;
    if(Torque_Ref_PM < -TORQUE_LIMIT_PM) Torque_Ref_PM = -TORQUE_LIMIT_PM;

    //***********************************************Getting Iq_Ref and Id_Ref***********************************************************//

    Iq_Ref_PM = Torque_Ref_PM;
    //        DAC  = (5+Iq_Ref_PM) * 300;
    if(Iq_Ref_PM > (MAX_OUTPUT_CURRENT*1.414) /*|| (V_RMS_DISPLAY > (0.97*0.707*VDC_BUS_Avg))*/){ //(MOTOR_POWER * 1200) /MOTOR_VOLTAGE_PM; // 900*sqrt(2)bysqrt(3);
        SPEED_STOP_INCREASE = true;
    }
    else if (Iq_Ref_PM < 0.95*(MAX_OUTPUT_CURRENT*1.414) /*&& (V_RMS_DISPLAY < (0.94*0.707*VDC_BUS_Avg))*/){
        SPEED_STOP_INCREASE = false;
    }
    if(trial==0){
        Iq_Ref_PM  = debug_Iq_Ref_PM;
    }
    //Id_Ref_PM  = 0;  // 2 for low power surface motor
    // }
}
void Vector_Control_PMSM(void){
    Uint16 duty1=0, duty3=0, duty5=0;
    float errorintoki =0, errorintokp = 0;
    if(ON_OFF_FLAG == true){
        if (FLAG_PARK == true && FLAG_PARK_EEPROM == true){
            /*****************PMSM_Parking()**********************/
            //IRATED_Park = 0.3 * MAX_CURRENT;
            IRATED_Park = IRATED_Park + Istart_PM_Delta;
            if(Istart_PM < IRATED_Park_limit){
                if (IRATED_Park > Istart_PM){
                    IRATED_Park = Istart_PM;
                }
            }
            else{
                if (IRATED_Park > IRATED_Park_limit){
                    IRATED_Park = IRATED_Park_limit;
                }
            }

            if (SPEED_FORWARD) {
                Park_IR_ref =    1.0 * IRATED_Park;
                Park_IY_ref =   -0.5 * IRATED_Park;
                Park_IB_ref =   -0.5 * IRATED_Park;
            }

            if (!SPEED_FORWARD) {
                Park_IR_ref =  -0.5 * IRATED_Park;
                Park_IY_ref =   1.0 * IRATED_Park;
                Park_IB_ref =  -0.5 * IRATED_Park;
            }

            Park_IR_delta = Park_IR_ref - I_INV_R_MAF;
            Park_IY_delta = Park_IY_ref - I_INV_Y_MAF;
            Park_IB_delta = Park_IB_ref - I_INV_B_MAF;

            mdqgain_Park =  2/VDC_BUS_LPF_50;

            //***************************Park_PI_IRController****************************
            Park_IR_KP = Park_IR_delta * KP_ICNTRL_Park;
            Park_IR_KI = Park_IR_delta * KI_ICNTRL_Park;
            Park_IR_KI = Park_IR_KI * Ts;
            Park_IR_KI = Park_IR_KI + Park_IR_KI_Prev;

            if(Park_IR_KI> Park_KI_MAX){
                Park_IR_KI = Park_KI_MAX;
            }
            else if(Park_IR_KI < Park_KI_MIN){
                Park_IR_KI = Park_KI_MIN;
            }

            Park_IR_KI_Prev = Park_IR_KI;

            Park_IR_PI = Park_IR_KP + Park_IR_KI;

            if(Park_IR_PI> Park_PI_MAX){
                Park_IR_PI = Park_PI_MAX;
            }
            else if(Park_IR_PI < Park_PI_MIN){
                Park_IR_PI = Park_PI_MIN;
            }

            VR_Ref_Park = (-mdqgain_Park) * Park_IR_PI;

            //***************************Park_PI_IYController****************************
            Park_IY_KP = Park_IY_delta * KP_ICNTRL_Park;

            Park_IY_KI = Park_IY_delta * KI_ICNTRL_Park;
            Park_IY_KI = Park_IY_KI * Ts;
            Park_IY_KI = Park_IY_KI + Park_IY_KI_Prev;

            if(Park_IY_KI> Park_KI_MAX){
                Park_IY_KI = Park_KI_MAX;
            }
            else if(Park_IY_KI < Park_KI_MIN){
                Park_IY_KI = Park_KI_MIN;
            }

            Park_IY_KI_Prev = Park_IY_KI;

            Park_IY_PI = Park_IY_KP + Park_IY_KI;

            if(Park_IY_PI> Park_PI_MAX){
                Park_IY_PI = Park_PI_MAX;
            }
            else if(Park_IY_PI < Park_PI_MIN){
                Park_IY_PI = Park_PI_MIN;
            }

            VY_Ref_Park = (-mdqgain_Park) * Park_IY_PI;

            //***************************Park_PI_IBController****************************
            Park_IB_KP = Park_IB_delta * KP_ICNTRL_Park;

            Park_IB_KI = Park_IB_delta * KI_ICNTRL_Park;
            Park_IB_KI = Park_IB_KI * Ts;
            Park_IB_KI = Park_IB_KI + Park_IB_KI_Prev;

            if(Park_IB_KI> Park_KI_MAX){
                Park_IB_KI = Park_KI_MAX;
            }
            else if(Park_IB_KI < Park_KI_MIN){
                Park_IB_KI = Park_KI_MIN;
            }

            Park_IB_KI_Prev = Park_IB_KI;

            Park_IB_PI = Park_IB_KP + Park_IB_KI;

            if(Park_IB_PI> Park_PI_MAX){
                Park_IB_PI = Park_PI_MAX;
            }
            else if(Park_IB_PI < Park_PI_MIN){
                Park_IB_PI = Park_PI_MIN;
            }

            VB_Ref_Park = (-mdqgain_Park) * Park_IB_PI;


            if (SPEED_FORWARD) {
                duty1=floor(INVERTER_PERIOD * (0.5*VR_Ref_Park+0.5));
                duty3=floor(INVERTER_PERIOD * (0.5*VY_Ref_Park+0.5));
                duty5=floor(INVERTER_PERIOD * (0.5*VB_Ref_Park+0.5));
            }

            if (!SPEED_FORWARD){
                duty3=floor(INVERTER_PERIOD * (0.5*VR_Ref_Park+0.5));
                duty1=floor(INVERTER_PERIOD * (0.5*VY_Ref_Park+0.5));
                duty5=floor(INVERTER_PERIOD * (0.5*VB_Ref_Park+0.5));
            }
            Counter_PM++;
            if (Counter_PM >=PARKING_COUNTER_THR)
                FLAG_PARK =  false;
        }


        if (FLAG_PARK == false || FLAG_PARK_EEPROM == false){

            Speed_Estimation_PMSM();  //Temp for tesing purpose
            //********************************************Generate SIN_THETA_PM && COS_THETA_PM*************************************************
            Counter_PM++;  // This counter is required to take care starting
            /* if(Counter_PM > 1999999){  //This line is required only for running in open loop
            Counter_PM = 1999998;
        }
       Speed_Ref_PM_Min = PMSM_MIN_RPM * 0.10472* RATED_POLE_PM/2; //This line is required only for running in open loop*/


            Theta_PM = atan2f(SAI_Beta_s_Theta_PM, SAI_Alpha_s_Theta_PM);

            // Theta_PM_temp = atan2f(SAI_Beta_s_Theta_PM, SAI_Alpha_s_Theta_PM);



            //if (Theta_PM_temp < 0){
            //   Theta_PM_temp = Theta_PM_temp + PIinto2;
            //}



            if (Theta_PM < 0){
                Theta_PM = Theta_PM + PIinto2;
            }


            PMSM_THETA_FACTOR1 = PMSM_THETA_FACTOR - 1;
            PFC_THETA_CORRECTION1 = 1.19+0.0124*Speed_Ref_PM1-1.169;   //Using Voltage sensing RC Compensation, C=0.022 MFD
            PFC_THETA_CORRECTION1 = PFC_THETA_CORRECTION1*PI/180;      //Degree to radian
            PFC_THETA_CORRECTION = 0.785 + PMSM_THETA_FACTOR1*PFC_THETA_CORRECTION1;
            Theta_PM = Theta_PM + PIby2 -PFC_THETA_CORRECTION + PFC_CF;// It was observed that due to non ideal integration a phase lead of close to 45 (35 to 50) degree was observed in I_Alpha w.r.t V_alpha.
            // which has been corrected here by subtracting -0.65 manually, which is corresponding to 37.24 degree.
            //We need some reactive power support from VSC so we borrowed it from reduction in power factor. This was required to run motor from lower DC link voltage and full speed.

            if(Theta_PM > PIinto2){
                Theta_RESET_COUNT1++;
                //Theta_SF_COUNT = 0;
                Theta_PM = (Theta_PM-PIinto2);
                //Theta_RESET_COUNT1 = 3+Theta_RESET_COUNT1;
                //if (flag_start ==1){
                //Theta_RESET_COUNT++;
                //}

            }
            else if (Theta_PM < 1 && PM_flag_start == 1 && W_start >30){
                if(Theta_RESET_COUNT1 > 0){
                    Theta_RESET_COUNT++;
                    Theta_RESET_COUNT1 = 0;
                }

            }
            if(Theta_PM < (-PIinto2)){  //
                Theta_PM = (Theta_PM+PIinto2);
                //Theta_RESET_COUNT2 = 3+Theta_RESET_COUNT2;
                /*if (flag_start ==1 ){
                                           Theta_RESET_COUNT++;
                                       }*/
            }


            SAI_s_Theta_PM_Mag_corr = sqrt(SAI_Alpha_s_Theta_PM*SAI_Alpha_s_Theta_PM+SAI_Beta_s_Theta_PM*SAI_Beta_s_Theta_PM);
            SAI_Alpha_s_Theta_PM_corr =  SAI_s_Theta_PM_Mag_corr * sinf (Theta_PM);
            SAI_Beta_s_Theta_PM_corr  = -SAI_s_Theta_PM_Mag_corr * cosf (Theta_PM);
            Lmid = IMP_FACTOR * (Ld_PM + Lq_PM);
            SAI_Alpha_r_Theta_PM_corr = SAI_Alpha_s_Theta_PM_corr - Lmid * I_Alpha_PM;
            SAI_Beta_r_Theta_PM_corr  = SAI_Beta_s_Theta_PM_corr - Lmid * I_Beta_PM;

            Theta_PM = atan2f(SAI_Beta_r_Theta_PM_corr, SAI_Alpha_r_Theta_PM_corr);
            Theta_PM = Theta_PM + PIby2;

            if (Theta_PM < 0) Theta_PM = Theta_PM + PIinto2;
            if (Theta_PM > PIinto2) Theta_PM = Theta_PM - PIinto2;


            /****************************OPEN LOOP ALGORITHM START***************************/
            if(Counter_PM < OPEN_LOOP_COUNTER_PM){
                if(PM_flag_start == 1){
                    if(Counter_PM > HLD_ROTOR_COUNTER_PM  && Counter_PM < (Counter_PM_Freq_Inc + HLD_ROTOR_COUNTER_PM)){
                        W_start = W_start + (Ramp_Rate_PM * No_of_Pole_Pair_PM);
                    }
                    if (Counter_PM > (Counter_PM_Freq_Inc + HLD_ROTOR_COUNTER_PM)){
                        W_start = W_start;
                    }
                }
                if (W_start > Speed_Ref_PM_Min) W_start = Speed_Ref_PM_Min;
                // W_start =0;
                Trial_W_start = W_start;
                Theta_PM = W_start * Ts;
                Theta_PM = Theta_PM + Last_theta_PM;
                if(Theta_PM > PIinto2)  Theta_PM = (Theta_PM - PIinto2);
                if(Theta_PM < -PIinto2)  Theta_PM = (Theta_PM + PIinto2);
                Last_theta_PM = Theta_PM;
                Speed_Ref_PM =  Speed_Ref_PM_Min;
                diff_Theta_PM = debug_Theta_PM - Theta_PM;
                if (diff_Theta_PM < -PI) diff_Theta_PM = diff_Theta_PM + 2 * PI;

                if(Counter_PM > (Counter_PM_Freq_Inc + OPEN_LOOP_MER_COUNTER_PM))
                    Counter_PM = OPEN_LOOP_COUNTER_PM +1;

                Timer_Flag_start = Minute_Count;
            }
            else{
                PM_flag_start = 0;
                Counter_PM = OPEN_LOOP_COUNTER_PM+1;
                Theta_RESET_COUNT1 =0;
                if (SysTime_Minute_Count_IntervalElapsed(Timer_Flag_start, 0.05)){ /*&& Speed_Ref_PM < (150* No_of_Pole_Pair) && SOFT_STOP_FLAG==0*/

                    if(START_FAIL_PMSM_COUNT > 32000 && !START_FAIL_PMSM) {     // For 3 s time-window, total count is 48000. If IqrefPM > OVER_CURR_LIMIT,
                        START_FAIL_PMSM = true;                                 // for 95% of this time-window, start-fail fault is declared.
                    }
                    START_FAIL_PMSM_COUNT = 0;
                }

                else {
                    if((Iq_Ref_PM > OVER_CURR_LIMIT) || (Iq_Ref_PM<(-OVER_CURR_LIMIT))){    // Threshold for detecting Motor-Start Fail PM: 0.707 * 1.414 = 1.00
                        START_FAIL_PMSM_COUNT++;
                    }
                    Speed_Ref_PM =  Speed_Ref_PM_Min;
                }


                if (SysTime_Minute_Count_IntervalElapsed(Timer_Flag_start, Time_Blank_OC_Detection)){
                    OCTest_IZero_Threshold = threshold1;
                }
                else{
                    OCTest_IZero_Threshold = threshold2;
                }
            }
            //W_est_PM_SF = (temp - Last_theta_PM_SF) / T_s;

            /****************************OPEN LOOP ALGORITHM END***************************/
            if(Theta_PM> PIinto2) Theta_PM = (Theta_PM-PIinto2);
            if(Theta_PM<(-PIinto2))Theta_PM = (Theta_PM+PIinto2);

            //  DAC = ((Torque_Ref_PM+0.5)/12.5) * 1365;



            //Theta_PM = Theta_PM/(PIinto2);
            SIN_THETA_PM       = sinf(Theta_PM);  // this is done to save some computation time  //*(p2)
            COS_THETA_PM       = cosf(Theta_PM);  // *(p2+1)
            SIN_THETA_120_PM   = sinf(Theta_PM + 2.094395); // *(p2+2)
            COS_THETA_120_PM   = cosf(Theta_PM + 2.094395); // *(p2+3)

            //DAC = (1+SIN_THETA_PM) * DAC_Var;
            //******************************************Calculate_Id_n_Iq_PM**************************************************
            Id_Sensed_PM = 0.667*(I_INV_R * SIN_THETA_PM + I_INV_Y * SIN_THETA_120_PM + I_INV_B * (- SIN_THETA_PM - SIN_THETA_120_PM)); // *(p2)
            Iq_Sensed_PM = 0.667*(I_INV_R * COS_THETA_PM + I_INV_Y * COS_THETA_120_PM + I_INV_B * (- COS_THETA_PM - COS_THETA_120_PM)); // *(p2+1)
            //*****************************************************************************************************************

            //Id_Sensed_PM = Id_Sensed_PM_debug;
            //Iq_Sensed_PM = Iq_Sensed_PM_debug;
            Current_Error_Id_PM = ID_REF_PM - Id_Sensed_PM;
            Current_Error_Iq_PM = Iq_Ref_PM - Iq_Sensed_PM;

            //*********************************************CurrentError_Id_PM_PI***********************************************************

            if(Current_Error_Id_PM > CURR_ERROR_LIMIT_PM)  Current_Error_Id_PM =  CURR_ERROR_LIMIT_PM;
            if(Current_Error_Id_PM < -CURR_ERROR_LIMIT_PM) Current_Error_Id_PM = -CURR_ERROR_LIMIT_PM;

            //Current_Error_Id_PM_Kp = CURRENT_KP_PM;//TOL_I;
            // Current_Error_Id_PM_Ki = CURRENT_KI_PM * 5; TOL_V * 5;                //Factor of 3 for 100 us ISR and Tsvector has been made equal to ISR time

            errorintokp = CURRENT_KP_PM * Current_Error_Id_PM;
            errorintoki = CURRENT_KI_PM * Current_Error_Id_PM * Ts;

            Current_Error_Id_PM_Integ = errorintoki + Last_Current_Id_PM_Output;

            // Adding saturation on Integration
            if(Current_Error_Id_PM_Integ > VOLT_OUTPUT_LIMIT_PM)  Current_Error_Id_PM_Integ =  VOLT_OUTPUT_LIMIT_PM;
            if(Current_Error_Id_PM_Integ < -VOLT_OUTPUT_LIMIT_PM) Current_Error_Id_PM_Integ = -VOLT_OUTPUT_LIMIT_PM;

            Last_Current_Id_PM_Output = Current_Error_Id_PM_Integ;

            Vd_Ref_PM  = Current_Error_Id_PM_Integ + errorintokp;

            // Adding saturation on Vd_Ref_PM
            if(Vd_Ref_PM >  VOLT_OUTPUT_LIMIT_PM) Vd_Ref_PM =  VOLT_OUTPUT_LIMIT_PM;
            if(Vd_Ref_PM < -VOLT_OUTPUT_LIMIT_PM) Vd_Ref_PM = -VOLT_OUTPUT_LIMIT_PM;



            //**********************************************CurrentError_Iq_PM_PI***********************************************************

            if(Current_Error_Iq_PM > CURR_ERROR_LIMIT_PM) Current_Error_Iq_PM  =  CURR_ERROR_LIMIT_PM;
            if(Current_Error_Iq_PM < -CURR_ERROR_LIMIT_PM) Current_Error_Iq_PM = -CURR_ERROR_LIMIT_PM;

            //Current_Error_Iq_PM_Kp = TOL_I;
            //Current_Error_Iq_PM_Ki = TOL_V * 5;

            errorintokp = CURRENT_KP_PM * Current_Error_Iq_PM;
            errorintoki = CURRENT_KI_PM * Current_Error_Iq_PM * Ts;

            Current_Error_Iq_PM_Integ = errorintoki + Last_Current_Iq_PM_Output;

            // Adding saturation on Integration
            if(Current_Error_Iq_PM_Integ > VOLT_OUTPUT_LIMIT_PM)  Current_Error_Iq_PM_Integ =  VOLT_OUTPUT_LIMIT_PM;
            if(Current_Error_Iq_PM_Integ < -VOLT_OUTPUT_LIMIT_PM) Current_Error_Iq_PM_Integ = -VOLT_OUTPUT_LIMIT_PM;


            Last_Current_Iq_PM_Output = Current_Error_Iq_PM_Integ;

            Vq_Ref_PM  = Current_Error_Iq_PM_Integ + errorintokp;

            // Adding saturation on Vq_Ref_PM
            if(Vq_Ref_PM >  VOLT_OUTPUT_LIMIT_PM) Vq_Ref_PM =  VOLT_OUTPUT_LIMIT_PM;
            if(Vq_Ref_PM < -VOLT_OUTPUT_LIMIT_PM) Vq_Ref_PM = -VOLT_OUTPUT_LIMIT_PM;

            //*****************************************************************************************************************

            //debug_Vd_Ref_PM = Vd_Ref_PM;
            //debug_Vq_Ref_PM = Vq_Ref_PM;

            D_Flux_Linkage = Id_Sensed_PM * Ld_PM;
            Q_Flux_Linkage = Iq_Sensed_PM * Lq_PM;
            //Rotor_Flux = 0.003184*MOTOR_VOLTAGE_PM;
            Rotor_Flux = 0.81*(No_of_Pole_Pair_PM*RATED_VOLT_PM)/(PIinto2*RATED_FREQ_PM);
            Total_Flux = Rotor_Flux + D_Flux_Linkage;

            if(PM_flag_start ==1){
                Q_Feed_FWD = Total_Flux * W_start/No_of_Pole_Pair_PM ;
                D_Feed_FWD = Q_Flux_Linkage * W_start/No_of_Pole_Pair_PM;
            }
            else{
                Q_Feed_FWD = Total_Flux * Speed_FB_PM/No_of_Pole_Pair_PM;
                D_Feed_FWD = Q_Flux_Linkage * Speed_FB_PM/No_of_Pole_Pair_PM;
            }

            // D_Feed_FWD = 0; // disable Feed Fw
            //  Q_Feed_FWD = 0;
            Vd_Ref_PM = Vd_Ref_PM - D_Feed_FWD;
            Vq_Ref_PM = Vq_Ref_PM + Q_Feed_FWD;

            //  DAC = ((Vq_Ref_PM)/430) * 2730;


            Vd_Ref_PM = (Vd_Ref_PM * -MOD_GAIN_PM);  // Here Perunitisation for m is done by multiplying  2/VDC i.e 400
            Vq_Ref_PM = (Vq_Ref_PM * -MOD_GAIN_PM);

            // DAC = (Theta_PM) * DAC_Var;
            // Vd_Ref_PM = Vd_Ref_PM * DC_link_PU;  // Here Perunitisation for m is done by multiplying  2/VDC i.e 400
            // Vq_Ref_PM = Vq_Ref_PM * DC_link_PU;
            //Vd_Ref_PM = 0.05;
            //Vq_Ref_PM = 0.05;

            //*******************************************Calculate_Reference_Qty_RYB_PM*****************************************
            //IR_Ref_PM =   Id_Ref_PM * SIN_THETA_PM + Iq_Ref_PM * COS_THETA_PM;  // *(p2);
            // IY_Ref_PM =   Id_Ref_PM * SIN_THETA_120_PM + Iq_Ref_PM * COS_THETA_120_PM;  // *(p2);
            //DAC = (IY_Ref_PM+12) * 15;

            VR_Ref_PM =   Vd_Ref_PM * SIN_THETA_PM + Vq_Ref_PM * COS_THETA_PM;  // *(p2);
            VY_Ref_PM =   Vd_Ref_PM * SIN_THETA_120_PM + Vq_Ref_PM * COS_THETA_120_PM;  // *(p2+1);
            VB_Ref_PM = - VR_Ref_PM - VY_Ref_PM; //  *(p2+2);
            //  VR_Ref_PM - SIN_THETA_PM
            // DAC = ( VR_Ref_PM*SIN_THETA_PM+1) * DAC_Var;
            //******************************************************************************************************************


            Max_PM = fmaxf(VR_Ref_PM, VY_Ref_PM);
            Max_PM = fmaxf(Max_PM,VB_Ref_PM);

            Min_PM = fminf(VR_Ref_PM, VY_Ref_PM);
            Min_PM = fminf(Min_PM,VB_Ref_PM);

            Mid_PM = -(Max_PM+Min_PM)*0.5;

            //CSVPWM implementation
            VR_Ref_PM1 = 1.154*(VR_Ref_PM)+Mid_PM;
            VY_Ref_PM1 = 1.154*(VY_Ref_PM)+Mid_PM;
            VB_Ref_PM1 = 1.154*(VB_Ref_PM)+Mid_PM;

            if(SPEED_FORWARD){
                VR_Ref_PM1 = 1.154*(VR_Ref_PM)+Mid_PM;
                VY_Ref_PM1 = 1.154*(VY_Ref_PM)+Mid_PM;
                VB_Ref_PM1 = 1.154*(VB_Ref_PM)+Mid_PM;
            }
            else if(!SPEED_FORWARD){
                VR_Ref_PM1 = 1.154*(VY_Ref_PM)+Mid_PM;
                VY_Ref_PM1 = 1.154*(VR_Ref_PM)+Mid_PM;
                VB_Ref_PM1 = 1.154*(VB_Ref_PM)+Mid_PM;
            }

            //    if (SPEED_DIRECTION_SELECT == 2 ){
            //        //CSVPWM implementation
            //        VY_Ref_PM1 = 1.154*(VR_Ref_PM)+Mid_PM;
            //        VR_Ref_PM1 = 1.154*(VY_Ref_PM)+Mid_PM;
            //        VB_Ref_PM1 = 1.154*(VB_Ref_PM)+Mid_PM;
            //    }


            //***********************************************Hysteresis Control START *************************************

            /*IR_Ref_PM =   Id_Ref_PM * SIN_THETA_PM + Iq_Ref_PM * COS_THETA_PM;  // *(p2);
        IY_Ref_PM   =   Id_Ref_PM * SIN_THETA_120_PM + Iq_Ref_PM * COS_THETA_120_PM;  // *(p2+1)
        IB_Ref_PM   = - IR_Ref_PM - IY_Ref_PM;  // *(p2+2);

        Curr_ErrorR_PM = IR_Ref_PM - I_INV_R;
        Curr_ErrorY_PM = IY_Ref_PM - I_INV_Y;
        Curr_ErrorB_PM = -Curr_ErrorR_PM - Curr_ErrorY_PM;

        if(Curr_ErrorR_PM < Hys) duty1_PM = 2500;
        if(Curr_ErrorR_PM >-Hys) duty1_PM = 0;

        if(Curr_ErrorY_PM < Hys) duty3_PM = 2500;
        if(Curr_ErrorY_PM >-Hys) duty3_PM = 0;

        if(Curr_ErrorB_PM < Hys) duty5_PM = 2500;
        if(Curr_ErrorB_PM >-Hys) duty5_PM = 0;

        //debug_Peak = IR_Ref*IR_Ref+IY_Ref*IY_Ref+IB_Ref*IB_Ref;
        //debug_Peak = debug_Peak*0.667;
        //debug_Peak = sqrt(debug_Peak);
        EPwm7Regs.CMPA.bit.CMPA = duty1_PM;
        EPwm7Regs.CMPB.bit.CMPB = duty1_PM;

        EPwm8Regs.CMPA.bit.CMPA = duty3_PM;
        EPwm8Regs.CMPB.bit.CMPB = duty3_PM;

        EPwm6Regs.CMPA.bit.CMPA = duty5_PM;
        EPwm6Regs.CMPB.bit.CMPB = duty5_PM;*/
            //********************************************Hysteresis Control END  *************************************
            duty1 = floorf(INVERTER_PERIOD*((0.5*VR_Ref_PM1)+0.5));
            duty3 = floorf(INVERTER_PERIOD*((0.5*VY_Ref_PM1)+0.5));
            duty5 = floorf(INVERTER_PERIOD*((0.5*VB_Ref_PM1)+0.5));
        }
        // DAC = ((0.5*VR_Ref_PM1)+0.5) * DAC_Var;

        EPwm5Regs.CMPA.bit.CMPA = duty1;   //R
        EPwm5Regs.CMPB.bit.CMPB = duty1;

        EPwm6Regs.CMPA.bit.CMPA = duty3;   //Y
        EPwm6Regs.CMPB.bit.CMPB = duty3;

        EPwm7Regs.CMPA.bit.CMPA = duty5;   //B
        EPwm7Regs.CMPB.bit.CMPB = duty5;

        if(ALL_PWM_LOW == true && PWM_Release_Flag == 10){
            //Relesase pluses
            TZ_CLR_PWM();
            GpioDataRegs.GPHCLEAR.bit.GPIO228     = 1;
        }

        PWM_Release_Flag++;
        if(PWM_Release_Flag > 10){
            PWM_Release_Flag = 10;
        }

    }

    else if(ON_OFF_FLAG == false){

        TZ_FRC_PWM_low();
        GpioDataRegs.GPHSET.bit.GPIO228     = 1;
        PWM_Release_Flag  = false;

        EPwm5Regs.CMPA.bit.CMPA = 0;   //R
        EPwm5Regs.CMPB.bit.CMPB = 0;

        EPwm6Regs.CMPA.bit.CMPA = 0;   //Y
        EPwm6Regs.CMPB.bit.CMPB = 0;

        EPwm7Regs.CMPA.bit.CMPA = 0;   //B
        EPwm7Regs.CMPB.bit.CMPB = 0;

        Speed_Ref_PM_Min = PMSM_MIN_RPM * 0.10472* RATED_POLE_PM/2;
        Speed_Ref_PM = Speed_Ref_PM_Min;
        No_of_Pole_Pair_PM = RATED_POLE_PM * 0.5;
        // Speed_Ref_PM = 40*No_of_Pole_Pair_PM;
        //DRY_RUN_RPM_PMSM = 0;
        //SPEED_REF_INPUT_DISPLAY = 500;
        //    Speed_Ref_PM_Disp_Prev = Speed_Ref_PM_Min;

        Speed_Ref_PM_Prev=0; // for Speed LPF
        Speed_Ref_PM_Corr_Prev = 0;
        Speed_Ref_PM1 =0;
        Speed_Ref_PM3 =0;
        W_est_Prev_PM1 = 0;  // for displaying Speed in RPM
        SAI_Alpha_s_Theta_Prev_PM=0;
        SAI_Beta_s_Theta_Prev_PM=0;
        SAI_Alpha_s_Prev_PM=0;
        SAI_Beta_s_Prev_PM=0;
        Torque_Ref_PM = 0;
        Iq_Ref_PM =0;
        W_est_PM=0;
        W_est_Prev_PM=0;
        W_est_Prev_PM1=0;
        W_est_PM_LPF = 0;
        Speed_FB_PM =0;
        PM_flag_start = 1;
        Speed_Error_Integ_PM=0;
        Speed_Error_Integ_sat=0;
        Last_Speed_I_Output_PM=0;
        MPPT_START_FLAG = 0;
        SAI_Alpha_s_PM =  0;
        SAI_Beta_s_PM = 0;
        SAI_Alpha_s_Theta_PM = 0;
        SAI_Beta_s_Theta_PM  = 0;

        Counter_PM=0;
        W_start = 10;
        Last_theta_PM=0;
        Current_Error_Id_PM_Integ   =0;
        Current_Error_Iq_PM_Integ  = 0;
        Last_Current_Id_PM_Output  = 0;
        Last_Current_Iq_PM_Output  = 0;


        //    SPEED_RPM_DISPLAY_PMSM     = 0;
        //    FREQ_HZ_DISPLAY_PMSM       = 0;
        //
        PFC_THETA_CORRECTION       = 0.78;
        Theta_RESET_COUNT1         = 0;
        Theta_RESET_COUNT          = 0;
        //Theta_SF_COUNT           = 0;
        //Theta_SF_COUNT1          = 0;
        START_FAIL_PMSM_COUNT      = 0;
        //Time_Blank_OC_Detection    = MPPT_CALL_RATE * 0.003;

        Park_IR_KI_Prev            = 0;
        Park_IR_KI                 = 0;
        Park_IR_PI                 = 0;
        Park_IY_KI_Prev            = 0;
        Park_IY_KI                 = 0;
        Park_IY_PI                 = 0;
        Park_IB_KI_Prev            = 0;
        Park_IB_KI                 = 0;
        Park_IB_PI                 = 0;

        //Istart_PM_Max                   = 25;
        //ISTART_PM_FACTOR                = 226.24;
        MOD_GAIN_PM                     = 1/VOLT_OUTPUT_LIMIT_PM;                  // VOLT_OUTPUT_LIMIT_PM;//0.0024;       //need to check with simha_1.0
        //INIT_VOLTPERCENT_FACTOR         = 0.03;
        Istart_PM = INIT_VOLTPERCENT_FACTOR * ISTART_PM_FACTOR; //226.24; //16*14.14 = 226.24
        Istop_PM = 0.6667* INIT_VOLTPERCENT_FACTOR * ISTART_PM_FACTOR;//226.24 ; //16*14.14 = 226.24

        if (Istart_PM > ISTART_PM_LIMIT) Istart_PM = ISTART_PM_LIMIT;
        IRATED_Park_limit = ISTART_PM_LIMIT*0.7;
        if(Istart_PM < IRATED_Park_limit){
            Istart_PM_Delta = Istart_PM/PM_RAMP_STEP_COUNTER;
        }
        else{
            Istart_PM_Delta = IRATED_Park_limit/PM_RAMP_STEP_COUNTER;
        }
        //SPEED_MODE_SELECT          = 3;
        // SPEED_RPM_REF_UI           = 500;
        INIT_RAMP_TIME_PMSM1       = INIT_RAMP_TIME_PMSM;
        if(PUMP_TYPE==2){
            if (Istart_PM < (OVER_CURR_LIMIT * 0.91)) Istart_PM = (OVER_CURR_LIMIT * 0.91); //65% of rated current peak
            if (Istop_PM < (OVER_CURR_LIMIT * 0.74)) Istop_PM = (OVER_CURR_LIMIT * 0.74);
            if (INIT_RAMP_TIME_PMSM1 < 12) INIT_RAMP_TIME_PMSM1 = 12;
        }
        if (Istop_PM > ISTART_PM_LIMIT) Istop_PM = ISTART_PM_LIMIT;
        pi_out_merge = Istart_PM;
        Counter_PM_Freq_Inc = floorf(INIT_RAMP_TIME_PMSM1/Ts);
        Ramp_Rate_PM = (Speed_Ref_PM_Min-W_start)/(Counter_PM_Freq_Inc * RATED_POLE_PM/2);
        IRATED_Park = 0;
        if(FLAG_PARK_EEPROM == true){
            FLAG_PARK =  true;
        }
        else{
            FLAG_PARK =  false;
        }
        KP_ICNTRL_Park = CURRENT_KP_PM;
        KI_ICNTRL_Park = CURRENT_KI_PM;

        //RATED_FREQ = MOTOR_RATED_FREQ_PMSM;
        FLAG_OPEN_PM =false;
        FLAG_FREQ_CORRES = false;
        // FLAG_SPEED_REF = false;
        //        FLAG_MAX_POW = false;
        //        FLAG_MAX_CURR = false;
        //        FLAG_RATED_FREQ = false;
        //        FLAG_MAX_FREQ = false;
        //
        //    if(APP_MODE == 0){
        //        if(MPPT_CALL_RATE_LOCAL < 500)   MPPT_CALL_RATE_LOCAL = 500;
        //    }
        SPEED_LIMIT_MAX_FREQ_SET   = PIinto2 * MAX_FREQ_SET_PM;
        SPEED_LIMIT_RATED_FREQ_SET = PIinto2 * RATED_FREQ_PM;
        FREQ_LIMIT_PM              = fminf(RATED_FREQ_PM,MAX_FREQ_SET_PM);
        SPEED_REF_PM_LIMT          = PIinto2 * FREQ_LIMIT_PM;
        PARKING_COUNTER_THR        = (30000*COUNT_FACTOR);
        OPEN_LOOP_COUNTER_PM       = (2000000*COUNT_FACTOR);
        OPEN_LOOP_MER_COUNTER_PM   = (100000*COUNT_FACTOR);
        HLD_ROTOR_COUNTER_PM       = (70000*COUNT_FACTOR);
        PMSM_START_FAIL_THR        = (32000*COUNT_FACTOR);
        PM_RAMP_STEP_COUNTER       = (20000*COUNT_FACTOR);
        PM_RAMP_STEP_COUNTER       = (20000*COUNT_FACTOR);

    }
}

