/*
 * F&W_Manager.c
 *
 *  Created on: Jul 20, 2023
 *      Author: Dell
 */
#include <Headers/Project_Header/Init.h>


void Faults_and_Warnings_Manager(void){

    /**************************************FLT-0 ******************************************/
    /**************************************DC_BUS_OV_FLT******************************************/
    /*
     * This fault condition occurs immediately when the voltage across DC_BUS is higher than the
     * DC_BUS_OV_LIMIT set from the display. It gets reset after a minute when DC_BUS voltage falls
     * below DC_BUS_OV_LIMIT-60.
     */
    /********************************************************************************************/

    if(!(FAULT_CODE & DC_BUS_OV_FLT_BIT)&& OV_Enable){
        if(VDC_BUS_MAF > DC_BUS_OV_LIMIT){
            DC_BUS_OV_FLT               =  true;
            FAULT_CODE                 |= DC_BUS_OV_FLT_BIT;
            Timer_DCBUS_OV_Reset        = Minute_Count;
            EEPROM_Fault_Write_Enable   = true;
        }
    }
    else if(FAULT_CODE & DC_BUS_OV_FLT_BIT){
        if(SysTime_Minute_Count_IntervalElapsed(Timer_DCBUS_OV_Reset, 1)){
            if(VDC_BUS_MAF < (DC_BUS_OV_LIMIT- DC_BUS_OV_RESET_HYS)){
                DC_BUS_OV_FLT            = false;
                FAULT_CODE              &= DC_BUS_OV_FLT_CLR_BIT;
                Timer_DCBUS_OV_Reset     = Minute_Count;
                P_PV_Avg_DELAY_TIMER = Minute_Count;
            }
        }

    }

    /**************************************FLT-1 ******************************************/
    /**************************************DC_BUS_UV_FLT******************************************/
    /*
     * This fault condition occurs during the operation when the input power available is too low
     * even to maintain a sufficient DC_BUS voltage during operation. So to protect the LPS from
     * turning off, the fault comes under 6 ms and turns off the drive. The reset of this fault is
     * based on the power at the time of detection of the fault. If the power was too low then the
     * fault will be reset after a minute else it will be reset after 0.6 seconds.
     */
    /********************************************************************************************/

    if(!(FAULT_CODE & DC_BUS_UV_FLT_BIT) && ON_OFF_FLAG && (VDC_BUS_MAF < 175) && (Motor_Power_LPF_1 <((MIN_PV_POWER+50))) && (UV_Enable)){
        if(TimerDCUV_LPD==0){
            TimerDCUV_LPD = Minute_Count;
        }

        if(SysTime_Minute_Count_IntervalElapsed(TimerDCUV_LPD, 0.0001)){ // Observe the situation for 6 mseconds and decide
            DC_BUS_UV_FLT               = true;
            FAULT_CODE                 |= DC_BUS_UV_FLT_BIT;
            TimerDCUV_LPD_Reset         = Minute_Count;
            EEPROM_Fault_Write_Enable  = true;
            Powe_AT_ELP                = Motor_Power_LPF_1;
        }
    }
    else{
        TimerDCUV_LPD =0;
    }

    if(DC_BUS_UV_FLT && !ON_OFF_FLAG){
        if(Powe_AT_ELP < MIN_PV_POWER){
            Time_DCUV_LPD_Reset = 1;
        }
        else if(Powe_AT_ELP > (MIN_PV_POWER+50)){
            Time_DCUV_LPD_Reset = 0.01;
        }
        else{
            Time_DCUV_LPD_Reset = 0.02;
        }
        if(SysTime_Minute_Count_IntervalElapsed(TimerDCUV_LPD_Reset,  Time_DCUV_LPD_Reset)){  // Restart in 0.6 Seconds after detecting the event

            DC_BUS_UV_FLT       = false;
            FAULT_CODE         &= DC_BUS_UV_FLT_CLR_BIT;
            TimerDCUV_LPD_Reset = Minute_Count;
            P_PV_Avg_DELAY_TIMER = Minute_Count;
            /*  if(SPEED_MODE_SELECT == 5 && TIMER_TYPE == 1){
                if(SCHEDULE_OVER_FLAG != 1) SCHEDULE_EXECUTED = false;
            }*/
        }
    }

    /**************************************FLT-2 ******************************************/


    /**************************************OUTPUT_SC_FLT*******************************************/
    /*
     * This fault condition occurs when the short circuit happens or the current is suddenly increased
     * to a very high level. This is indicated by an external circuit from which we are reading a
     * GPIO. As soon this GPIO goes low (indicating a short circuit) we wait for 3 cycles and then
     * declare the fault. The fault gets cleared after 1 minute and can occur at max 13 times after
     * which it won't be reset.
     */
    /********************************************************************************************/

    if(!(FAULT_CODE & OUTPUT_SC_FLT_BIT) && ON_OFF_FLAG && (GPIO_ReadPin(226)==0 /*|| GPIO_ReadPin(0)==0*/ )){// GPIO_ReadPin(28)==0-in case of rev04
        SC_DETECTION_CTR++;
        if(SC_DETECTION_CTR > 3){
            OUTPUT_SC_FLT                   = true;
            FAULT_CODE                     |= OUTPUT_SC_FLT_BIT;
            EEPROM_Fault_Write_Enable       = true;
            COUNT_SC_FAULT++;
            Timer_SC_FLT_Reset              = Minute_Count;
        }
    }
    /*else if (!OUTPUT_SC_FLT && ON_OFF_FLAG == true){
        if(SysTime_Minute_Count_IntervalElapsed(timershortcircuit, 0.001)){
            timershortcircuit       = Minute_Count;                 // check unknown increment in SC_DETECTION_BY_CS happens
            SC_DETECTION_CTR        = 0;                            // and reset it at 60mS
        }
    }*/
    else if((FAULT_CODE & OUTPUT_SC_FLT_BIT) &&  ON_OFF_FLAG == false && COUNT_SC_FAULT<13){
        if(SysTime_Minute_Count_IntervalElapsed(Timer_SC_FLT_Reset, 1)){
            SC_DETECTION_CTR             = 0;
            Timer_SC_FLT_Reset           = Minute_Count;
            OUTPUT_SC_FLT                = false;
            FAULT_CODE                  &= OUTPUT_SC_FLT_CLR_BIT;
            P_PV_Avg_DELAY_TIMER        = Minute_Count;
            /* if(SPEED_MODE_SELECT == 5 && TIMER_TYPE == 1){
                if(SCHEDULE_OVER_FLAG != 1) SCHEDULE_EXECUTED = false;
            }*/
        }
    }


    /**************************************FLT-3 ******************************************/

    /*************************************OVERTEMP_FLT********************************************/
    /*
     * This fault condition comes immediately when the temperature of the IGBT module crosses
     * OVER_TEMP_LIMIT set from the display or the heat sink temperature crosses 90 deg. It will be
     * reset after 30 seconds when the IGBT temperature falls below OVER_TEMP_LIMIT-40 or the heat
     * sink temperature falls below 80 deg.
     */
    /********************************************************************************************/
    if(!(FAULT_CODE & VFD_OVERTEMP_FLT_BIT) && ON_OFF_FLAG && (TEMP_INV > VFD_OVER_TEMP_LIMIT /*|| TEMP_HS > (VFD_OVER_TEMP_LIMIT_1)*/)&&(OVER_TEMP_Enable)){
        if(Timer_Overtemp == 0){
            Timer_Overtemp = Minute_Count;
        }
        if(SysTime_Minute_Count_IntervalElapsed(Timer_Overtemp, 0.01667)){
            Timer_Overtemp                = Minute_Count;
            Timer_Overtemp_Reset          = Minute_Count;
            VFD_OVERTEMP_FLT              = true;
            FAULT_CODE                   |= VFD_OVERTEMP_FLT_BIT;
            EEPROM_Fault_Write_Enable     = true;
        }
    }
    else{
        Timer_Overtemp = 0;
    }
    if((FAULT_CODE & VFD_OVERTEMP_FLT_BIT) && TEMP_INV < (VFD_OVER_TEMP_LIMIT-30) /*&& TEMP_HS < (VFD_OVER_TEMP_LIMIT_1-30)*/){
        if(SysTime_Minute_Count_IntervalElapsed(Timer_Overtemp_Reset, 0.5)){// Restart in 30 sec after detecting the event
            VFD_OVERTEMP_FLT        = false;
            FAULT_CODE             &= VFD_OVERTEMP_FLT_CLR_BIT;
            Timer_Overtemp_Reset    = Minute_Count;
            Timer_Overtemp          = 0;
            P_PV_Avg_DELAY_TIMER    = Minute_Count;
            /* if(SPEED_MODE_SELECT == 5 && TIMER_TYPE == 1){
               if(SCHEDULE_OVER_FLAG != 1) SCHEDULE_EXECUTED = false;
           }*/
        }
    }


    /**************************************FLT-4 ******************************************/

    /**************************************OUTPUT_OV_FLT******************************************/
    /*
     * This fault condition occurs when the output side voltage is higher than 50V when the drive
     * is OFF (indicating a device failure or erroneous application of input voltage to output)
     * It gets reset after a minute when the output voltage is less than 20V.
     */
    /********************************************************************************************/


    if(!(FAULT_CODE & OUTPUT_OV_FLT_BIT) && (OC_Enable) && !ON_OFF_FLAG && (VVFD_UV_STRUCT.RMS > VFD_OVER_VOLT_LIMIT ||VVFD_VW_STRUCT.RMS > VFD_OVER_VOLT_LIMIT)){
        if(Timer_outputOV ==0){
            Timer_outputOV = Minute_Count;
        }
        if(SysTime_Minute_Count_IntervalElapsed(Timer_outputOV,0.01667)){
            VFD_OUT_OV_FLT                 = true;
            FAULT_CODE                    |= OUTPUT_OV_FLT_BIT;
            EEPROM_Fault_Write_Enable      = true;
            Timer_outputOV_Reset           = Minute_Count;
        }
    }
    else{
        Timer_outputOV = 0;
    }

    if ((FAULT_CODE & OUTPUT_OV_FLT_BIT) && !ON_OFF_FLAG){
        if(VVFD_UV_STRUCT.RMS <50 && VVFD_VW_STRUCT.RMS <50){
            if(SysTime_Minute_Count_IntervalElapsed(Timer_outputOV_Reset, 1)){
                Timer_outputOV_Reset    = Minute_Count;
                VFD_OUT_OV_FLT          = false;
                FAULT_CODE             &= OUTPUT_OV_FLT_CLR_BIT;
                Timer_outputOV          = 0;
                P_PV_Avg_DELAY_TIMER = Minute_Count;
                /*   if(SPEED_MODE_SELECT == 5 && TIMER_TYPE == 1){
                        if(SCHEDULE_OVER_FLAG != 1) SCHEDULE_EXECUTED = false;
                    }*/
            }
        }
    }

    /**************************************FLT-5 ******************************************/

    /**************************************UNBALANCE_FLT******************************************/
    /*
     * This fault condition occurs when the input  side voltage is unbalanced badly
     * It gets reset after a minute when the output voltage is less than 20V.
     */
    /********************************************************************************************/
    if(!(FAULT_CODE & INPUT_UNBALANCE_FLT_BIT) && (GRID_DETECTED == 1)&&(INPUT_UNBALANCE_LIMIT)){ //Not Required for Solar
        if(VGRD_RY_STRUCT.RMS -VGRD_YB_STRUCT.RMS > 50){
            if(Timer_Phaseloss==0){
                Timer_Phaseloss = Minute_Count;
            }
            if(SysTime_Minute_Count_IntervalElapsed(Timer_Phaseloss, 0.15)){
                Timer_Phaseloss             = Minute_Count;
                Timer_Phaseloss_Reset       = Minute_Count;
                INPUT_UNBALANCE_FLT         =  true;
                FAULT_CODE                 |= INPUT_UNBALANCE_FLT_BIT;
                EEPROM_Fault_Write_Enable   = true;
            }
        }
        else{
            Timer_Phaseloss = 0;
        }
    }
    else if((FAULT_CODE & INPUT_UNBALANCE_FLT_BIT) && ON_OFF_FLAG == false){
        if(SysTime_Minute_Count_IntervalElapsed(Timer_Phaseloss_Reset, 1)){
            if(VGRD_RY_STRUCT.RMS -VGRD_YB_STRUCT.RMS < 35){
                INPUT_UNBALANCE_FLT          = false;
                FAULT_CODE                  &= INPUT_UNBALANCE_FLT_CLR_BIT;
                Timer_Phaseloss_Reset        = Minute_Count;
                Timer_Phaseloss = 0;
                P_PV_Avg_DELAY_TIMER         = Minute_Count;
            }
        }
    }

    /**************************************FLT-6 ******************************************/

    /*************************************OUTPUT_OPEN_FLT******************************************/
    /*
     * This fault condition occurs during the operation when the any of the output is opened and is
     * detected by the current of any phase crossing a certain region while the power is there and
     * is observed for 4 seconds. The fault is reset after a minute.
     */
    /********************************************************************************************/

    if(!(FAULT_CODE & VFD_OUT_OPEN_FLT_BIT) && ON_OFF_FLAG == true && SOFT_STOP_FLAG == false){
        OUTPUT_OPEN_LOW_LIMIT   = 0.4 * I_OUTPUT_AVG;
        OUTPUT_OPEN_HIGH_LIMIT  = 1.6 * I_OUTPUT_AVG;
        MOTOR_PWR_MIN_LIMIT     = MOTOR_POWER *0.05;// 50; change of scaling factor
        if((P_PV_Avg > MOTOR_PWR_MIN_LIMIT ||Motor_Power_LPF_1 > MOTOR_PWR_MIN_LIMIT) &&
                (( IVFD_U_STRUCT.RMS < OUTPUT_OPEN_LOW_LIMIT || IVFD_U_STRUCT.RMS > OUTPUT_OPEN_HIGH_LIMIT)||
                        ( IVFD_V_STRUCT.RMS < OUTPUT_OPEN_LOW_LIMIT || IVFD_V_STRUCT.RMS > OUTPUT_OPEN_HIGH_LIMIT)||
                        ( IVFD_W_STRUCT.RMS < OUTPUT_OPEN_LOW_LIMIT || IVFD_W_STRUCT.RMS > OUTPUT_OPEN_HIGH_LIMIT))){
            if(Timer_OpenCircuit==0){
                Timer_OpenCircuit = Minute_Count;
            }
            if(SysTime_Minute_Count_IntervalElapsed(Timer_OpenCircuit, 0.1)){ // Observe the situation for 4 seconds and decide
                Timer_OpenCircuit       = Minute_Count;
                Timer_OpenCircuit_Reset = Minute_Count;
                VFD_OUT_OPEN_FLT        = true;
                FAULT_CODE             |= VFD_OUT_OPEN_FLT_BIT;
                EEPROM_Fault_Write_Enable     = true;
            }
        }
        else{
            Timer_OpenCircuit = 0;
            if (FLAG_OPEN_CKT == true){
                Timer_OpenCircuit             = Minute_Count;
                Timer_OpenCircuit_Reset       = Minute_Count;
                VFD_OUT_OPEN_FLT              = true;
                FAULT_CODE                   |= VFD_OUT_OPEN_FLT_BIT;
                EEPROM_Fault_Write_Enable     = true;
            }
        }
    }
    if((FAULT_CODE & VFD_OUT_OPEN_FLT_BIT) && ON_OFF_FLAG == false){
        if(SysTime_Minute_Count_IntervalElapsed(Timer_OpenCircuit_Reset, 1)){
            Timer_OpenCircuit_Reset   = Minute_Count;
            P_PV_Avg_DELAY_TIMER      = Minute_Count;
            VFD_OUT_OPEN_FLT          = false;
            FAULT_CODE               &= VFD_OUT_OPEN_FLT_BIT_CLR_BIT;
            Timer_OpenCircuit        = 0;
            /* if(SPEED_MODE_SELECT == 5 && TIMER_TYPE == 1){
                if(SCHEDULE_OVER_FLAG != 1) SCHEDULE_EXECUTED = false;
            }*/
        }

    }

    /**************************************FLT- 7 ******************************************/
    /*************************************OVERLOAD_FLT********************************************/
    /*
     * This fault condition comes when the current flowing from any of the phases is more than the
     * OVER_CURR_LIMIT value set from the display and that too for 30 seconds. It will be reset in
     * one minute after detection.
     */
    /********************************************************************************************/
    /*   if (flag_start == 1 && MOTOR_TYPE ==2 && (MODEL_NO == 92 || MODEL_NO == 96))
        OC_Limit = 1.1 * INIT_VOLTPERCENT_FACTOR * 10 * MAX_CURRENT * 1.414;
    else{
        OC_Limit = OVER_CURR_LIMIT; //, Timer_OverLoad_Reset
    }*/
    if(!(FAULT_CODE & OUTPUT_OVERLOAD_FLT_BIT) && ON_OFF_FLAG && (SOFT_STOP_FLAG == false)&&(Over_Load_enable)){
        if(IVFD_U_STRUCT.RMS > OVER_CURR_LIMIT || IVFD_V_STRUCT.RMS >  OVER_CURR_LIMIT
        /* || I_OUTPUT_DISPLAY > OVER_CURR_LIMIT*/){
            if(Timer_OverLoad==0/*|| OL_TRIP_TIME_LPF_MINUTE > 29*/){
                Timer_OverLoad = Minute_Count;
                /* time_interval_OL = 0.5 * (OVER_CURR_LIMIT/I_OUTPUT_DISPLAY) * (OVER_CURR_LIMIT/I_OUTPUT_DISPLAY);
                if (time_interval_OL > 0.5) time_interval_OL = 0.5;
                if (time_interval_OL < 0.01) time_interval_OL = 0.01;*/
            }

            //if(SysTime_Minute_Count_IntervalElapsed(timeroverload, OL_TRIP_TIME_LPF_MINUTE)){ // Observe the situation for 30 seconds and decide
            if(SysTime_Minute_Count_IntervalElapsed(Timer_OverLoad, 0.1/*time_interval_OL*/)){
                Timer_OverLoad          = Minute_Count;
                Timer_OverLoad_Reset    = Minute_Count;
                VFD_OUT_OL_FLT          = true;
                FAULT_CODE             |= OUTPUT_OVERLOAD_FLT_BIT;
                EEPROM_Fault_Write_Enable     = true;
            }
        }

        else{
            Timer_OverLoad          = 0;
        }
    }

    else if((FAULT_CODE & OUTPUT_OVERLOAD_FLT_BIT) && !ON_OFF_FLAG){
        if(SysTime_Minute_Count_IntervalElapsed(Timer_OverLoad_Reset, 1)){// Restart in 1 Minute after detecting the event
            VFD_OUT_OL_FLT                = false;
            FAULT_CODE                   &= OUTPUT_OVERLOAD_FLT_CLR_BIT;
            P_PV_Avg_DELAY_TIMER          = Minute_Count;
            Timer_OverLoad                = 0;
            //time_interval_OL              = 0;
            /* if(SPEED_MODE_SELECT == 5 && TIMER_TYPE == 1){
                if(SCHEDULE_OVER_FLAG != 1) SCHEDULE_EXECUTED = false;
            }*/
        }
    }

    //    /**************************************DRY_RUN_FLT********************************************/
    //         /*
    //          * This fault condition is an indication of no water present at pump site. This can be determined
    //          * when the Speed is full and the power drawn is lower than DRY_RUN_POWER set from display or
    //          * the current flowing is lesser than the DRY_RUN_LIMIT set from the display. This is reset after
    //          * 10 minutes of detection.
    //          */
    //         /********************************************************************************************/
    if(!LOAD_DRY_RUN_FLT && ON_OFF_FLAG && (SOFT_STOP_FLAG == false)&&(DRY_Run_Enable)){
        if ((P_Motor_Slowest < DRY_RUN_POWER_LIMIT) || (I_OUTPUT_AVG < DRY_RUN_CURR_LIMIT) && Live_RPM > 2500){
            if(timerdryrun==0){
                timerdryrun = Minute_Count;
            }

            if(SysTime_Minute_Count_IntervalElapsed(timerdryrun, 0.05)){ // Observe the situation for 1.5 seconds and decide
                timerdryrun             = Minute_Count;
                timerdryrun_Reset       = Minute_Count;
                LOAD_DRY_RUN_FLT        = true;
                FAULT_CODE             |= LOAD_DRY_RUN_FLT_BIT;
                //EEPROM_Write_check      = true;
            }
        }
        else{
            timerdryrun = 0;
        }
    }
    else if(LOAD_DRY_RUN_FLT && !ON_OFF_FLAG){
        //        if(SysTime_Minute_Count_IntervalElapsed(timerdryrun_Reset, 10)){ // Restart in 10 Minute after detecting the event
        if(SysTime_Minute_Count_IntervalElapsed(timerdryrun_Reset, Retry_time_Minutes)){ // 09/05/25 : (Chetan)Restart through Retry_time_Minutes which is configurable through display
            LOAD_DRY_RUN_FLT       = false;
            FAULT_CODE       &= LOAD_DRY_RUN_FLT_CLR_BIT;
            P_PV_Avg_DELAY_TIMER = Minute_Count;
            timerdryrun_Reset = Minute_Count;
            timerdryrun       = 0;
            /* if(SPEED_MODE_SELECT == 5 && TIMER_TYPE == 1){
                        if(SCHEDULE_OVER_FLAG != 1) SCHEDULE_EXECUTED = false;
                    }*/
        }
    }


    /**************************************FLT- 13 ******************************************/
    /***********************************OUTPUT_HIGH_INRUSH_FLT*************************************/
    /*
     * This fault condition is detected when the current flowing is high. There are three levels to
     * cross, and based on the level crossing of these, the detection time is decided. Higher the
     * current level, faster the detection. Once detected the fault resets after 30 seconds.
     */
    /********************************************************************************************/

      if(!OUTPUT_HIGH_INRUSH_FLT){
             if(ON_OFF_FLAG == true){
                 if(MSC_I_U_SQR > Motor_Slow_Lmt_OC || MSC_I_V_SQR > Motor_Slow_Lmt_OC || MSC_I_W_SQR > Motor_Slow_Lmt_OC){  // OC limit need to be
                     Motor_Short_Term_Over_Current_DSP_SLOW++;
                     if(MSC_I_U_SQR > Motor_Med_Lmt_OC || MSC_I_V_SQR > Motor_Med_Lmt_OC || MSC_I_W_SQR > Motor_Med_Lmt_OC){
                         Motor_Short_Term_Over_Current_DSP_MEDIUM++;
                         if(MSC_I_U_SQR > Motor_Fast_Lmt_OC  || MSC_I_V_SQR > Motor_Fast_Lmt_OC || MSC_I_W_SQR > Motor_Fast_Lmt_OC){
                             Motor_Short_Term_Over_Current_DSP_FAST++;
                         }
                     }
                 }
                 else if((MSC_I_U_SQR < Motor_Slow_Lmt_OC_Reset && MSC_I_V_SQR < Motor_Slow_Lmt_OC_Reset && MSC_I_W_SQR < Motor_Slow_Lmt_OC_Reset)){//20A continous current
                     if(SysTime_Minute_Count_IntervalElapsed(Motor_Check_Occurance_OC ,0.01667)){
                         Motor_Check_Occurance_OC = Minute_Count;
                         if(Motor_Short_Term_Over_Current_DSP_SLOW <=1){
                             Motor_Short_Term_Over_Current_DSP_SLOW =1;
                         }
                         if(Motor_Short_Term_Over_Current_DSP_MEDIUM <=1){
                             Motor_Short_Term_Over_Current_DSP_MEDIUM =1;
                         }
                         if(Motor_Short_Term_Over_Current_DSP_FAST <=1){
                             Motor_Short_Term_Over_Current_DSP_FAST =1;
                         }
                         Motor_Short_Term_Over_Current_DSP_SLOW--;
                         Motor_Short_Term_Over_Current_DSP_MEDIUM--;
                         Motor_Short_Term_Over_Current_DSP_FAST--;


                     }
                 }
                 if(Motor_Short_Term_Over_Current_DSP_SLOW > 1000 || Motor_Short_Term_Over_Current_DSP_MEDIUM > 450 || Motor_Short_Term_Over_Current_DSP_FAST > 100){
                     OUTPUT_HIGH_INRUSH_FLT  = true;
                     FAULT_CODE               |= OUTPUT_HIGH_INRUSH_FLT_BIT;
                     Motor_Check_RESET_OC            = Minute_Count;
                 }
             }
         }
         if(OUTPUT_HIGH_INRUSH_FLT){
             if (MSC_I_U_SQR < 4 && MSC_I_V_SQR < 4 && MSC_I_W_SQR < 4){
                 if(SysTime_Minute_Count_IntervalElapsed(Motor_Check_RESET_OC ,0.5)){
                     Motor_Check_RESET_OC               = Minute_Count;
                     Motor_Short_Term_Over_Current_DSP_SLOW   = 1;
                     Motor_Short_Term_Over_Current_DSP_MEDIUM = 1;
                     Motor_Short_Term_Over_Current_DSP_FAST   = 1;
                     OUTPUT_HIGH_INRUSH_FLT             = false;
                     FAULT_CODE                       &= OUTPUT_HIGH_INRUSH_FLT_CLR_BIT;
                     P_PV_Avg_DELAY_TIMER              = Minute_Count;
                   }
                 }
             }



}


