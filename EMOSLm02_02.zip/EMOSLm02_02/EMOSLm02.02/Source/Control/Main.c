//#############################################################################
//
// FILE:   Main.c
//
// TITLE:  Main file for Initialization and While loop
//
//#############################################################################
//
// Included Files
//
#include <Headers/Project_Header/Init.h>

//unsigned char data_test_byte1, data_test_byte2, data_test_byte3;
//unsigned int data_test_int1, data_test_int2;
//float data_test_float1, data_test_float2;

uint16_t spi_dummy_read=0;

void main(void){

//    unsigned char day_r,date_r,month_r,year_r,sec_r,minute_r,hour_r;

    InitSysCtrl();                                          // Initialize device clock and peripherals
    GPIO_Select();                                          // Initialize GPIO based on application
    AGPIO_Select();                                         // Initialize AGPIO based on application

    DINT;                                                   // Disable CPU interrupts

    InitPieCtrl();                                          // Initialize the PIE control registers to their default state.
    IER = 0x0000;                                           // Disable CPU interrupts
    IFR = 0x0000;                                           // Clear all CPU interrupt flags:

    InitPieVectTable();                                     // Initialize the PIE vector table with pointers to the shell
    MOTOR_TYPE = 0;                                         //0 IM, 1 PMSM
    MOTOR_ID = 1;
    Variable_Init();                                        // Initialization of variable                                                        // Interrupt Service Routines (ISR).

    FAULT_CODE =0;

    Firmware_Version = 02.02;                               //As of CTRL brd Rev-06

    EALLOW;
    PieCtrlRegs.PIECTRL.bit.ENPIE       = 1;                // Enable the PIE block
    PieVectTable.ADCA1_INT              = &adcA1ISR;        // Function for ADCA interrupt 1
    PieVectTable.EPWM4_TZ_INT           = &epwmFlt_isr;     // TZ_INTERRUPT
    //    PieVectTable.SPIA_TX_INT            = &spiaTxFifoIsr;   // SPIA_TX
    //    PieVectTable.SPIA_RX_INT            = &spiaRxFifoIsr;   // SPIA_RX
    PieVectTable.SCIA_TX_INT            = &sciaTxFifoIsr;   // RS485_TXD_DSP
    PieVectTable.SCIA_RX_INT            = &sciaRxFifoIsr;   // RS485_RXD_DSP

    PieVectTable.SCIB_TX_INT            = &scibTxFifoIsr;   // RS485_TXD_DSP
    PieVectTable.SCIB_RX_INT            = &scibRxFifoIsr;   // RS485_RXD_DSP
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC    = 0;
    EDIS;

    // GPIO starting positions
    ConfigureADC();                                         // Configure the ADC and power it up
    SetupADCEpwm();                                         // Setup the ADC for ePWM triggered conversions on channel 1
    ConfigureEPWM();                                        // Configure all the EPWM modules
    TZ_FRC_PWM_low();
    TZ_init();                                              // Initialize Trip-zone on EPWM4
    ConfigureDAC();                                         // DAC_A
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;

    GpioDataRegs.GPHSET.bit.GPIO228     = 1;                // To enable Gate Driver ICs
    DELAY_US(500);
    GpioDataRegs.GPHCLEAR.bit.GPIO228       = 1;

    ConfigureRS485();

    Configure_Display_scia();

    ConfigureEEprom();

    EALLOW;
    IER |= M_INT1;                                          // Enable group 1 interrupts
    IER |= M_INT2;                                          // Enable group 2 interrupts
    IER |= M_INT9;                                          // Enable group 9 interrupts
    IER |= M_INT6;                                          // Enable group 6 interrupts
    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;                      // Enable PIE interrupt
    PieCtrlRegs.PIEIER2.bit.INTx4 = 1;                      // Enable EPWM4_TZ Interrupt
    //    PieCtrlRegs.PIEIER6.bit.INTx1 = 1;                      // SPIA_RX
    //    PieCtrlRegs.PIEIER6.bit.INTx2 = 1;                      // SPIA_TX
    PieCtrlRegs.PIEIER9.bit.INTx1 = 1;                      // SCIA_RX
    PieCtrlRegs.PIEIER9.bit.INTx2 = 1;                      // SCIA_TX
    PieCtrlRegs.PIEIER9.bit.INTx3 = 1;                      // RS485_RX
    PieCtrlRegs.PIEIER9.bit.INTx4 = 1;                      // RS485_TX
    EDIS;
    EINT;                                                   // Enable Global interrupt INTM
    ERTM;                                                   // Enable Global realtime interrupt DBGM

    EALLOW;                                                 // need to check if required or not
    //    spi_dummy_read = SpiaRegs.SPIRXBUF;
    //    SpiaRegs.SPIFFRX.bit.RXFFINTCLR     = 1;                // Clear RX FIFO interrupt Flag
    //    PieCtrlRegs.PIEACK.all              = PIEACK_GROUP6;    // Issue PIE ACK
    EDIS;

    RS485_scib.sci_send_buff    = malloc(256);              // need to put inside SCI init
	RS485_scib.rx_count = 0;
    RS485_scib.start_address = 0;

    Display_scia.sci_send_buff    = malloc(256);              // need to put inside SCI init
    Display_scia.rx_count = 0;
    Display_scia.start_address = 0;
    Test_Var_PRD = 320;                                      //Test_var


    init_BQ32();

    EEPROM_All_Data_Read();//to uncomment
//        EEPROM_DATA_VALID_FLAG =0;
    if (EEPROM_DATA_VALID_FLAG !=1){
        EEPROM_Default_Data_Write();
        EEPROM_All_Data_Read();
    }

    //        CONST_SPEED_REF_1 = 500;
    Cummulative_Parameter_Read();//to uncomment

     /*   day_r=dec2bcd(6);
        date_r=dec2bcd(05);
        month_r=dec2bcd(07);
        year_r=dec2bcd(25);
        set_date_BQ32(day_r,date_r,month_r,year_r);

        hour_r=dec2bcd(11);
        minute_r=dec2bcd(15);
        sec_r=dec2bcd(00);
        set_time_BQ32(sec_r,minute_r,hour_r);*/

    read_date_BQ32(&Day_RTC,&Date_RTC,&Month_RTC, &Year_RTC);
    read_time_BQ32(&Second_RTC, &Minute_RTC, &Hour_RTC);
    for(;;){

        // Need to write inside scheduler
        if(SysTime_mSec_IntervalElapsed(Motor_Timer, 10)){
            Motor_Timer = mSeconds;
            Power_flow_Manager();
        }
        if(SysTime_mSec_IntervalElapsed(UART_Test, 200)){
            UART_Test = mSeconds;
            read_time_BQ32(&Second_RTC, &Minute_RTC, &Hour_RTC);
                         /*if((FACTORY_MODE == 1)&&(Factory_flag == 0)){
                             Factory_Mode();
                             Factory_flag = 1;
                         }*/
            //             GpioDataRegs.GPBCLEAR.bit.GPIO32 = 1;    // to enable 485 communication
            //             scib_xmit(0x41);                         // send a dummy byte
            Update_MB_Var();   //Update Modbus Variables/
            Display_scia.start_address = Display_frame_read(Display_scia.start_address);     //Display Scheduler
            RS485_scib.start_address = RS485_frame_read(RS485_scib.start_address);     // MODbus reading inside schedule
            RMS_Average_Calc();
            Flow_manager();
            if(SysTime_Minute_Count_IntervalElapsed(CUMMULATIVE_PARAMETER_TIMER, 15)){ // Observe the situation for 2 hours and decide
                CUMMULATIVE_PARAMETER_TIMER = Minute_Count;
                EEPROM_WriteFloat(16,0,Cumulative_Energy);// Energy//Total
                EEPROM_WriteFloat(16,2,Cummulative_Water_Discharge);//Total
                EEPROM_WriteFloat(16,4,Cumulative_Run_Hrs);//Time//Total
            }

        }

        if(SysTime_mSec_IntervalElapsed(PLC_Test, 50)){
            PLC_Test = mSeconds;
            Digital_PLC_Handler();
            //Analog_PLC_Handler();
        }

        // End of scheduler
    }
}
void Update_MB_Var(void){



    COUNT_DISPLAY++;
    if(COUNT_DISPLAY > 5){
        COUNT_DISPLAY =0;
        Input_Vol_RY =  VGRD_RY_STRUCT.RMS;
        Input_Vol_YB =  VGRD_YB_STRUCT.RMS;
        Input_Vol_BR =  VGRD_BR_STRUCT.RMS;
        Input_Curr_R =  IGRD_R_STRUCT.RMS;
        // Input_Curr_Y =  IGRD_Y_STRUCT.RMS;
        // Input_Curr_B =  IGRD_B_STRUCT.RMS;
        Output_Vol_UV =  VVFD_UV_STRUCT.RMS;
        Output_Vol_VW =  VVFD_VW_STRUCT.RMS;
        Output_Vol_WU =  VVFD_WU_STRUCT.RMS;

        Output_Curr_U =  IVFD_U_STRUCT.RMS;
        Output_Curr_V =  IVFD_V_STRUCT.RMS;
        Output_Curr_W =  IVFD_W_STRUCT.RMS;

        I_OUTPUT_AVG = (IVFD_U_STRUCT.RMS + IVFD_V_STRUCT.RMS + IVFD_W_STRUCT.RMS)*0.33;
        /*------------------Water Calculation-----------*/
        Today_Hr = Cumulative_Run_Hrs - Total_Time_Ref;//Today
        Today_Energy = Cumulative_Energy - Total_Energy_Ref;//Today
        Daily_Water_Discharge = Cummulative_Water_Discharge - Total_Water_Discharge_Ref;//Today
        if (ON_OFF_FLAG == 1){
            if(MOTOR_TYPE == 0){
                if(CONTROL_MODE == 1){
                    Live_RPM      = (Freq*120)/RATED_POLE_IM;

                }
                else if(CONTROL_MODE == 2){
                    Live_RPM     = W_Est_LPF * 9.554;
                }
                Live_Freq = Freq;
            }
            if(MOTOR_TYPE == 1){
                Live_RPM     = W_est_PM_LPF * 9.554;
                Live_Freq = FREQ_HZ_DISPLAY_PMSM;//FREQ_HZ_DISPLAY_PMSM;

            }

            if(MOTOR_TYPE == 2){
                Live_RPM     = W_est_PM_LPF * 9.554;
            }
            //    if(APP_MODE == 0){
            if(APPLICATION_MODE == 0){
                Live_Power = P_PV_Avg;
            }
            //    else if(APP_MODE == 1){
            else if(APPLICATION_MODE == 1){
                Live_Power = Motor_Power_LPF_1;
            }
            Live_Torque = Live_Power*0.0147/Live_RPM;
        }
        else {
            Live_Power = 0;
            Live_Torque = 0;
            Live_RPM = 0;
        }

        if(ON_OFF_FLAG == false){
            DC_OC_VOLTAGE = VDC_BUS_LPF_50;
        }
    }






}
void Cummulative_Parameter_Read(void){
        Cumulative_Energy                                  = EEPROM_ReadFloat(16,0);//* ONE_BY_THOUSAND;
        Cummulative_Water_Discharge                        = EEPROM_ReadFloat(16,2);//* ONE_BY_THOUSAND;
        Cumulative_Run_Hrs                                 = EEPROM_ReadFloat(16,4);//*ONE_BY_THOUSAND;

}
// End of File
