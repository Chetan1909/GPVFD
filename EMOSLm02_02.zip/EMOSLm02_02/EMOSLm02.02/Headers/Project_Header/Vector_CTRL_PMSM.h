/*
 * Vector_CTRL_PMSM.h
 *
 *  Created on: 20-Jan-2025
 *      Author: manoj
 */

#ifndef HEADERS_PROJECT_HEADER_VECTOR_CTRL_PMSM_H_
#define HEADERS_PROJECT_HEADER_VECTOR_CTRL_PMSM_H_

void Motor_Parameter_Estimation_PMSM(void);
void Speed_Estimation_PMSM(void);
void Vector_Control_PMSM(void);



#endif /* HEADERS_PROJECT_HEADER_VECTOR_CTRL_PMSM_H_ */
