/*
 * ISR.h
 *
 *  Created on: 13-May-2023
 *      Author: pemen
 */

#ifndef HEADERS_PROJECT_HEADER_ADC_ISR_H_
#define HEADERS_PROJECT_HEADER_ADC_ISR_H_

__interrupt void adcA1ISR(void);
__interrupt void epwmFlt_isr(void);                 // TZ INTERRUPT
void Energy_and_Flow_Meter(void);
void Flow_manager(void);
#endif /* HEADERS_PROJECT_HEADER_ADC_ISR_H_ */
