/*
 * MODBUS.h
 *
 *  Created on: 25-Aug-2023
 *      Author: Dipesh
 */

#ifndef HEADERS_PROJECT_HEADERS_MODBUS_H_
#define HEADERS_PROJECT_HEADERS_MODBUS_H_

#include "Init.h"


struct Coils{
    Uint16 ControlWord;     // Writable
    Uint16 StatusWord;      // Readable
    Uint16 Speed;           // Writable
    Uint16 OutputFrequency; // Readable
    bool_t WriteControl;    // Writable
};


extern unsigned char slaveAddress;
extern unsigned char response_flag;
extern unsigned char *frame;
extern unsigned int CRC;
extern float float_temp;
extern uint32_t int_temp;
extern unsigned char dataFrame[40];
extern const unsigned char recv_buffer_size;
extern unsigned int address;
extern unsigned int quantity;
extern unsigned int data;
extern Uint16 MODBUS_registers[5];     // defines registers values for the MODBUS.

extern unsigned char *frame1;
extern unsigned char dataFrame1[40];
extern unsigned char response_flag1;
                                                                 // stores the index just after most recent FRAME detection.
extern unsigned int CRC1;
extern const unsigned char recv_buffer_size1;//100;//34;
extern unsigned int address1;
extern unsigned int quantity1;
extern unsigned int data1;
extern float float_temp1;
extern uint32_t int_temp1;
extern Uint16 MODBUS_registers1[5];


void stringCopy2(unsigned char startAddress,unsigned char size);
unsigned int CRC16_MODBUS(unsigned char *buf, int len);
void RS485_frame_write(unsigned char responseCode);
unsigned char RS485_frame_read(unsigned char startByte);
void Configure_Display_scia(void);
void replicateFrame(unsigned char startAddress,unsigned char size);
void replicate_485Frame(unsigned char startAddress,unsigned char size);
unsigned char Display_frame_read(unsigned char startAddress);
void Display_frame_write(unsigned char responseCode);
void Enter_Serial_Boot_Mode(void);

#endif /* HEADERS_PROJECT_HEADERS_MODBUS_H_ */
