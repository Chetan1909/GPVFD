/*
 * User_Init.h
 *
 *  Created on: 13-May-2023
 *      Author: pemen
 */

#ifndef HEADERS_PROJECT_HEADER_INIT_H_
#define HEADERS_PROJECT_HEADER_INIT_H_
#include "f28x_project.h"
#include "f280013x_device.h"         // f280013x Headerfile Include File
#include <stdlib.h>
#include "math.h"
#include <string.h>     //sagar
#include <Headers/Project_Header/Global_Variable.h>
#include <Headers/Project_Header/RTC.h>
#include <Headers/Project_Header/ADC_ISR.h>
#include <Headers/Project_Header/DAQ.h>
#include <Headers/Project_Header/F&W_Manager.h>
#include <Headers/Project_Header/Scaler_CTRL_IM.h>
#include <Headers/Project_Header/Vector_CTRL_IM.h>
#include <Headers/Project_Header/Vector_CTRL_PMSM.h>
#include <Headers/Project_Header/Vector_CTRL_SynRM.h>
#include <Headers/Project_Header/Solar_MPPT.h>
#include <Headers/Project_Header/Sci_Init.h>
#include <Headers/Project_Header/I2C_Init.h>
#include <Headers/Project_Header/SPI_Init.h>
#include <Headers/Project_Header/MODBUS.h>

#include <Headers/Project_Header/Address.h>

#include <Headers/Project_Header/PLC_IO.h>


void ConfigureADC(void);
void SetupADCEpwm(void);
void InitEPwmGpio(void);
void GPIO_Select(void);
void AGPIO_Select(void);
void ConfigureDAC(void);

void ConfigureEPWM(void);
void InitEPwm1Gpio(void);
void InitEPwm1Example(void);
void InitEPwm2Gpio(void);
void InitEPwm2Example(void);
void InitEPwm5Gpio(void);
void InitEPwm5Example(void);
void InitEPwm6Gpio(void);
void InitEPwm6Example(void);
void InitEPwm7Gpio(void);
void InitEPwm7Example(void);
void TZ_init(void);
void TZ_FRC_PWM_low(void);
void TZ_CLR_PWM(void);
void Power_flow_Manager(void);
void Update_MB_Var(void);
void Cummulative_Parameter_Read(void);
#endif /* HEADERS_PROJECT_HEADER_INIT_H_ */
