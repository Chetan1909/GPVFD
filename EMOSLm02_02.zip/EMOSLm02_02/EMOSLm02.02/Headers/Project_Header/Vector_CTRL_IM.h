/*
 * Vector_CTRL_IM.h
 *
 *  Created on: 10-Aug-2023
 *      Author: manoj
 */

#ifndef HEADERS_PROJECT_HEADER_VECTOR_CTRL_IM_H_
#define HEADERS_PROJECT_HEADER_VECTOR_CTRL_IM_H_

void Motor_Parameter_Estimation_IM(void);
void Speed_Estimation_IM(void);
void Vector_Control_IM(void);

#endif /* HEADERS_PROJECT_HEADER_VECTOR_CTRL_IM_H_ */
