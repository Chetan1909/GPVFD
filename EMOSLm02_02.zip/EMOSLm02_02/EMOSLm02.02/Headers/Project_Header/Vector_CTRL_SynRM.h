/*
 * Vector_CTRL_SynRM.h
 *
 *  Created on: 20-Jan-2025
 *      Author: manoj
 */

#ifndef HEADERS_PROJECT_HEADER_VECTOR_CTRL_SYNRM_H_
#define HEADERS_PROJECT_HEADER_VECTOR_CTRL_SYNRM_H_

void Motor_Parameter_Estimation_SynRM(void);
void Speed_Estimation_SynRM(void);
void Vector_Control_SynRM(void);

#endif /* HEADERS_PROJECT_HEADER_VECTOR_CTRL_SYNRM_H_ */
