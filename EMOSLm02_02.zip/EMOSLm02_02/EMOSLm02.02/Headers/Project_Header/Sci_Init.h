/*
 * Sci_Init.h
 *
 *  Created on: 27-Jul-2023
 *      Author: Arjun Yadav
 */

#ifndef HEADERS_PROJECT_HEADER_SCI_INIT_H_
#define HEADERS_PROJECT_HEADER_SCI_INIT_H_


struct SCI_VAR{
    unsigned char           *sci_send_buff;
    unsigned char           sci_recv_buff[40];
    volatile unsigned char  tx_target_count;
    volatile unsigned char  tx_count;
	volatile unsigned char  rx_count;
	unsigned char           start_address;
    unsigned char           BAUD_RATE;
};

extern struct SCI_VAR RS485_scib;
extern struct SCI_VAR Display_scia;

void ConfigureRS485(void);
void scia_fifo_init(void);
void scia_xmit(unsigned char a);                          //send character on serial
void scia_msg(char *msg);                                //send data on serial
void scia_msg_intrupt(void);

__interrupt void sciaTxFifoIsr(void);               // RS485 TX INTRUPT
__interrupt void sciaRxFifoIsr(void);               // RS485 RX INTERRUPT

void scib_fifo_init(void);
void scib_xmit(unsigned char a);                          //send character on serial
void scib_msg(char *msg);                                //send data on serial
void scib_msg_intrupt(void);

__interrupt void scibTxFifoIsr(void);               // RS485 TX INTRUPT
__interrupt void scibRxFifoIsr(void);               // RS485 RX INTERRUPT

#endif /* HEADERS_PROJECT_HEADER_SCI_INIT_H_ */
