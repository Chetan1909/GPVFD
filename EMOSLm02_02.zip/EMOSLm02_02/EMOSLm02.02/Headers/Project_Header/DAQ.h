/*
 * ADC.h
 *
 *  Created on: 13-May-2023
 *      Author: pemen
 */

#ifndef HEADERS_PROJECT_HEADER_DAQ_H_
#define HEADERS_PROJECT_HEADER_DAQ_H_

void Read_ADC(void);
void RMS_Average_Calc(void);


void PLL_IndexCalc(float Index_Freq, IndexPara *Index);
float rms_calculation(float *ADC, RMSData *RMSVar);

#endif /* HEADERS_PROJECT_HEADER_DAQ_H_ */
