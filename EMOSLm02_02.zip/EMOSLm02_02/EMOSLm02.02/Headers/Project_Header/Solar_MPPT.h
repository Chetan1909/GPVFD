/*
 * Solar_MPPT.h
 *
 *  Created on: 16-Oct-2023
 *      Author: manoj
 */

#ifndef HEADERS_PROJECT_HEADER_SOLAR_MPPT_H_
#define HEADERS_PROJECT_HEADER_SOLAR_MPPT_H_
void vfd_dcbus_cntrl_PMSM();
void vfd_dcbus_cntrl_IMFOC();
void vfd_dcbus_cntrl_IM();
void VBased_MPPT();
float Vdc_Controller_TS_MPP(float VDC_VFD_ERROR);
#endif /* HEADERS_PROJECT_HEADER_SOLAR_MPPT_H_ */
