/*
 * RTC.h
 *
 *  Created on: Jul 12, 2023
 *      Author: Dell
 */

#ifndef HEADERS_PROJECT_HEADERS_RTC_H_
#define HEADERS_PROJECT_HEADERS_RTC_H_

void Update_Time(void);

bool SysTime_mSec_IntervalElapsed(Uint32 startTime, Uint32 interval);
bool SysTime_Seconds_IntervalElapsed(Uint32 startTime, Uint32 interval);
bool SysTime_Minutes_IntervalElapsed(Uint32 startTime, Uint32 interval);
bool SysTime_Minute_Count_IntervalElapsed(float startTime, float interval);



#endif /* HEADERS_PROJECT_HEADERS_RTC_H_ */
