/*
 * Variable.h
 *
 *  Created on: 05-Aug-2023
 *      Author: manoj
 */

#ifndef HEADERS_PROJECT_HEADER_GLOBAL_VARIABLE_H_
#define HEADERS_PROJECT_HEADER_GLOBAL_VARIABLE_H_

//*********************************Macros*************************************************************//
#define Low                 1                       // This will be with Opto. If without Opto change it 0
#define High                0                       // This will be with Opto. If without Opto change it 1
#define Ts                  0.00005                 // sampling time 50uS
#define PI                  3.141592654
#define PIby2               1.570796327
#define PIinto2             6.283185307
#define OneBy2PI            0.159154943
#define RootThreebyTwo      0.866025
#define ThreebyTwo          1.5

#define INTERRUPT_PERIOD    3000
#define GATE_CLK_PERIOD     120
#define INVERTER_PERIOD     18750 //12000                 //6250 for 9.6kHz Switching, // 18750 for 3.2kHz  120M/[3200*2]
#define BAND                16
#define BAND_INV            200


#define COUNT_FACTOR                 0.625


#define Min_Threshhold_Freq 10
//#define VDC_VFD_ERROR_Max   100
//#define VFD_VDC_KP          0.04     //0.08       //0.1
//#define VFD_VDC_KI          0.8      //0.95       //0.8
#define MPPT_CALLING_FRQ    3000

#define VFD_VDC_REF_MIN     220
#define VFD_VDC_REF_MAX     720

#define LPF_WC_1            1
#define LPF_CONST_C1_1      Ts/(1+(LPF_WC_1*Ts))    //Ts/(1+Wc*Ts)
#define LPF_CONST_C2_1      1/(1+(LPF_WC_1*Ts))     // 1/(1+Wc*Ts)

#define LPF_WC_50           30              // Speed LPF cut off frequency
#define LPF_CONST_C1_50     Ts/(1+(LPF_WC_50*Ts)) //  0.0000995025    //Ts/(1+Wc*Ts)
#define LPF_CONST_C2_50     1/(1+(LPF_WC_50*Ts))    //1/(1+Wc*Ts)

#define LPF_Cutoff_Freq_1      0.15                                       // REMOVE DC PART       For Grid Voltage = 0.015
#define LPF_Const_Slowest      Ts/(1+(LPF_Cutoff_Freq_1*Ts))
#define LPF_Const_Slowest0     1/(1+(LPF_Cutoff_Freq_1*Ts))

#define Wc_SPD_PM              50
#define LPF_SPD_PM_C1          Ts/(1+(Wc_SPD_PM*Ts))         // 0.0000995025    //Ts/(1+Wc*Ts)
#define LPF_SPD_PM_C2          1/(1+(Wc_SPD_PM*Ts))           // 1/(1+Wc*Ts)

#define Wc_SPD_PM_SLOWEST           0.1
#define LPF_SPD_PM_SLOWEST_C1       Ts/(1+(Wc_SPD_PM_SLOWEST*Ts)) // 0.0000995025    //Ts/(1+Wc*Ts)
#define LPF_SPD_PM_SLOWEST_C2       1/(1+(Wc_SPD_PM_SLOWEST*Ts))   // 1/(1+Wc*Ts)

#define  LPF_Cutoff_Freq_Slowest    0.15
#define  LPF_Const_Slowest1         Ts/(1+(LPF_Cutoff_Freq_Slowest*Ts))   // 0.0000995025    //Ts/(1+Wc*Ts)
#define  LPF_Const_Slowest2         1/(1+(LPF_Cutoff_Freq_Slowest*Ts))     // 1/(1+Wc*Ts)

#define  LPF_Cutoff_Freq_Slowest1   1
#define  LPF_Const_Slowest3         Ts/(1+(LPF_Cutoff_Freq_Slowest1*Ts))  // 0.0000995025    //Ts/(1+Wc*Ts)
#define  LPF_Const_Slowest4         1/(1+(LPF_Cutoff_Freq_Slowest1*Ts))    // 1/(1+Wc*Ts)

#define  LPF_Cutoff_Freq_Slowest2   10
#define  LPF_Const_Slowest5         Ts/(1+(LPF_Cutoff_Freq_Slowest2*Ts))  // 0.0000995025    //Ts/(1+Wc*Ts)
#define  LPF_Const_Slowest6         1/(1+(LPF_Cutoff_Freq_Slowest2*Ts))    // 1/(1+Wc*Ts)

#define  LPF_Cutoff_Freq_Slowest3   25                                 // 100
#define  LPF_Const_Slowest7         Ts/(1+(LPF_Cutoff_Freq_Slowest3*Ts))  // 0.0000995025    //Ts/(1+Wc*Ts)
#define  LPF_Const_Slowest8         1/(1+(LPF_Cutoff_Freq_Slowest3*Ts))    // 1/(1+Wc*Ts)

#define  LPF_Cutoff_Freq_Slowest4   1
#define  LPF_Const_Slowest9         Ts/(1+(LPF_Cutoff_Freq_Slowest4*Ts))  //  0.0000995025    //Ts/(1+Wc*Ts)
#define  LPF_Const_Slowest10        1/(1+(LPF_Cutoff_Freq_Slowest4*Ts))    //1/(1+Wc*Ts)

#define  LPF_Cutoff_Freq_Slowest5   300
#define  LPF_Const_Slowest11        Ts/(1+(LPF_Cutoff_Freq_Slowest5*Ts))  //                 //Ts/(1+Wc*Ts)
#define  LPF_Const_Slowest12        1/(1+(LPF_Cutoff_Freq_Slowest5*Ts))    //1/(1+Wc*Ts)

//#define Current_Error_Id_PM_Integ_Max       430
//#define Id_PM_PI_Output_Max                 430

//#define Current_Error_Iq_PM_Integ_Max       430
//#define Iq_PI_Output_PM_Max                 430

#define Park_KI_MAX                         20
#define Park_KI_MIN                        -20

#define Park_PI_MAX                         20
#define Park_PI_MIN                        -20

#define CURR_OFFSET_ACS720      2048//   2252-TMCS1123, 2048-ACS720
#define VDC_GAIN                0.1978//0.2488                  // 3/(4096*circuit_gain)
#define CURR_GAIN              0.01902// 0.035723//           0.035723//3/(4096*circuit_gain(20.5mV/A)) @ACS720KLATR-65AB-T                      //0.019024// 3/(4096*circuit_gain(38.5mV/A)) @TMCS1123D71                          0.01902// 3/(4096*circuit_gain(38.5mV/A)) @ACS720_35A
#define VAC_GAIN                0.396134//0.4981
#define AC_VOLT_OFFSET          2252

#define Speed_Error_IM_Max      150
#define Speed_Error_IM_PI_Kp    0.3
#define Speed_Error_IM_PI_Ki    0.1

//#define Speed_Error_PM_PI_Kp    0.3
//#define Speed_Error_PM_PI_Ki    0.1

#define Current_Error_Id_Kp     10
#define Current_Error_Id_Ki     300
#define Current_Error_Iq_Kp     10
#define Current_Error_Iq_Ki     300

//#define FluxErrorPI_Kp          10
//#define FluxErrorPI_Ki          300
extern float FluxErrorPI_Kp, FluxErrorPI_Ki;
extern float Id_Ref_IM_debug, Iq_Ref_IM_debug;
#define Current_Error_Integ_Max 400
#define Flux_Error_Max          12
#define Flux_Error_PI_Max       6000

#define SAI_Mag_PM_Max          100
#define SAI_Mag_PM_Min          0.0001


#define ONE_BY_TEN              0.1
#define ONE_BY_HUNDRED          0.01
#define ONE_BY_THOUSAND         0.001
#define ONE_BY_TEN_THOUSAND     0.0001
#define TEN                     10
#define HUNDRED                 100
#define THOUSAND                1000
#define TEN_THOUSAND            10000

// below parameters will go to EEPROM
//#define VFD_VDC_STEP            5           //0.9        //0.7
//#define MAX_SOLAR_POWER         15000
//#define I_PV_MAX                40
#define MOTOR_FREQ_INCR         0.7
//#define MAX_OUTPUT_CURRENT      24
#define MOTOR_FREQ_DECR         0.3
//#define MAX_FREQ_SET            180
#define APP_MODE                1
#define TEMP_DERATING_START     90

#define  FILTER_RC                  0.00022

#define publishSample(sample, channel, index)   \
    do{\
        DaqMeasItems_##channel##_buf[index] = sample;\
    }while(0);
#define FS           20000
#define MAX_INDEX    0.015625


//********************************* End of Macros*******************************************************//



/*********************************User Interface*******************************************************/
extern uint16_t dummy_read, COUNT_DISPLAY;
extern bool RS485_TX_EN;
extern bool ON_OFF_FLAG, SOFT_STOP_FLAG, SOFT_START_FLAG, SPEED_FORWARD, FREQ_UP_FLAG, SET_FREQ_ACHIEVED, LPS_CTRL, DSAT_CLEAR_FLAG, MASTER_ON_OFF, POLARITY , GRID_DETECTED,MASTER_ON_OFF;
extern bool LOW_SPEED_OFF_FLAG, FLAG_FREQ_CORRES, Warning_LOW_POWER;
extern float Test_Float1, Test_Float2, grid_detect_minute,Firmware_Version;
extern unsigned char Display_Reset_Flag;
extern float Live_Power, Live_Torque;
extern unsigned int Live_RPM;
extern float Live_Freq;
extern float Power_Interval,Energy_Interval, Energy_Avg, Flow_L_Avg;
extern float Rated_Speed_info, RATED_LPM, RATED_FREQ, POW1, POW2, POW3, POW4, POW5;
extern float P_Motor_Slowest, D1, D2, D3, D4, D5, Head, Low_Power_Test;
extern float DC_OC_VOLTAGE;
extern Uint16 PUMP_TYPE;
extern float Today_Hr,Today_Energy,Total_Time_Ref,Total_Energy_Ref,Today_Water_Discharge,Total_Water_Discharge_Ref;
extern uint16_t RPM_Display,  count_pos, count_neg ,SPI_send_buff[7][15];
extern unsigned char Day_RTC,Date_RTC,Month_RTC,Year_RTC,Second_RTC,Minute_RTC,Hour_RTC;
extern float Test_Var_PRD;
extern float case_state,Motor_Power_Rating;
extern unsigned int Test_Var1,Test_Var2;
//extern unsigned int CURR_OFFSET_ACS720,CURR_GAIN;
extern unsigned int COUNT_DISPLAY_SPD_FREQ, FREQ_HZ_DISPLAY_PMSM, DRY_RUN_RPM_PMSM;

extern unsigned int Device_State_Type,Device_Type,Device_Sr_No,Date_Code;
//********************************* End of User Interface *************************************************************//

/*********************************User PLC*******************************************************/
extern Uint16 loc_plc[8];
extern Uint16 PLC_Function, flag, PLC_Test, PLC_DI3, PLC_DI4;
extern bool DI1_MOMENTARY_FLAG, DI3_MOMENTARY_FLAG;
extern char PLC_V_OR_I;

//********************************* End of User PLC *************************************************************//

//********************************* EEPROM Related *************************************************************//
extern unsigned char eeprom_slave_address;
extern Uint16 RATED_POLE_IM, RATED_POLE_PM;
extern Uint16 SPEED_MODE_SELECT, CONTROL_MODE, FACTORY_MODE, LANGUAGE_SELECTED, APPLICATION_MODE, EEPROM_DATA_VALID_FLAG, MOTOR_TYPE, MOTOR_ID,Factory_flag ;
extern Uint16  CONST_SPEED_REF_SOURCE, CONST_SPEED_REF_1, CONST_SPEED_REF_2, CONST_SPEED_REF_3, CONST_SPEED_REF_4, CONST_SPEED_REF_5, CONST_SPEED_REF_6, CONST_SPEED_REF_7, CONST_SPEED_REF_8, CONST_SPEED_REF_9, VARIABLE_SPEED_REF_SOURCE;
extern Uint32 SPEED_RPM_REF_UI, INVERTER_PERIOD_EEPROM;
extern float RATED_VOLT_IM, RATED_CURR_IM, RATED_FREQ_IM , RATED_OMEGA_IM, RATED_COS_PHI_IM, RATED_SIN_PHI_IM, TORQUE_PERCENT_IM, MOTOR_POWER, RATED_CURRENT_IM;
extern float RATED_VOLT_PM, RATED_FREQ_PM, No_of_Pole_Pair_PM, RATED_CURR_PM, RATED_OMEGA_PM, RATED_COS_PHI_PM, TORQUE_PERCENT_PM, MOTOR_POWER_PM, Rs_PM, Ld_PM, Lq_PM ;// 13-02-2025
extern float MAX_FREQ_SET_IM, TOTAL_ENERGY, TOTAL_TIME, MAX_FREQ_SET_PM;
extern float DC_OC_VOLT, MAX_DC_VOLT, MAX_DC_CURR, MAX_OA_POWER,Max_Flow_Speed;// 13-02-2025
extern Uint16 RMT_LOC_CTRL, FAN_CTRL, PHASE_ORDER, FLT_RST,MEM_ER_FLG, MOTOR_ON_OFF, DIR_ROTATION, SWITCH_FREQ_MULT, UF_RATIO;// 13-02-2025
extern Uint16 STOP_METHOD_SEL, JOG_SEL, DWELL_REF_START, DWELL_TIME_START, DWELL_FREQ_STOP, DWELL_TIME_STOP, FREQ_REF_IP_SEL, RUN_CMD_IP_SEL;// 13-02-2025
extern Uint16 FluxErrorPI_Kp_PM, FluxErrorPI_Ki_PM,Flux_Error_Max_PM, Flux_Error_PI_Max_PM, FluxErrorPI_Kp_SynRM, FluxErrorPI_Ki_SynRM, Flux_Error_Max_SynRM, Flux_Error_PI_Max_SynRM, Flux_Error_Max_IM, Flux_Error_PI_Max_IM;// 13-02-2025

extern float Power1, Power2, Power3, Power4, Power5, Discharge1, Discharge2, Discharge3, Discharge4, Discharge5;  //04-04-2025

extern float SWITCH_FREQ;
extern float SPEED_KP_PM, SPEED_KI_PM, CURRENT_KP_PM, CURRENT_KI_PM, MAX_SOLAR_POWER, I_PV_MAX, MAX_OUTPUT_CURRENT;

//********************************* End of EEPROM Related *************************************************************//

//********************************* Scaler Control  Related *************************************************************//
extern Uint16 Count;
extern float INITIAL_VOLTPERCENT_FACTOR;  //30*7.5/100*100 = 0.0225///here we would like to add max 7.5% when someone will set 100 in the EEPROM ,
extern float Freq, Corres_Freq, Init_Voltage_Perc, Init_Voltage_Addition, Max_RMS_Possible, Set_Freq, Set_Freq_Past, Set_Freq_LPF, Set_Freq_LPF_Prev,  FREQ_STEP;
extern float VbyF_Ratio, Max, Min, Mid, VRMS;
extern float Sin1, Sin2, Sin3,Sin1_CSVPWM,Sin2_CSVPWM,Sin3_CSVPWM, Mod_Index, Theta1, Theta2, Theta_Increment;
extern float Dead_Band_Comp, Dead_Band_Comp_R, Dead_Band_Comp_Y, Dead_Band_Comp_B;
//*********************************  End of Scaler Control  Related *************************************************************//

//********************************* Vector Control  Related *************************************************************//
extern float  Rr, Rs, Llr, Lls, Lr, Ls, Lm, Tr,  LrByLm, Sigma_const, LmByTr,LPF_Constx, LPF_Consty, NUM, DEN, VC_Factor, Torque_Ref_IM_Max, Id_Iq_Error_Max;
extern float Speed_Ref_IM, Speed_Ref_IM_MAX, Set_Speed_Ref_IM_Prev, Speed_Ref_IM_LPF, Speed_Error_IM, Speed_FB_IM, W_Slip_Est, W_Stator;
extern float Id_Ref_IM, Iq_Ref_IM, Vd_Ref_IM, Vd_Ref_IM1, Vq_Ref_IM1, Vd_Ref_IM2, Vq_Ref_IM2, Vq_Ref_IM, Vd_IM_FF, Vq_IM_FF, SAI_r_IM, Torque_Ref_IM, Theta_IM, Theta_IM_Prev;
extern float Id_Sensed_IM, Iq_Sensed_IM, Id_IM_Error, Iq_IM_Error;
extern float Speed_Error_Integ, Speed_Error_Integ_Prev, Current_Error_Id_Integ, Current_Error_Id_Integ_Prev, Current_Error_Iq_Integ, Current_Error_Iq_Integ_Prev;
extern float SIN_THETA, COS_THETA, SIN_THETA_120, COS_THETA_120, SIN_THETA_240, COS_THETA_240;
extern float IR_Ref_IM, IY_Ref_IM, IB_Ref_IM,  VR_Ref_IM, VY_Ref_IM, VB_Ref_IM;
extern float I_Alpha_IM, I_Beta_IM, V_Alpha_IM, V_Beta_IM, V_Peak_IM,  Power_Q, Power_P, W_c, LPF_Const1, LPF_Const2, Motor_Power_LPF_1, Motor_Power_LPF_1_Prev;
extern float SAI_Alpha_s_IM, SAI_Beta_s_IM, SAI_Alpha_r_IM, SAI_Beta_r_IM;
extern float SAI_Alpha_s_IM_45, SAI_Beta_s_IM_45, SAI_Alpha_s_IM_45_Prev, SAI_Beta_s_IM_45_Prev;
extern float SAI_Alpha_s_IM_90, SAI_Beta_s_IM_90, SAI_Alpha_s_IM_90_Prev, SAI_Beta_s_IM_90_Prev;
extern float SAI_Alpha_r1_IM, SAI_Beta_r1_IM, SAI_Alpha_r1_IM_Prev, SAI_Beta_r1_IM_Prev, Flux_IM, Flux_IM1, Flux_Error_IM, W_Est, W_Est_Prev, W_Est_LPF, W_Est_LPF_debug, Flux_Error_Integ, Flux_Error_Integ_Prev;
extern float tempa, tempb, tempc, tempd, tempe, tempf, tempg, temph;
extern float Speed_Ref_STEP;
//*********************************  End of Vector Control IM  Related *************************************************************//

//********************************* Vector Control PMSM  Related *************************************************************//
extern Uint16 trial;
extern float Rs_PM, Ld_PM, Lq_PM, Time_Blank_OC_Detection;
extern float I_Alpha_PM, I_Beta_PM, V_Alpha_PM, V_Beta_PM, V_Alpha_E_PM, V_Beta_E_PM;;
extern float  V_Alpha_PM_LPF_50_Prev, V_Alpha_PM_LPF_50, V_Beta_PM_LPF_50_Prev, V_Beta_PM_LPF_50;
extern float LPF_SAI_PM_C1, LPF_SAI_PM_C2, LPF_SAI_THETA_PM_C1, LPF_SAI_THETA_PM_C2, Wc_SAI_PM, Wc_SAI_THETA_PM;
extern float SAI_Alpha_s_Theta_PM, SAI_Alpha_s_Theta_Prev_PM, SAI_Alpha_s_PM, SAI_Alpha_s_Prev_PM, SAI_Beta_s_Theta_PM, SAI_Beta_s_Theta_Prev_PM, SAI_Beta_s_PM, SAI_Beta_s_Prev_PM;
extern float SAI_Mag_PM, flux_mag, W_est_PM;
extern float W_est_Prev_PM, W_est_PM_LPF, W_est_Prev_PM1, W_est_PM_LPF_SLOWEST;
extern float Speed_Ref_PM_Prev, SPEED_LPF_Cutoff, LPF_Const_SPDREF1, LPF_Const_SPDREF2;
extern float speed_info;
extern float Speed_Ref_PM_Corr_Prev;
extern float Speed_FB_PM, Speed_Error_PM, Speed_Ref_PM, Speed_Ref_PM1, Speed_Ref_PM2, Speed_Ref_PM3, Torque_Ref_PM, I, ID_REF_PM, Iq_Ref_PM, Theta_PM,Speed_Ref_PM_debug;
extern float kx, ky, Q1, P1;
extern float INV_U_Ph, INV_V_Ph, INV_W_Ph;
extern float INV_U_Ph_DC_Prev, INV_V_Ph_DC_Prev, INV_W_Ph_DC_Prev, INV_U_Ph_DC, INV_V_Ph_DC, INV_W_Ph_DC, INV_U_Ph_Filt, INV_V_Ph_Filt, INV_W_Ph_Filt;
extern Uint32 Counter_PM, START_FAIL_PMSM_COUNT;
extern bool PM_flag_start;
extern float W_start, Timer_Flag_start, Theta_RESET_COUNT, Theta_RESET_COUNT1, Theta_RESET_COUNT2, exit_count_SS;
extern float KP_ICNTRL_Park, KI_ICNTRL_Park, Counter_PM_Freq_Inc, Ramp_Rate_PM, INIT_RAMP_TIME_PMSM;
extern float Speed_Error_Integ_PM, Speed_Ref_PM_Min, Speed_Error_Integ_sat,  Last_Speed_I_Output_PM;
extern float debug_Theta_PM, pi_out_merge, diff_Theta_PM, Istart_PM_Delta;
extern float Last_theta_PM, PFC_THETA_CORRECTION, PFC_THETA_CORRECTION1, PFC_CF;
extern float OCTest_IZero_Threshold, OCTest_IRZero, OCTest_IYZero, OCTest_IBZero, OC_Time_Window, OC_Total_Count;
extern bool SPEED_STOP_INCREASE, FLAG_OPEN_PM, FLAG_CORRES_SPEED_PMSM, FLAG_PARK, FLAG_PARK_EEPROM, START_FAIL_PMSM;
extern float FREQ_LIMIT_PM;
extern float threshold1, threshold2;
extern float Trial_W_start;//, Speed_Error_PM_PI_Ki, Speed_Error_PM_PI_Kp;
extern float SIN_THETA_PM, COS_THETA_PM, SIN_THETA_120_PM, COS_THETA_120_PM;
extern float IR_Ref_PM, IY_Ref_PM, IB_Ref_PM, Iq_Sensed_PM, Id_Sensed_PM, PMSM_THETA_FACTOR, IMP_FACTOR, PMSM_THETA_FACTOR1;
extern float Current_Error_Id_PM, Current_Error_Iq_PM, Vd_Ref_PM, Vq_Ref_PM, debug_Vd_Ref_PM, debug_Vq_Ref_PM;
extern float Back_EMF, Rotor_Flux, DC_link_PU; /*Speed_Error_PM_Integ_Max , Speed_PI_PM_Output_Max, Current_Error_Id_PM_Max, Current_Error_Iq_PM_Max;*/
//extern float Current_Error_Id_PM_Kp,  Current_Error_Id_PM_Ki;/*, TOL_V, TOL_I;*/
extern float errorintoki, errorintokp,pi_output1;
extern float Current_Error_Id_PM_Integ, Last_Current_Id_PM_Output;
//extern float Current_Error_Iq_PM_Kp,  Current_Error_Iq_PM_Ki;
extern float Current_Error_Iq_PM_Integ, Last_Current_Iq_PM_Output;
extern float Total_Flux, D_Feed_FWD, Q_Feed_FWD, D_Flux_Linkage, Q_Flux_Linkage;
extern float INIT_RAMP_TIME_PMSM1, MOD_GAIN_PM,  INIT_VOLTPERCENT_FACTOR, TORQUE_LIMIT_PM, CURR_ERROR_LIMIT_PM, VOLT_OUTPUT_LIMIT_PM, ISTART_PM_LIMIT,VOLT_OUTPUT_LIMIT_debug;
extern float VR_Ref_PM, VY_Ref_PM, VB_Ref_PM, VR_Ref_PM1, VY_Ref_PM1, VB_Ref_PM1, debug_Iq_Ref_PM;
extern float Park_IR_ref, Park_IY_ref, Park_IB_ref;
extern float Park_IR_delta, Park_IY_delta, Park_IB_delta;
extern float VR_Ref_Park, VY_Ref_Park, VB_Ref_Park, mdqgain_Park, IRATED_Park, pi_out_merge, Istart_PM, ISTART_PM_FACTOR, Istop_PM, IRATED_Park_limit;
extern float Park_IR_KP, Park_IR_KI, Park_IR_KI_Prev, Park_IR_PI;
extern float Park_IY_KP, Park_IY_KI, Park_IY_KI_Prev, Park_IY_PI;
extern float Park_IB_KP, Park_IB_KI, Park_IB_KI_Prev, Park_IB_PI;
extern float Max_PM, Min_PM, Mid_PM;
extern float PMSM_MIN_RPM;
extern float DAC_Var, V_res, y_out1, Theta_PM_temp;
extern float Speed_Error_PM_PI_Ki_1;
extern float I_Alpha_OTH,I_Beta_OTH, V_Alpha_OTH,V_Beta_OTH, I_Peak, I_RMS, V_Peak, Reactive_Pow, Active_Pow, Active_Pow1,V_a_OTH, V_b_OTH,V_c_OTH;
extern float theta_corr, theta_cor1, theta_lag_calc, theta_lag_comp, gain_comp, V_Peak_corr, V_Alpha_OTH_Corr,V_Beta_OTH_Corr, Active_Pow_corr;
extern float Lmid, SAI_Alpha_r_Theta_PM_corr, SAI_Alpha_s_Theta_PM_corr, SAI_Beta_s_Theta_PM_corr, SAI_Beta_r_Theta_PM_corr, SAI_s_Theta_PM_Mag_corr;
extern float V_Peak_corr_Avg, V_Peak_corr_Prev, V_Peak_corr1, Corres_Speed1, Corres_Speed2,Corres_Speed2_debug, Corres_Speed, V_Peak_corr_Avg1;
extern float  SPEED_LIMIT_MAX_FREQ_SET, SPEED_LIMIT_RATED_FREQ_SET, SPEED_REF_PM_LIMT;
extern float PARKING_COUNTER_THR, OPEN_LOOP_COUNTER_PM, OPEN_LOOP_MER_COUNTER_PM, HLD_ROTOR_COUNTER_PM, PMSM_START_FAIL_THR, PM_RAMP_STEP_COUNTER, PM_RAMP_STEP_COUNTER;
//*********************************  End of Vector Control PMSM  Related *************************************************************//

//********************************* ADC/DAC Related *************************************************************//
extern Uint16 DAC, Avgi;
extern Uint16 MUX_POS, S2, S1, S0, MUX_Count;
extern float VDC_BUS,I_INV_R, I_INV_Y, I_INV_B, VINV_RY, VINV_YB, VINV_BR, VGRD_RY, VGRD_YB, VGRD_BR, I_GRID_R;
extern float MSC_I_U, MSC_I_V, MSC_I_W, MSC_I_U_SQR, MSC_I_V_SQR, MSC_I_W_SQR;
extern float TEMPHS_COUNT,TEMPINV_COUNT, TEMP_HS, TEMP_INV;
extern Uint16 TEMPHS_COUNT1, TEMPINV_COUNT1, PLC_V_count, PLC_I_count;
extern float VINV_UV_MAF, VINV_VW_MAF, VINV_WU_MAF, I_INV_U_MAF, I_INV_V_MAF, VGRD_RY_MAF, VGRD_YB_MAF, VGRD_BR_MAF, I_GRD_R_MAF, VDC_BUS_MAF, I_GRID_MAF,  I_INV_R_MAF, I_INV_Y_MAF, I_INV_B_MAF, W_est_PM_MAF;
extern float VINV_UV1[4], VINV_VW1[4], VINV_WU1[4], I_INV_U1[4], I_INV_V1[4], VGRD_RY1[4], VGRD_YB1[4], VGRD_BR1[4], I_GRD_R1[4], VDC_BUS1[4], I_GRID_R1[4], I_INV_R1[4], I_INV_Y1[4], W_est_PM_1[4];
extern float Freq_PLL;
extern float DaqMeasItems_VOLT_GRD_RY_buf[64];
extern float DaqMeasItems_VOLT_GRD_YB_buf[64];
extern float DaqMeasItems_VOLT_GRD_BR_buf[64];
extern float DaqMeasItems_CURR_GRD_R_buf[64];
extern float DaqMeasItems_VOLT_VFD_UV_buf[64];
extern float DaqMeasItems_VOLT_VFD_VW_buf[64];
extern float DaqMeasItems_VOLT_VFD_WU_buf[64];
extern float DaqMeasItems_CURR_VFD_U_buf[64];
extern float DaqMeasItems_CURR_VFD_V_buf[64];
extern float DaqMeasItems_CURR_VFD_W_buf[64];
typedef struct IndexPara
{
    Uint16 indexScaler;
    Uint16 indexCount;
    Uint16 pllIndex;
    Uint16 index64;
    bool zcDetected;
}IndexPara;


typedef enum{
    VOLT_VFD_UV,
    VOLT_VFD_VW,
    VOLT_VFD_WU,
    CURR_VFD_U,
    CURR_VFD_V,
    CURR_VFD_W,
    CURR_GRD_R,
    VOLT_GRD_RY,
    VOLT_GRD_YB,
    VOLT_GRD_BR,
    DAQ_N_MEAS_ITEMS
}DaqMeasItemsId_t;

typedef struct RMSData
{
    float x_0;
    float x_1;
    float y_0;
    float y_1;
    float d_sumOfSquares;
    float d_msq;
    float RMS;
}RMSData;
extern IndexPara InvIndexPara, GrdIndexPara;

extern float Input_Vol_RY,Input_Vol_YB,Input_Vol_BR;
extern float Input_Curr_R,Input_Curr_Y,Input_Curr_B;
extern float Output_Vol_UV,Output_Vol_VW,Output_Vol_WU;
extern float Output_Curr_U,Output_Curr_V,Output_Curr_W;

extern RMSData VGRD_RY_STRUCT, VGRD_YB_STRUCT,VGRD_BR_STRUCT, IGRD_R_STRUCT,IGRD_Y_STRUCT,IGRD_B_STRUCT,   VVFD_UV_STRUCT, VVFD_VW_STRUCT, IVFD_U_STRUCT, IVFD_V_STRUCT;
extern RMSData VGRD_RY_STRUCT, VGRD_YB_STRUCT, VGRD_BR_STRUCT, IGRD_R_STRUCT,  VVFD_UV_STRUCT, VVFD_VW_STRUCT, VVFD_WU_STRUCT, IVFD_U_STRUCT, IVFD_V_STRUCT, IVFD_W_STRUCT;
extern float VGRD_RY_RMS_Prev , VGRD_RY_RMS_LPF,  VDC_BUS_LPF_1_Prev, VDC_BUS_LPF_1, VDC_BUS_LPF_50_Prev, VDC_BUS_LPF_50, I_GRID_R_LPF_50, I_GRID_R_LPF_50_Prev, I_OUTPUT_AVG;
extern float P_PV_Avg, flow_LPM;

//********************************* End of ADC/DAC Related *************************************************************//

//********************************************SOLAR MPPT****************************************************************//
extern bool MPPT_START_FLAG, flag_VFD_MPP_Initial, FLAG_CORRES_SPEED_IM;
extern Uint16 MPPT_Counter;
extern float Setfreq_IM_MPPT , Setfreq_IM_MPPT_Prev, Setfreq_IM_MPPT_LPF, Freq_Ref_Max_temp1, Freq_Ref_Max_temp2, Freq_Ref_VFD_Max, Speed_Ref_VFD_Max;
extern float SetSpeed_PMSM_NewMPP, SetSpeed_PMSM_NewMPP_LPF, SetSpeed_PMSM_NewMPP_Prev, F_REF_PMSM_TS_MAX_temp, F_REF_PMSM_TS_MAX, SPEED_REF_PMSM_TS_MAX;
extern float VDC_VFD_ERROR_Integ, Last_VDC_VFD_ERROR_Integ;
extern float VDC_VFD_ERROR_Integ_Max, VDC_VFD_ERROR_Integ_Min, VDC_VFD_ERROR_PI_Output_Max, Speed_Ref_VFD_Max_UPPER, VDC_VFD_ERROR_PI_Output_Min;
extern float MPPT_VDC_REF, Freq_Ref_MPPT, VFD_VDC_KP1, VOC_START_VFD;
extern float VPV_Avg_Prev,  IPV_Avg_Prev;
extern float tol_P_vfd, tol_V_vfd;
extern Uint16 ssfc1, ssfc2, ssfc3, ssfc4, ssfc5, ssfc6, ssfc7,ssfc8,ssfc9,ssfc10, ssfc11, ssfc12, ssfc13;
extern float  VFD_VDC_STEP; //VFD_VDC_KP, VFD_VDC_KI
extern float Cumulative_Energy,Cummulative_Water_Discharge,Cumulative_Pump_Run_Hrs,Cumulative_Run_Hrs, Flow_Speed;
extern float Daily_Water_Discharge,Daily_Pump_Run_Hrs,Torque_Ref;
extern Uint32 Control_Ref_Selection;
extern float MAX_PV_POWER_UPPER, MAX_OUTPUT_CURRENT_UPPER, Freq_UPPER_LIMIT, I_PV_MAX_UPPER;
extern float VFD_VDC_KP , VFD_VDC_KI, VDC_VFD_ERROR_Max;
//**************************************END OF SOLAR MPPT**************************************************************//

//********************************* Software RTC *************************************************************//
extern Uint32 mSeconds, Tick_Tick , Tick_Tick1;
extern float Minute_Count, Reset_Tick_Tick_Minute_Reset, Tick_Tick_Minute_Reset;

//********************************* End of Software RTC *************************************************************//

//********************************* Menus and State MAchine  *************************************************************//
extern float Button_Pressed;
extern Uint16 ON_BUTTON_COUNT, OFF_BUTTON_COUNT;
extern float Exit_Count_SS, ON_OFF_DELAY_TIMER, P_PV_Avg_DELAY_TIMER, Retry_time_Minutes, Retry_time_Minutes_EEPROM;
extern Uint16 Delay_flag;
//********************************* End of Menus and State MAchine  *************************************************************//

//********************************* ADC ISR*************************************************************//
extern Uint16 Blink_LED, UART_Test, Motor_Timer, EEPROM_READ,CUMMULATIVE_PARAMETER_TIMER;
extern unsigned char TZ_CLR, ALL_PWM_LOW, TZ_FRC_SW;
extern unsigned char PWM_Release_Flag;
//********************************* End of ADC ISR*************************************************************//

//********************************* Faults and Warning related Variables ********************************************************//

#define DC_BUS_OV_FLT_BIT                   0x01
#define DC_BUS_OV_FLT_CLR_BIT               0xFFFFFFFE
#define DC_BUS_UV_FLT_BIT                   0x02
#define DC_BUS_UV_FLT_CLR_BIT               0xFFFFFFFD
#define VFD_OVERTEMP_FLT_BIT                0x04
#define VFD_OVERTEMP_FLT_CLR_BIT            0xFFFFFFFB
#define OUTPUT_OV_FLT_BIT                   0x08
#define OUTPUT_OV_FLT_CLR_BIT               0xFFFFFFF7
#define OUTPUT_OVERLOAD_FLT_BIT             0x10
#define OUTPUT_OVERLOAD_FLT_CLR_BIT         0xFFFFFFEF
#define OUTPUT_SC_FLT_BIT                   0x20
#define OUTPUT_SC_FLT_CLR_BIT               0xFFFFFFDF
#define LOAD_DRY_RUN_FLT_BIT                0x40
#define LOAD_DRY_RUN_FLT_CLR_BIT            0xFFFFFFBF
#define INPUT_UNBALANCE_FLT_BIT             0x80
#define INPUT_UNBALANCE_FLT_CLR_BIT         0xFFFFFF7F
#define VFD_OUT_OPEN_FLT_BIT                0x100
#define VFD_OUT_OPEN_FLT_BIT_CLR_BIT        0xFFFFFEFF


#define OUTPUT_HIGH_INRUSH_FLT_BIT          0x200
#define OUTPUT_HIGH_INRUSH_FLT_CLR_BIT      0xFFFFFDFF
#define LOW_POWER_FLT_BIT                   0x400
#define LOW_POWER_FLT_BIT_CLR_BIT           0xFFFFFBFF

/*
#define DUMMY4_FLT_BIT                      0x400
#define DUMMY4_FLT_BIT_CLR_BIT              0xFFFFFBFF
#define DUMMY5_FLT_BIT                      0x800
#define DUMMY5_FLT_BIT_CLR_BIT              0xFFFFF7FF
#define DUMMY6_FLT_BIT                      0x1000
#define DUMMY6_FLT_BIT_CLR_BIT              0xFFFEFFF
#define DUMMY7_FLT_BIT                      0x2000
#define DUMMY7_FLT_BIT_CLR_BIT              0xFFFFDFFF
#define DUMMY8_FLT_BIT                      0x4000
#define DUMMY8_FLT_BIT_CLR_BIT              0xFFFFBFFF
#define DUMMY9_FLT_BIT                      0x8000
#define DUMMY9_FLT_BIT_CLR_BIT              0xFFFF7FFF
#define DUMMY10_FLT_BIT                     0x10000
#define DUMMY10_FLT_BIT_CLR_BIT             0xFFFEFFFF
*/



extern Uint32 FAULT_CODE;
extern float DC_BUS_OV_LIMIT, OVER_CURR_LIMIT, VFD_OVER_TEMP_LIMIT, VFD_OVER_VOLT_LIMIT, DC_BUS_OV_RESET_HYS, VFD_OVER_TEMP_LIMIT_1, VFD_OVER_TEMP_LIMIT_2;
extern float MIN_PV_POWER, MAX_CURR_LIMIT;
extern Uint16 SC_DETECTION_CTR, COUNT_SC_FAULT;
extern float Timer_DCBUS_OV_Reset, TimerDCUV_LPD, TimerDCUV_LPD_Reset, Time_DCUV_LPD_Reset, Timer_SC_FLT_Reset, Timer_Overtemp, Timer_Overtemp_Reset, Timer_outputOV, Timer_outputOV_Reset;
extern float Powe_AT_ELP, Timer_Phaseloss, Timer_Phaseloss_Reset, Timer_OverLoad, Timer_OverLoad_Reset, Timer_OpenCircuit, Timer_OpenCircuit_Reset,INPUT_VOLT_UNBALANCE_LIMIT,INPUT_UNBALANCE_LIMIT;
extern float timerdryrun, timerdryrun_Reset;
extern bool EEPROM_Fault_Write_Enable, DC_BUS_OV_FLT, DC_BUS_UV_FLT, OUTPUT_SC_FLT, VFD_OVERTEMP_FLT, VFD_OUT_OV_FLT, INPUT_UNBALANCE_FLT, VFD_OUT_OL_FLT, VFD_OUT_OPEN_FLT, FLAG_OPEN_CKT, LOAD_DRY_RUN_FLT;
extern float Torue_MIN,Torque_Max,DCBUS_UNDER_VOLT,Speed_Max,Speed_Min,Freq_Max,Freq_Min,DRY_RUN_CURR_LIMIT,DRY_RUN_POWER_LIMIT;
extern bool  UV_Enable,OV_Enable,OVER_TEMP_Enable,OC_Enable,Over_Load_enable,Over_Speed_Enable,DRY_Run_Enable;
extern bool OUTPUT_HIGH_INRUSH_FLT;
extern Uint16  Motor_Slow_Lmt_OC, Motor_Med_Lmt_OC, Motor_Fast_Lmt_OC, Motor_Short_Term_Over_Current_DSP_SLOW, Motor_Short_Term_Over_Current_DSP_MEDIUM, Motor_Short_Term_Over_Current_DSP_FAST, Motor_Slow_Lmt_OC_Reset;
extern float  Motor_Check_Occurance_OC,Motor_Check_RESET_OC;
extern float OUTPUT_OPEN_LOW_LIMIT, OUTPUT_OPEN_HIGH_LIMIT, MOTOR_PWR_MIN_LIMIT;
/*********************************  End of Faults and Warning related Variables ********************************************************/

//*********************************Functions*************************************************************//

void Variable_Init(void);
void Varible_Init_Revised(void);
//*********************************End of Functions******************************************************//


extern float TEMP_HS_TABLE[], TEMP_INV_TABLE[];


#endif /* HEADERS_PROJECT_HEADER_GLOBAL_VARIABLE_H_ */
