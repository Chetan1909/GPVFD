/*
 * F&W_Manager.h
 *
 *  Created on: Jul 20, 2023
 *      Author: Dell
 */

#ifndef HEADERS_PROJECT_HEADER_F_W_MANAGER_H_
#define HEADERS_PROJECT_HEADER_F_W_MANAGER_H_


void Faults_and_Warnings_Manager(void);


#endif /* HEADERS_PROJECT_HEADER_F_W_MANAGER_H_ */
