/*
 * PLC_IO.h
 *
 *  Created on: 16-Jun-2025
 *      Author: commc
 */

#ifndef HEADERS_PROJECT_HEADER_PLC_IO_H_
#define HEADERS_PROJECT_HEADER_PLC_IO_H_



extern unsigned char loop;
extern Uint16 V_RPM, I_RPM, I_Mean1, I_Mean2;

typedef struct PLC_Para_DI{
    bool Parameter_FLAG;
    unsigned char PLC_DI;
//    unsigned char Parameter;
}PLC_Para_DI;

extern void Analog_PLC_Handler();
extern void Digital_PLC_Handler();
extern bool Configurable_DIOs(unsigned char, unsigned char);

void Two_Wire_Mode1();
void Two_Wire_Mode2();
void Three_Wire_Mode1();
void Three_Wire_Mode2();
void Float_Switch();

void PLC_Froward();
void PLC_Reverse();
void PLC_Stop();

void RELAY1_H();
void RELAY1_L();
void RELAY2_H();
void RELAY2_L();


#endif /* HEADERS_PROJECT_HEADER_PLC_IO_H_ */
