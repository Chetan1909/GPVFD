/*
 * MODBUS.h
 *
 *  Created on: 25-Aug-2023
 *      Author: Dipesh
 */

#ifndef HEADERS_PROJECT_HEADERS_ADDRESS_H_
#define HEADERS_PROJECT_HEADERS_ADDRESS_H_


#define RAM_OFFSET          0x0000A000
typedef enum
{
    UINT_8 = 0,
    UINT_16,
    FLOAT,
    UINT_32
}Var_type;



typedef struct Memory_map{
    unsigned int modbus_address;
    unsigned char Var_type;
    unsigned int min_val;
    unsigned long int max_val;                                        //char max_val,to be checked;
    unsigned long int default_val;                                    //char default_val,to be checked;
    unsigned int Mem_address;
    unsigned int Scale_Factor;
    unsigned char quantity_reg;
}Memory_map;

extern const Memory_map Memory_add[];


//#include "Init.h"

//#pragma LOCATION(tempOffset, 0x0000A101)
//int tempOffset;
//#pragma LOCATION(tempOffset1, 0x0000A002)
//int tempOffset1;
//#pragma LOCATION(tempOffset2, 0x0000A003)
//int tempOffset2;
//#pragma LOCATION(tempOffset3, 0x0000A004)
//int tempOffset3;
//#pragma LOCATION(tempOffset4, 0x0000A005)
//int tempOffset4;
//#pragma LOCATION(tempOffset5, 0x0000A006)
//float tempOffset5;










#endif /* HEADERS_PROJECT_HEADERS_ADDRESS_H_ */
