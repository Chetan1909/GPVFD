/*
 * I2C_Init.h
 *
 *  Created on: 28-Aug-2023
 *      Author: arjun
 */

#ifndef HEADERS_PROJECT_HEADER_I2C_INIT_H_
#define HEADERS_PROJECT_HEADER_I2C_INIT_H_

#define eeprom_24xx64_control_word      0x0A
#define eeprom_24xx64_pin_address       0x00

#define eeprom_24xx64_total_no_page     0x3F        //  for 64 pages
#define eeprom_24xx64_byted_per_page    0x7F        //  for 128 bytes per page
#define eeprom_24xx64_byte_start_page   1
#define eeprom_24xx64_byte_end_page     100
#define eeprom_24xx64_int_start_page    1
#define eeprom_24xx64_int_end_page      100
#define eeprom_24xx64_float_start_page  1
#define eeprom_24xx64_float_end_page    100

void EEPROM_Default_Data_Write(void);
void EEPROM_All_Data_Read(void);
void ConfigureEEprom(void);
void I2C_init(void);

void EEPROM_WriteByte(unsigned char, unsigned char, unsigned char);
void EEPROM_WriteInt(unsigned char, unsigned char, unsigned int);
void EEPROM_WriteFloat(unsigned char, unsigned char, float);
void EEPROM_WriteByte_24XX64(unsigned char, unsigned int, unsigned char);

unsigned char EEPROM_ReadByte(unsigned char , unsigned char );
unsigned int EEPROM_ReadInt(unsigned char , unsigned char );
float EEPROM_ReadFloat(unsigned char , unsigned char );
unsigned char EEPROM_ReadByte_24XX64(unsigned char,unsigned int);

char dec2bcd(char num);
char bcd2dec(char num);
void init_BQ32(void);

void set_date_alone_BQ32(unsigned char date);
void set_month_alone_BQ32(unsigned char month);
void set_year_alone_BQ32(unsigned char year);
void set_hour_time_BQ32(unsigned char hour);
void set_minute_time_BQ32(unsigned char minute);

void read_date_BQ32(unsigned char *day, unsigned char *date, unsigned char *month, unsigned char *year);
void read_time_BQ32(unsigned char *second, unsigned char *minute, unsigned char *hour);
void set_date_BQ32(unsigned char day,unsigned char date, unsigned char month,unsigned char year);
void set_time_BQ32(unsigned char second,unsigned char minute, unsigned char hour);

void EEPROM_WriteByte_BQ32( unsigned char address,unsigned char data);
unsigned char EEPROM_ReadByte_BQ32(unsigned char address);
void wait_i2c_bytesent_set(void);
void wait_i2c_xrdybit_set(void);
void wait_i2c_busbusy_clear(void);
void wait_i2c_stpbit_clear(void);
void wait_i2c_rrdybit_set(void);
#endif /* HEADERS_PROJECT_HEADER_I2C_INIT_H_ */
