/*
 * SPI_Init.h
 *
 *  Created on: 05-Oct-2023
 *      Author: arjun
 */

#ifndef HEADERS_PROJECT_HEADER_SPI_INIT_H_
#define HEADERS_PROJECT_HEADER_SPI_INIT_H_

#define SPI_Buffer_Size      81               // sagar


extern unsigned char rec_buff_index;


void ConfigureSPI(void);

__interrupt void spiaTxFifoIsr(void);               // SPIA TX INTRUPT
__interrupt void spiaRxFifoIsr(void);               // SPIA RX INTERRUPT

//void SPI_Recv_Process(void);
void SPI_modbus(void);      //sagar
void SPI(void);
void MB_function(unsigned char *CMD_REC_MB); //sagar
unsigned int checksum(unsigned char *buf,int start, int len);  //sagar
void copy_buffer_part(char *source, int start_index, int length, char *destination); // sagar
void copy_buffer_part_wraparound(unsigned char *source, unsigned int start_index, unsigned int length, unsigned char *destination, unsigned int buffer_size); //SAGAR
void Display_SPI_Buffer_Fill(void);
void Update_Motor_Para(void);    // sagar for parameter like on/off
void Update_Modbus_Memory();

#endif /* HEADERS_PROJECT_HEADER_SPI_INIT_H_ */
