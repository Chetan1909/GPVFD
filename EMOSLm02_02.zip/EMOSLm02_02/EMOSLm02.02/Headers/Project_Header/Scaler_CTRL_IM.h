/*
 * Scaler_CTRL_IM.h
 *
 *  Created on: Jul 21, 2023
 *      Author: Dell
 */

#ifndef HEADERS_PROJECT_HEADER_SCALER_CTRL_IM_H_
#define HEADERS_PROJECT_HEADER_SCALER_CTRL_IM_H_

void Scaler_Control_IM(void);

#endif /* HEADERS_PROJECT_HEADER_SCALER_CTRL_IM_H_ */
